﻿using mshtml;
using R2R_UI.Common;
using R2R_UI.History;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace R2R_UI
{
    public partial class frmMain
    {
        #region Param Def
        bool bHaveInitHistory = false;
        bool bDgvClick = false;

        string strService = string.Empty;
        string strNetwork = string.Empty;
        string strDaemon = string.Empty;
        string strTargetSubject = string.Empty;

        //"User Id=e3suite;Password=e3suite;Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=192.168.150.135)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=e3suite)))";
        string strConn = string.Empty;

        //TIMESTAMP,LOT_ID,FAB,AREA,PRODUCT,LAYER_OR_STEP,STAGE,TOOL_ID,SERVICEMETHOD
        //MACHINENAME,ENGINENAME,TRANSACTIONTAG,R2RMODE_MES,R2RMODE_E3,STRATEGYNAME,RECIPE,R2R_CONTEXT_GROUP,RETCODE,RETMESSAGE,PROCESS_LOG,CALCULATION_LOG
        DataTable dtProcessLog = new DataTable("dbProcessLog");

        //TIMESTAMP,LOT_ID,FAB,AREA,PRODUCT,LAYER_OR_STEP,STAGE,TOOL_ID,SERVICEMETHOD
        //SYSTEM_FROM,SYSTEM_TO,MACHINENAME,ENGINENAME,TRANSACTIONTAG,RECIPE,R2RMODE_MES,RETCODE,RETMESSAGE,XML_LOG
        DataTable dtXmlLog = new DataTable("dbXmlLog");

        string strXmlLog = string.Empty;
        string strProcessLog = string.Empty;
        string strCalculationLog = string.Empty;
        #endregion

        #region dtp_History_ValueChanged
        string startTime = string.Empty;
        string endTime = string.Empty;
        private void GetTimePeriodValue(ref string FromTime,ref string ToTime)
        {
            FromTime = string.Empty;
            ToTime = string.Empty;

            DateTime startTimeTmp = dtpFrom_History.Value;
            DateTime endTimeTmp = dtpTo_History.Value;

            FromTime = startTimeTmp.ToString("o");
            ToTime = endTimeTmp.ToString("o");
        }

        private void dtp_History_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                ClearControl_History();
                GetTimePeriodValue(ref startTime, ref endTime);

                string strTabName = tabLog_History.SelectedTab.Name;
                if (strTabName.Equals("tabPageXML"))
                {
                    string sql = string.Format("SELECT * FROM R2R_UI_HISTORY_XML_LOG WHERE TIMESTAMP >= '{0}' AND TIMESTAMP<='{1}'", startTime, endTime);
                    dtXmlLog = OracleHelp.ExecuteDataTable(strConn, sql);
                }
                else
                {
                    string sql = string.Format("SELECT * FROM R2R_UI_HISTORY_PROCESS_LOG WHERE TIMESTAMP >='{0}' AND TIMESTAMP<='{1}'", startTime, endTime);
                    sql = "SELECT* FROM ( " + sql + ") WHERE ROWNUM <=" + txtListOfRuns_History.Text.ToString();
                    dtProcessLog = OracleHelp.ExecuteDataTable(strConn, sql);
                }
                if (bHaveInitHistory)
                {
                    btnRun_History_Click(sender, e);
                }
                txtFrom.Text = dtpFrom_History.Text.ToString();
                txtTo.Text = dtpTo_History.Text.ToString();
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }
        #endregion

        #region Init 
        private void InitCmbHistory()
        {
            try
            {
                #region
                strListModule_History = new List<string>(strListModule);
                cmbModule_History.DataSource = strListModule_History;

                InitCmbDataText();
                #endregion
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private void InitCmbDataText()
        {
            if (cmbModule_History.Items.Count > 0)
            {
                cmbModule_History.SelectedIndex = 0;
            }
            else
            {
                cmbModule_History.Text = "*";
            }

            cmbLotId_History.Text = "*";
            cmbProduct_History.Text = "*";
            cmbStage_History.Text = "*";
            cmbLayer_History.Text = "*";
            cmbTool_History.Text = "*";
        }

        private void InitDateTime()
        {
            try
            {
                #region
                this.dtpFrom_History.Value= DateTime.Now.AddDays(-7);

                //控制日期或时间的显示格式
                this.dtpFrom_History.CustomFormat = "yyyy-MM-dd";
                //this.dtpFrom_History.CustomFormat = "yyyy-MM-dd HH:mm:ss";
                //使用自定义格式
                this.dtpFrom_History.Format = DateTimePickerFormat.Custom;
                //时间控件的启用
                //this.dtpFrom.ShowUpDown = true;

                //控制日期或时间的显示格式
                this.dtpTo_History.CustomFormat = "yyyy-MM-dd";
                //this.dtpTo_History.CustomFormat = "yyyy-MM-dd HH:mm:ss";
                //使用自定义格式
                this.dtpTo_History.Format = DateTimePickerFormat.Custom;

                txtFrom.Text = dtpFrom_History.Text.ToString();
                txtTo.Text = dtpTo_History.Text.ToString();
                #endregion
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private void InitBtnProcess()
        {
            btnProcess_History.BackColor = SystemColors.GradientActiveCaption;
            btnProcess_History.Text = "State";
        }

        private void InitTabLogHistory()
        {
            tabLog_History.SelectedTab = tabLog_History.TabPages[0];
            tabLog_History.TabPages[0].Refresh();
            tabLog_History.TabPages[0].Update();
            tabLog_History.TabPages[0].Show();
        }

        private void InitHistoryGrd()
        {
            dgvContext_History.DataSource = null;
            dgvBasicInformation_History.DataSource = null;
        }

        private void ClearCmbHistoryList()
        {
            strListLotId_History.Clear();
            strListProduct_History.Clear();
            strListStage_History.Clear();
            strListLayer_History.Clear();
            strListTool_History.Clear();
        }

        private void ClearControl_History()
        {
            bDgvClick = false;
            dgvContext_History.DataSource = null;
            dgvBasicInformation_History.DataSource = null;
            tvwDetails.Nodes.Clear();
            NodeLastSelected = null;
          //  panDetailsDgv.Controls.Clear();//清空panel
            wbsCalculation_History.DocumentText = "";
            wbsXML_History.DocumentText = "";
            strXmlLog = string.Empty;
            strProcessLog = string.Empty;
            strCalculationLog = string.Empty;
            ht.Clear();
            InitBtnProcess();
        }

        private void ClearTabLogControl_History()
        {
            dgvBasicInformation_History.DataSource = null;
            tvwDetails.Nodes.Clear();
            NodeLastSelected = null;
          //  panDetailsDgv.Controls.Clear();//清空panel
            wbsCalculation_History.DocumentText = "";
            wbsXML_History.DocumentText = "";
            strXmlLog = string.Empty;
            strProcessLog = string.Empty;
            strCalculationLog = string.Empty;
            InitBtnProcess();
        }

        #endregion

        #region GetCmb
        private void GetAllCmbHistoryList(DataTable db)
        {
            ClearCmbHistoryList();

            strListLotId_History = GetCmbDataHelp.GetCmbData(db, "LOT_ID");
            strListProduct_History = GetCmbDataHelp.GetCmbData(db, "PRODUCT");
            strListStage_History = GetCmbDataHelp.GetCmbData(db, "STAGE");
            strListLayer_History = GetCmbDataHelp.GetCmbData(db, "LAYER_OR_STEP");
            strListTool_History = GetCmbDataHelp.GetCmbData(db, "TOOL_ID");
        }

        private List<string> GetCmbHistoryList(string strKey)
        {
            List<string> strList = new List<string>();
            try
            {
                DataTable dtCmb = new DataTable("dbCmbHistory");
                int maxRow = int.Parse(txtListOfRuns_History.Text.ToString());

                GetTimePeriodValue(ref startTime, ref endTime);

                string sql = "SELECT " + strKey +","+"TIMESTAMP FROM R2R_UI_HISTORY_PROCESS_LOG WHERE ";

                string sqlCmb = GetSql_Cmb(strKey);

                if (sqlCmb.Equals(""))
                {
                    sql = "SELECT " + strKey + "," + "TIMESTAMP FROM R2R_UI_HISTORY_PROCESS_LOG ";
                    sql = string.Format(sql + " WHERE TIMESTAMP >='{0}' AND TIMESTAMP<='{1}'", startTime, endTime);
                }
                else
                {
                    sql += sqlCmb;
                    sql = string.Format(sql + " AND TIMESTAMP >='{0}' AND TIMESTAMP<='{1}'", startTime, endTime);
                }

                string strSort = GetStrSort();
                sql += strSort;

                sql = "SELECT* FROM ( " + sql + ") WHERE ROWNUM <=" + maxRow.ToString();

                dtCmb = OracleHelp.ExecuteDataTable(strConn, sql);
                if (dtCmb.Rows.Count > 0)
                {
                    strList = GetCmbDataHelp.GetCmbData(dtCmb, strKey);

                    GetCurrentCmbText();

                    cmbLotId_History.Text = strCurrentLotId_History;
                    cmbProduct_History.Text = strCurrentProduct_History;
                    cmbStage_History.Text = strCurrentStage_History;
                    cmbLayer_History.Text = strCurrentLayer_History;
                    cmbTool_History.Text = strCurrentTool_History;
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }

            return strList;
        }

        private void ShowCmbHistory()
        {
            try
            {
                DataTable dtCmb = new DataTable("dbCmbHistory");
                int maxRow = int.Parse(txtListOfRuns_History.Text.ToString());

                GetTimePeriodValue(ref startTime, ref endTime);

                string sql = "SELECT LOT_ID, PRODUCT, LAYER_OR_STEP, STAGE, TOOL_ID,TIMESTAMP FROM R2R_UI_HISTORY_PROCESS_LOG WHERE ";

                string sqlCmb = GetSql_Dgv();
               
                if (sqlCmb.Equals(""))
                {
                    sql = "SELECT LOT_ID, PRODUCT, LAYER_OR_STEP, STAGE, TOOL_ID,TIMESTAMP FROM R2R_UI_HISTORY_PROCESS_LOG ";
                    sql = string.Format(sql + " WHERE TIMESTAMP >='{0}' AND TIMESTAMP<='{1}'", startTime, endTime);
                }
                else
                {
                    sql += sqlCmb;
                    sql = string.Format(sql + " AND TIMESTAMP >='{0}' AND TIMESTAMP<='{1}'", startTime, endTime);
                }

                string strSort = GetStrSort();
                sql += strSort;

                sql = "SELECT* FROM ( " + sql + ") WHERE ROWNUM <=" + maxRow.ToString();
                dtCmb = OracleHelp.ExecuteDataTable(strConn, sql);
                if (dtCmb.Rows.Count > 0)
                {
                    GetAllCmbHistoryList(dtCmb);
                    GetCurrentCmbText();

                    cmbLotId_History.Text = strCurrentLotId_History;
                    cmbProduct_History.Text = strCurrentProduct_History;
                    cmbStage_History.Text = strCurrentStage_History;
                    cmbLayer_History.Text = strCurrentLayer_History;
                    cmbTool_History.Text = strCurrentTool_History;
                }
                else
                {
                    ClearCmbHistoryList();
                    ClearCmbHistoryDataSource();

                    strListLotId_History.Add(strCurrentLotId_History);
                    strListProduct_History.Add(strCurrentProduct_History);
                    strListStage_History.Add(strCurrentStage_History);
                    strListLayer_History.Add(strCurrentLayer_History);
                    strListTool_History.Add(strCurrentTool_History);
                }

            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }
        #endregion

        #region ShowDgv
        private string  GetStrSort()
        {
            string str = string.Empty;
            if (chkSort.Checked)
            {
                str = " ORDER BY TIMESTAMP DESC";
            }
            else
            {
                str = " ORDER BY TIMESTAMP ASC";
            }
            return str;
        }
        private void ShowContextHistory()
        {
            try
            {
                DataTable dtContext = new DataTable("dbContextHistory");
                int maxRow = int.Parse(txtListOfRuns_History.Text.ToString());

                GetTimePeriodValue(ref startTime, ref endTime);

                string sql = "SELECT LOT_ID, SERVICEMETHOD, TIMESTAMP, RETCODE, RETMESSAGE FROM R2R_UI_HISTORY_PROCESS_LOG WHERE ";

                string strSort = GetStrSort();
                string sqlCmb = GetSql_Dgv();
                if (sqlCmb.Equals(""))
                {
                    sql = "SELECT LOT_ID, SERVICEMETHOD, TIMESTAMP, RETCODE, RETMESSAGE FROM R2R_UI_HISTORY_PROCESS_LOG ";
                    sql = string.Format(sql + " WHERE TIMESTAMP >='{0}' AND TIMESTAMP<='{1}' ", startTime, endTime);
                }
                else
                {
                    sql += sqlCmb;
                    sql = string.Format(sql + " AND TIMESTAMP >='{0}' AND TIMESTAMP<='{1}' ", startTime, endTime);
                }
                sql += strSort;

                sql = "SELECT* FROM ( " + sql + ") WHERE ROWNUM <=" + maxRow.ToString();
                dtContext = OracleHelp.ExecuteDataTable(strConn, sql);
                dgvContext_History.DataSource = dtContext;
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }


        private void GetBasicInformation()
        {
            List<string> strListBasicInfoValue = new List<string>() { "null", "null", "null", "null", "null", "null", "null", "null" };
            List<string> strListBasicInfoName = new List<string>() { "RECIPE", "R2RMODE_MES", "R2RMODE_E3", "STRATEGYNAME", "MACHINENAME", "ENGINENAME", "TRANSACTIONTAG", "R2R_CONTEXT_GROUP" };

            try
            {
                if (strListHistoryContext.Count == 5)
                {
                    string sqlBasic = GetSql_BasicInformation(strListHistoryContext);
                    int maxRow = int.Parse(txtListOfRuns_History.Text.ToString());

                    GetTimePeriodValue(ref startTime, ref endTime);

                    string sql = string.Format("SELECT * FROM R2R_UI_HISTORY_PROCESS_LOG WHERE TIMESTAMP >='{0}' AND TIMESTAMP<='{1}'", startTime, endTime);

                    string strSort = GetStrSort();
                    sql += strSort;

                    sql = "SELECT* FROM ( " + sql + ") WHERE ROWNUM <=" + maxRow.ToString();

                    dtProcessLog = OracleHelp.ExecuteDataTable(strConn, sql);

                    DataRow[] drArrProcess = dtProcessLog.Select(sqlBasic);//模糊查询（如果的多条件筛选，可以加 and 或 or ）
                    if (drArrProcess.Length > 0)
                    {
                        strListBasicInfoValue.Clear();
                        strListBasicInfoValue.Add(drArrProcess[0]["RECIPE"].ToString());
                        strListBasicInfoValue.Add(drArrProcess[0]["R2RMODE_MES"].ToString());
                        strListBasicInfoValue.Add(drArrProcess[0]["R2RMODE_E3"].ToString());
                        strListBasicInfoValue.Add(drArrProcess[0]["STRATEGYNAME"].ToString());
                        strListBasicInfoValue.Add(drArrProcess[0]["MACHINENAME"].ToString());
                        strListBasicInfoValue.Add(drArrProcess[0]["ENGINENAME"].ToString());
                        strListBasicInfoValue.Add(drArrProcess[0]["TRANSACTIONTAG"].ToString());
                        strListBasicInfoValue.Add(drArrProcess[0]["R2R_CONTEXT_GROUP"].ToString());

                        strProcessLog = drArrProcess[0]["PROCESS_LOG"].ToString();
                        strCalculationLog = drArrProcess[0]["CALCULATION_LOG"].ToString();

                    }

                    DataTable dbBasicInformation = new DataTable("dbBasicInformation");
                    dbBasicInformation = DataTableHelp.CreateHistoryProcessTable(strListBasicInfoName, strListBasicInfoValue);
                    DataGridViewHelp.InitDgvGrid(dgvBasicInformation_History, dbBasicInformation);
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private void GetXmlLog()
        {
            try
            {
                if (strListHistoryContext.Count == 5)
                {
                    int maxRow = int.Parse(txtListOfRuns_History.Text.ToString());

                    GetTimePeriodValue(ref startTime, ref endTime);

                    string sql = string.Format("SELECT * FROM R2R_UI_HISTORY_XML_LOG WHERE TIMESTAMP >='{0}' AND TIMESTAMP<='{1}'", startTime, endTime);

                    string strSort = GetStrSort();
                    sql += strSort;

                    sql = "SELECT* FROM ( " + sql + ") WHERE ROWNUM <=" + maxRow.ToString();

                    dtXmlLog = OracleHelp.ExecuteDataTable(strConn, sql);

                    string sqlXml = GetSql_BasicInformation(strListHistoryContext);
                    DataRow[] drArrXml = dtXmlLog.Select(sqlXml);//模糊查询（如果的多条件筛选，可以加 and 或 or ）

                    if (drArrXml.Length > 0)
                    {
                        strXmlLog = drArrXml[0]["XML_LOG"].ToString();
                        //MessageBox.Show(strXmlLog);
                    }
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private string GetSql_Cmb(string strKey)
        {
            string sql = string.Empty;
            try
            {
                GetCurrentCmbText();

                string strCurrentModule_HistoryTmp = strCurrentModule_History;
                string strCurrentProduct_HistoryTmp = strCurrentProduct_History;
                string strCurrentStage_HistoryTmp = strCurrentStage_History;
                string strCurrentLayer_HistoryTmp = strCurrentLayer_History;
                string strCurrentTool_HistoryTmp = strCurrentTool_History;
                string strCurrentLotId_HistoryTmp = strCurrentLotId_History;

                if (strCurrentModule_HistoryTmp.Equals("*"))
                {
                    strCurrentModule_HistoryTmp = "%";
                }
                if (strCurrentProduct_HistoryTmp.Equals("*"))
                {
                    strCurrentProduct_HistoryTmp = "%";
                }
                if (strCurrentStage_HistoryTmp.Equals("*"))
                {
                    strCurrentStage_HistoryTmp = "%";
                }
                if (strCurrentLayer_HistoryTmp.Equals("*"))
                {
                    strCurrentLayer_HistoryTmp = "%";
                }
                if (strCurrentTool_HistoryTmp.Equals("*"))
                {
                    strCurrentTool_HistoryTmp = "%";
                }
                if (strCurrentLotId_HistoryTmp.Equals("*"))
                {
                    strCurrentLotId_HistoryTmp = "%";
                }


                if (strKey.Equals("PRODUCT"))
                {
                    sql += "AREA LIKE '" + strCurrentModule_HistoryTmp + "' AND STAGE LIKE '" + strCurrentStage_HistoryTmp
                      + "' AND LAYER_OR_STEP LIKE '" + strCurrentLayer_HistoryTmp + "' AND TOOL_ID LIKE '" + strCurrentTool_HistoryTmp + "' AND LOT_ID LIKE '" + strCurrentLotId_HistoryTmp + "'";

                }
                else if (strKey.Equals("STAGE"))
                {
                    sql += "AREA LIKE '" + strCurrentModule_HistoryTmp + "' AND PRODUCT LIKE '" + strCurrentProduct_HistoryTmp 
                        + "' AND LAYER_OR_STEP LIKE '" + strCurrentLayer_HistoryTmp + "' AND TOOL_ID LIKE '" + strCurrentTool_HistoryTmp + "' AND LOT_ID LIKE '" + strCurrentLotId_HistoryTmp + "'";

                }
                else if (strKey.Equals("LAYER_OR_STEP"))
                {
                    sql += "AREA LIKE '" + strCurrentModule_HistoryTmp + "' AND PRODUCT LIKE '" + strCurrentProduct_HistoryTmp + "' AND STAGE LIKE '" + strCurrentStage_HistoryTmp
                       + "' AND TOOL_ID LIKE '" + strCurrentTool_HistoryTmp + "' AND LOT_ID LIKE '" + strCurrentLotId_HistoryTmp + "'";

                }
                else if (strKey.Equals("TOOL_ID"))
                {
                    sql += "AREA LIKE '" + strCurrentModule_HistoryTmp + "' AND PRODUCT LIKE '" + strCurrentProduct_HistoryTmp + "' AND STAGE LIKE '" + strCurrentStage_HistoryTmp
                      + "' AND LAYER_OR_STEP LIKE '" + strCurrentLayer_HistoryTmp + "' AND LOT_ID LIKE '" + strCurrentLotId_HistoryTmp + "'";

                }
                else if (strKey.Equals("LOT_ID"))
                {
                    sql += "AREA LIKE '" + strCurrentModule_HistoryTmp + "' AND PRODUCT LIKE '" + strCurrentProduct_HistoryTmp + "' AND STAGE LIKE '" + strCurrentStage_HistoryTmp
                      + "' AND LAYER_OR_STEP LIKE '" + strCurrentLayer_HistoryTmp + "' AND TOOL_ID LIKE '" + strCurrentTool_HistoryTmp + "'";

                }
                //else
                //{
                //    sql += "AREA LIKE '" + strCurrentModule_HistoryTmp + "' AND PRODUCT LIKE '" + strCurrentProduct_HistoryTmp + "' AND STAGE LIKE '" + strCurrentStage_HistoryTmp
                //            + "' AND LAYER_OR_STEP LIKE '" + strCurrentLayer_HistoryTmp + "' AND TOOL_ID LIKE '" + strCurrentTool_HistoryTmp + "' AND LOT_ID LIKE '" + strCurrentLotId_HistoryTmp + "'";
                //}

            }

            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            //MessageBox.Show(sql);
            return sql;
        }

        private string GetSql_Dgv()
        {
            string sql = string.Empty;
            try
            {
                GetCurrentCmbText();

                string strCurrentModule_HistoryTmp = strCurrentModule_History;
                string strCurrentProduct_HistoryTmp = strCurrentProduct_History;
                string strCurrentStage_HistoryTmp = strCurrentStage_History;
                string strCurrentLayer_HistoryTmp = strCurrentLayer_History;
                string strCurrentTool_HistoryTmp = strCurrentTool_History;
                string strCurrentLotId_HistoryTmp = strCurrentLotId_History;

                if (strCurrentModule_HistoryTmp.Equals("*"))
                {
                    strCurrentModule_HistoryTmp = "%";
                }
                if (strCurrentProduct_HistoryTmp.Equals("*"))
                {
                    strCurrentProduct_HistoryTmp = "%";
                }
                if (strCurrentStage_HistoryTmp.Equals("*"))
                {
                    strCurrentStage_HistoryTmp = "%";
                }
                if (strCurrentLayer_HistoryTmp.Equals("*"))
                {
                    strCurrentLayer_HistoryTmp = "%";
                }
                if (strCurrentTool_HistoryTmp.Equals("*"))
                {
                    strCurrentTool_HistoryTmp = "%";
                }
                if (strCurrentLotId_HistoryTmp.Equals("*"))
                {
                    strCurrentLotId_HistoryTmp = "%";
                }

                sql += "AREA LIKE '" + strCurrentModule_HistoryTmp + "' AND PRODUCT LIKE '" + strCurrentProduct_HistoryTmp + "' AND STAGE LIKE '" + strCurrentStage_HistoryTmp
                        + "' AND LAYER_OR_STEP LIKE '" + strCurrentLayer_HistoryTmp + "' AND TOOL_ID LIKE '" + strCurrentTool_HistoryTmp + "' AND LOT_ID LIKE '" + strCurrentLotId_HistoryTmp + "'";

            }

            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            //MessageBox.Show(sql);
            return sql;
        }

        private string GetSql_BasicInformation(List<string> strListContext)
        {
            string sql = string.Empty;
            List<string> strListHistoryContextTmp = new List<string>(strListContext);
            List<string> strList = new List<string>() { "LOT_ID", "SERVICEMETHOD", "TIMESTAMP" };

            try
            {
                for (int i = 0; i < 3; i++)
                {
                    if (strListContext[i].Equals(""))
                    {
                        strListHistoryContextTmp.RemoveAt(i);
                        strList.RemoveAt(i);
                    }
                    else
                    {
                        sql += strList[i] + "='" + strListHistoryContextTmp[i] + "' AND ";
                    }
                }
                sql = " AND " + sql.TrimEnd("AND ".ToCharArray());

                string sqlTmp = string.Empty;
                sqlTmp = GetSql_Dgv();

                if (sqlTmp.Equals(""))
                {
                    sql = sql.TrimEnd("AND ".ToCharArray());
                }
                else
                {
                    sql = sqlTmp + " " + sql;
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }

            return sql;
        }

        private string GetSql_BasicInformation(string strServiceMethod)
        {
            string sql = string.Empty;
            try
            {
                //sql = GetSql_Dgv();
                if (sql.Equals(""))
                {
                    sql = "SERVICEMETHOD='" + strServiceMethod + "'";
                }
                else
                {
                    sql += " AND SERVICEMETHOD='" + strServiceMethod + "'";
                }

            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }

            return sql;
        }

        private string GetSqlCmdNew(List<string> strListContext)
        {
            string sql = string.Empty;
            List<string> strListHistoryContextTmp = new List<string>(strListContext);
            List<string> strList = new List<string>() { "LOT_ID", "SERVICEMETHOD", "TIMESTAMP", "RETCODE", "RETMESSAGE" };

            try
            {
                for (int i = 0; i < strListContext.Count; i++)
                {
                    if (strListContext[i].Equals(""))
                    {
                        strListHistoryContextTmp.RemoveAt(i);
                        strList.RemoveAt(i);
                    }
                    else
                    {
                        sql += strList[i] + "='" + strListHistoryContextTmp[i] + "' AND ";
                    }
                }
                sql = " AND " + sql.TrimEnd("AND ".ToCharArray());

                string sqlTmp = string.Empty;
                sqlTmp = GetSql_Dgv();

                if (sqlTmp.Equals(""))
                {
                    sql = sql.TrimEnd("AND ".ToCharArray());
                }
                else
                {
                    sql = sqlTmp + " " + sql;
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }

            return sql;
        }
        #endregion

        #region txtListOfRuns_History Event
        int iListOfRuns_History;
        private string strRunCount_History = "20";
        private void txtListOfRuns_History_TextChanged(object sender, EventArgs e)
        {
            try
            {
                bool bIsNumber = false;
                bIsNumber = RegexHelp.IsNumber(txtListOfRuns_History.Text.ToString());
                if (bIsNumber)
                {
                    strRunCount_History = txtListOfRuns_History.Text;   // 将现在textBox的值保存下来
                }
                else
                {
                    txtListOfRuns_History.Text = strRunCount_History;   // textBox内容不变

                    txtListOfRuns_History.SelectionStart = txtListOfRuns_History.Text.Length; // 将光标定位到文本框的最后
                                                                                              //MessageBox.Show("Please input a number!");
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private void txtListOfRuns_History_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)//如果输入的是回车键
            {
                this.btnRun_History_Click(sender, e);//触发button事件
            }
        }
        #endregion

        #region dgvContext_History Event
        List<string> strListHistoryContext = new List<string>();
        private void dgvContext_History_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            bDgvClick = true;
            var dgv = sender as DataGridView;
            try
            {
                ClearTabLogControl_History();

                wbsCalculation_History.DocumentText = "";
                wbsXML_History.DocumentText = "";
                if (e.RowIndex >= 0)
                {
                    DataGridViewHelp.SetDgvRowColor(dgv, e.RowIndex);
                    strListHistoryContext = DataGridViewHelp.GetDgvRowValue(dgv, e.RowIndex);

                    GetBasicInformation();
                    ShowCalculationLog();
                    ShowProcessLog();

                    string strTabName = tabLog_History.SelectedTab.Name;
                    if (strTabName.Equals("tabPageXML"))
                    {
                        GetXmlLog();
                        ShowXMLLog();
                        //this.wbsXML_History.DocumentText = strXmlLog;
                    }
                }
                tabLog_History.Refresh();
                tabLog_History.Update();
                tabLog_History.Show();
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }
        #endregion

        #region tabLog Function
        private void ShowCalculationLog()
        {
            try
            {
                //strCalculationLog = @"&lt;p&gt;The lot type is Pi-Run&lt;/p&gt; &lt;p&gt;For Model Group H1, the R2R mode is Active&lt;/p&gt; &lt;p&gt;For Model Group H1, the R2R mode is Active&lt;/p&gt; &lt;p&gt;For Model Group H1, the R2R mode is Active&lt;/p&gt; &lt;p&gt;For Model Group H1, the R2R mode is Active&lt;/p&gt; &lt;p&gt;For Model Group H1, The R2R model is: -10,0,0,0,0,0,0,0,0,0 0,1,0,0,0,0,0,0,0,0 0,0,1,0,0,0,0,0,0,0 0,0,0,1,0,0,0,0,0,0 0,0,0,0,1,0,0,0,0,0 0,0,0,0,0,1,0,0,0,0 0,0,0,0,0,0,1,0,0,0 0,0,0,0,0,0,0,1,0,0 0,0,0,0,0,0,0,0,1,0 0,0,0,0,0,0,0,0,0,1&lt;/p&gt; &lt;p&gt;For Model Group H1, The R2R model is: -10,0,0,0,0,0,0,0,0,0 0,1,0,0,0,0,0,0,0,0 0,0,1,0,0,0,0,0,0,0 0,0,0,1,0,0,0,0,0,0 0,0,0,0,1,0,0,0,0,0 0,0,0,0,0,1,0,0,0,0 0,0,0,0,0,0,1,0,0,0 0,0,0,0,0,0,0,1,0,0 0,0,0,0,0,0,0,0,1,0 0,0,0,0,0,0,0,0,0,1&lt;/p&gt; &lt;p&gt;For Model Group H1, The R2R model is: -10,0,0,0,0,0,0,0,0,0 0,1,0,0,0,0,0,0,0,0 0,0,1,0,0,0,0,0,0,0 0,0,0,1,0,0,0,0,0,0 0,0,0,0,1,0,0,0,0,0 0,0,0,0,0,1,0,0,0,0 0,0,0,0,0,0,1,0,0,0 0,0,0,0,0,0,0,1,0,0 0,0,0,0,0,0,0,0,1,0 0,0,0,0,0,0,0,0,0,1&lt;/p&gt; &lt;p&gt;For Model Group H1, The R2R model is: -10,0,0,0,0,0,0,0,0,0 0,1,0,0,0,0,0,0,0,0 0,0,1,0,0,0,0,0,0,0 0,0,0,1,0,0,0,0,0,0 0,0,0,0,1,0,0,0,0,0 0,0,0,0,0,1,0,0,0,0 0,0,0,0,0,0,1,0,0,0 0,0,0,0,0,0,0,1,0,0 0,0,0,0,0,0,0,0,1,0 0,0,0,0,0,0,0,0,0,1&lt;/p&gt; &lt;p&gt;For Model Group H1, The life time offsets are: 0,0,0,0,0,0,0,0,0,0&lt;/p&gt; &lt;p&gt;For Model Group H1, The life time offsets are: 0,0,0,0,0,0,0,0,0,0&lt;/p&gt; &lt;p&gt;For Model Group H1, The life time offsets are: 0,0,0,0,0,0,0,0,0,0&lt;/p&gt; &lt;p&gt;For Model Group H1, The life time offsets are: 0,0,0,0,0,0,0,0,0,0&lt;/p&gt; &lt;p&gt;The life time value of channel is &lt;/p&gt; &lt;p&gt;The R2R parameter names are , and the R2R parameter values are &lt;/p&gt; &lt;p&gt;For Model Gorup H1, the state values used for recommended setting calculation are: &lt;/p&gt; &lt;p&gt;For Model Gorup H1, the state values used for recommended setting calculation are: &lt;/p&gt; &lt;p&gt;For Model Gorup H1, the state values used for recommended setting calculation are: &lt;/p&gt; &lt;p&gt;For Model Gorup H1, the state values used for recommended setting calculation are: &lt;/p&gt; ";
                strCalculationLog = HtmlHelp.HtmlDecode(strCalculationLog);
                //strCalculationLog = HtmlHelp.HtmlDecodeTest(strCalculationLog);
                this.wbsCalculation_History.DocumentText = strCalculationLog;

            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private void ShowProcessLog()
        {
            SetBtnProcess();
            ShowDetails();
        }

        private void ShowXMLLog()
        {
            try
            {
                if (strXmlLog.Equals(""))
                {
                    //string strXmlPath = Environment.CurrentDirectory + "\\xmlLogTmp.xml";
                    //System.Xml.XmlDocument doc = new System.Xml.XmlDocument();//新建对象
                    //doc.Load(strXmlPath);//XML文件路径

                    //string strXml = doc.InnerXml;
                    //this.wbsXML_History.DocumentText = strXml;

                    ////wbsXML_History.Document.ExecCommand("Refresh", false, "");

                    MessageBox.Show("Xml is null");
                }
                else
                {
                    #region
                    XmlDocument xDoc = new XmlDocument();
                    xDoc.Load(Environment.CurrentDirectory + "\\defaultss.xslt");
                    string strXslt = xDoc.InnerXml;

                    MSXML2.DOMDocument xml = new MSXML2.DOMDocument();        //Xml对象
                    MSXML2.DOMDocument xslt = new MSXML2.DOMDocument();       //Xslt对象    
                    xml.loadXML(strXmlLog);                                                        //读取Xml字符串
                    xslt.loadXML(strXslt);                                                       //读取Xslt字符串

                    this.wbsXML_History.DocumentText = xml.transformNode(xslt);                //将转换的html字符串赋给WebBrowser控件
                    #endregion

                    #region
                    //System.Xml.XmlDocument doc = new System.Xml.XmlDocument();//新建对象
                    //doc.LoadXml(strXmlLog);

                    //string strXml = doc.InnerXml;
                    //this.wbsXML_History.DocumentText = strXml;
                    #endregion
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private void SetBtnProcess()
        {
            try
            {
                bool flag = false;
                if (strListHistoryContext.Count == 5 && strListHistoryContext[3].Equals("0"))
                {
                    flag = true;
                }
                if (flag)
                {
                    btnProcess_History.BackColor = Color.GreenYellow;
                    btnProcess_History.Text = "Success";
                }
                else
                {
                    btnProcess_History.BackColor = Color.Firebrick;
                    btnProcess_History.Text = "Error: There is missing set-point data";
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private void ShowTreeView(List<string> strList)
        {
            try
            {
                tvwDetails.Nodes.Clear();
                NodeLastSelected = null;
                List<TreeNode> strListTreeNode = new List<TreeNode>();
                foreach (var str in strList)
                {
                    TreeNode treeNodeTmp = new TreeNode(str);
                    treeNodeTmp.Text = str;
                    treeNodeTmp.Name = str;
                    strListTreeNode.Add(treeNodeTmp);
                }
                if (strListTreeNode.Count > 0)
                {
                    TreeNode treeNode = new TreeNode("InstanceId", strListTreeNode.ToArray());
                    treeNode.Text = "InstanceId";
                    treeNode.Name = "InstanceId";
                    tvwDetails.Nodes.Add(treeNode);
                }
                if (tvwDetails.Nodes.Count > 0)
                {
                    NodeLastSelected = tvwDetails.Nodes[0].Nodes[0];
                    NodeLastSelected.BackColor = Color.Blue;
                    tvwDetails.ExpandAll();
                    tvwDetails.SelectedNode = NodeLastSelected;
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        struct structDetailsData
        {
            public string strInputLbl;
            public string strOutputLbl;
            public DataTable dbInput;
            public DataTable dbOutput;
        };

        Hashtable ht = new Hashtable();
        private int GetStrCount(List<string> strList, string strKey)
        {
            int n = 0;
            try
            {
                if (strList.Contains(strKey))
                {
                    foreach (var str in strList)
                    {
                        if (str.Equals(strKey))
                        {
                            n++;
                        }
                    }
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            return n;
        }

        private void ShowDetails()
        {
            #region TreeView
            try
            {
                //XmlDocument doc = new XmlDocument();//新建对象
                //doc.Load(@"C:\Users\XNi160297\Desktop\testStruct2.xml");//XML文件路径
                //strProcessLog = doc.InnerXml;

                if (ht.Count > 0)
                {
                    ht.Clear();
                }
                if (strProcessLog.Equals(""))
                {

                }
                else
                {
                    List<string> strListInstanceId = new List<string>();
                    List<string> strListInstanceIdTmp = new List<string>();

                    List<structKeyBlockDataSerialize> structListKeyBlockDataAll = new List<structKeyBlockDataSerialize>();
                    structListKeyBlockDataAll = XmlSerializeHelp.Deserialize(typeof(List<structKeyBlockDataSerialize>), strProcessLog) as List<structKeyBlockDataSerialize>;

                    foreach (structKeyBlockDataSerialize structData in structListKeyBlockDataAll)
                    {
                        if (structData.OutputId.Equals(""))
                        {
                        }
                        else
                        {
                            structDetailsData structDataValue = new structDetailsData();

                            structDataValue.strInputLbl = "Input";
                            structDataValue.strOutputLbl = structData.OutputId;

                            structDataValue.dbInput = DataTableHelp.CreateHistoryProcessTable(structData.InputName, structData.InputValue);
                            structDataValue.dbOutput = DataTableHelp.CreateHistoryProcessTable(structData.OutputName, structData.OutputValue);

                            #region 
                            //string strInstanceId ="<" + structData.SubStrategyName+">/<"+structData.KeyBlockInstanceId+">";  // no need show strategy name, marked by yang 2019/3/5
                            string strInstanceId = structData.KeyBlockInstanceId;
                            string strInstanceIdTmp = strInstanceId;
                            if (strListInstanceIdTmp.Contains(strInstanceId))
                            {
                                int n = GetStrCount(strListInstanceIdTmp, strInstanceId);
                                if (n != 0)
                                {
                                    strInstanceIdTmp += "-" + n;
                                }
                            }
                            strListInstanceIdTmp.Add(strInstanceId);
                            ht.Add(strInstanceIdTmp, structDataValue);
                            strListInstanceId.Add(strInstanceIdTmp);
                            #endregion
                        }
                    }
                    if (strListInstanceId.Count > 0)
                    {
                        ShowTreeView(strListInstanceId);
                    }
                }

            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            #endregion
        }

        public void NavigateToUrl(string url)
        {
            this.wbsCalculation_History.Navigate(url);
        }
        public void ShowHTMLStr(string strHTML)
        {
            this.wbsCalculation_History.DocumentText = strHTML;
        }
        #endregion

        #region Btn Event
        private void btnRun_History_Click(object sender, EventArgs e)
        {
            ClearControl_History();

            ShowContextHistory();
            dgvContext_History.ReadOnly = true;
        }

        private void btnProcess_History_Click(object sender, EventArgs e)
        {

        }

        private void btnXML_History_Click(object sender, EventArgs e)
        {
            if (strListModule.Count() <= 1)  //added by yang 2019/3/21 deny resend
            {
                MessageBox.Show("you have no access to resend msg", "Deny");
                return;
            }
            frmCheckedPwd frmChecked = new frmCheckedPwd(strUserName);
            if (frmChecked.ShowDialog() == DialogResult.OK)
            {
                if (frmChecked.strPassword.Equals(strPassword))
                {
                    #region
                    try
                    {
                        #region
                        if (strXmlLog.Equals(""))
                        {
                            MessageBox.Show("Xml is null");
                        }
                        else
                        {
                            bool bIsXml = XmlHelp.IsXmlString(strXmlLog);
                            if (bIsXml)
                            {
                                List<string> strList = new List<string>();
                                strList = ResendXmlHelp.GetResendXmlConfig();
                                if (strList.Count == 4)
                                {
                                    strService = strList[0];
                                    strNetwork = strList[1];
                                    strDaemon = strList[2];
                                    strTargetSubject = strList[3];
                                    ResendXmlHelp.ReSendXml(strService, strNetwork, strDaemon, strTargetSubject, strXmlLog);
                                }
                            }
                            else
                            {
                                MessageBox.Show("Invalid xml format!");
                            }

                        }
                        #endregion

                        #region
                        //string strXml = wbsXML_History.Document.Body.InnerText;
                        //bool bIsXml = XmlHelp.IsXmlString(strXml);
                        //if (bIsXml)
                        //{
                        //    List<string> strList = new List<string>();
                        //    strList = GetResendXmlConfig();
                        //    if (strList.Count == 4)
                        //    {
                        //        strService = strList[0];
                        //        strNetwork = strList[1];
                        //        strDaemon = strList[2];
                        //        strTargetSubject = strList[3];
                        //        ResendXmlHelp.ReSendXml(strService, strNetwork, strDaemon, strTargetSubject, strXml);
                        //    }

                        //}
                        //else
                        //{
                        //    MessageBox.Show("Invalid xml format!");
                        //}
                        #endregion
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show(BaseFun.GetExceptionInformation(err));
                    }
                    #endregion
                }
                else
                {
                    MessageBox.Show("Invalid password!");
                }
            }
            else
            {
                //MessageBox.Show("Invalid password!");
            }
        }
        #endregion

        #region tabLog_History
        private void tabLog_History_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string strTabName = tabLog_History.SelectedTab.Name;
                switch (strTabName)
                {
                    case "tabPageCalculation":

                        break;
                    case "tabPageProcess":

                        break;
                    case "tabPageXML":
                        GetXmlLog();
                        ShowXMLLog();
                        break;
                    default:
                        break;
                }
                //tabLog_History.Refresh();
                //tabLog_History.Update();
                //tabLog_History.Show();
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }
        #endregion

        #region wbsXML_History Event
        private void wbsXML_History_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            //try
            //{
            //    if (this.wbsXML_History.Document != null)
            //    {
            //        //使内容可编辑
            //        IHTMLDocument2 doc = wbsXML_History.Document.DomDocument as IHTMLDocument2;
            //        if (doc != null)
            //        {
            //            doc.designMode = "on";
            //        }
            //    }
            //}
            //catch (Exception err)
            //{
            //    MessageBox.Show(BaseFun.GetExceptionInformation(err));
            //}
        }

        private void wbsCalculation_History_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            //var wbs = sender as WebBrowser;
            //wbs.Refresh();
            ////设置webBrowser 
            //wbs.ScriptErrorsSuppressed = true; //禁用错误脚本提示   
            //wbs.IsWebBrowserContextMenuEnabled = false; //禁用右键菜单   
            //wbs.WebBrowserShortcutsEnabled = false; //禁用快捷键  
            //wbs.AllowWebBrowserDrop = false;//禁止拖拽
            //wbs.ScrollBarsEnabled = false;//禁止滚动条
        }
        #endregion

        #region cmbContext_History Event
        string strCurrentModule_History = "LITHO";
        string strCurrentProduct_History;
        string strCurrentStage_History;
        string strCurrentLayer_History;
        string strCurrentTool_History;
        string strCurrentLotId_History;

        List<string> strListModule_History = new List<string>();
        List<string> strListProduct_History = new List<string>();
        List<string> strListStage_History = new List<string>();// { "*" };
        List<string> strListLayer_History = new List<string>();
        List<string> strListTool_History = new List<string>();
        List<string> strListLotId_History = new List<string>();

        private void ClearCmbHistoryDataSource()
        {
            cmbLotId_History.DataSource = null;
            //cmbModule_History.DataSource = null;
            cmbProduct_History.DataSource = null;
            cmbStage_History.DataSource = null;
            cmbLayer_History.DataSource = null;
            cmbTool_History.DataSource = null;
        }

        private void ClearCmbText()
        {
            cmbLotId_History.Text = "";
            cmbProduct_History.Text = "";
            cmbStage_History.Text = "";
            cmbLayer_History.Text = "";
            cmbTool_History.Text = "";
        }

        private void GetCurrentCmbText()
        {
            strCurrentModule_History = cmbModule_History.Text.ToString();
            strCurrentProduct_History = cmbProduct_History.Text.ToString();
            strCurrentStage_History = cmbStage_History.Text.ToString();
            strCurrentLayer_History = cmbLayer_History.Text.ToString();
            strCurrentTool_History = cmbTool_History.Text.ToString();
            strCurrentLotId_History = cmbLotId_History.Text.ToString();
        }

        private void SetCmbDataSource()
        {
            cmbLotId_History.DataSource = strListLotId_History;
            cmbModule_History.DataSource = strListModule_History;
            cmbProduct_History.DataSource = strListProduct_History;
            cmbStage_History.DataSource = strListStage_History;
            cmbLayer_History.DataSource = strListLayer_History;
            cmbTool_History.DataSource = strListTool_History;
        }
        #endregion

        #region TreeView Details
        private void tvwDetails_AfterSelect(object sender, TreeViewEventArgs e)
        {
            try
            {
                NodeLastSelected.BackColor = e.Node.BackColor;
                if (ht.Count > 0)
                {
                    TreeNode node = e.Node;
                    string htKey = node.Text.ToString();

                    if (ht.ContainsKey(htKey))
                    {
                        structDetailsData structDataValue = new structDetailsData();
                        structDataValue = (structDetailsData)ht[htKey];

                        //panDetailsDgv.Controls.Clear();//清空panel
                        //panDetailsDgv.AutoScroll = true;
                        // AddControlHelp.AddControlToTabPanel(panDetailsDgv, structDataValue.strInputLbl, structDataValue.strOutputLbl, structDataValue.dbInput, structDataValue.dbOutput);
                        splitContainer2.Panel1.Controls.Clear();
                        splitContainer2.Panel2.Controls.Clear();
                        AddControlHelp.AddDgvAndLbelToTabPanel(splitContainer2.Panel1, structDataValue.strInputLbl, structDataValue.dbInput);
                        AddControlHelp.AddDgvAndLbelToTabPanel(splitContainer2.Panel2, structDataValue.strOutputLbl, structDataValue.dbOutput);
                    }
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }
        TreeNode NodeLastSelected = null;
        private void tvwDetails_BeforeCollapse(object sender, TreeViewCancelEventArgs e)
        {
            try
            {
                if (tvwDetails.SelectedNode != null)
                {
                    NodeLastSelected = tvwDetails.SelectedNode;
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private void tvwDetails_AfterExpand(object sender, TreeViewEventArgs e)
        {
            try
            {
                if (NodeLastSelected != null)
                {
                    tvwDetails.SelectedNode = NodeLastSelected;
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }
        #endregion
    }
}
