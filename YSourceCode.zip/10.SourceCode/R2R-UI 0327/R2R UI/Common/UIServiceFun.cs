﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI.Common
{
    public class UIServiceFun
    {
        #region Context
        public static List<string> R2R_UI_GetModule(string userName, ref string serviceName)
        {
            int i = 0;
            int n = 0;int length = 0;

            List<string> strListModule = new List<string>();
            UIService.ReplyModuleSchema rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length; 
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestModuleSchema rq = new UIService.RequestModuleSchema();
                        rq.UserName = userName;
                        rq.ClientMachine = System.Environment.MachineName;

                        rly = cfg.R2R_UI_GetModules(rq);
                        if (rly.Success)
                        {
                            strListModule = new List<string>(rly.Modules);
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return strListModule;
        }

        public static List<string> R2R_UI_GetProduct(string userName, ref string serviceName, string strModule)
        {
            int i = 0;
            int n = 0;int length = 0;

            List<string> strListProduct = new List<string>();
            UIService.ReplyProductSchema rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestProductSchema rq = new UIService.RequestProductSchema();
                        rq.UserName = userName;
                        rq.Module = strModule;
                        rq.ClientMachine = System.Environment.MachineName;

                        rly = cfg.R2R_UI_GetProduct(rq);
                        if (rly.Success)
                        {
                            strListProduct = new List<string>(rly.Product);
                            if (strListProduct.Count == 1)
                            {
                                if (strListProduct[0] == "")
                                {
                                    strListProduct[0] = "*";
                                }
                            }
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return strListProduct;
        }

        public static List<string> R2R_UI_GetStage(string userName, ref string serviceName, string strModule, string strProduct)
        {
            int i = 0;
            int n = 0;int length = 0;

            List<string> strListStage = new List<string>();
            UIService.ReplyStageSchema rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestStageSchema rq = new UIService.RequestStageSchema();
                        rq.UserName = userName;
                        rq.Module = strModule;
                        if (strProduct.Equals("*"))
                        {
                            strProduct = "%";
                        }
                        rq.Product = strProduct;
                        rq.ClientMachine = System.Environment.MachineName;

                        rly = cfg.R2R_UI_GetStage(rq);
                        if (rly.Success)
                        {
                            strListStage = new List<string>(rly.Stage);
                            if (strListStage.Count == 1)
                            {
                                if (strListStage[0] == "")
                                {
                                    strListStage[0] = "*";
                                }
                            }
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }

            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return strListStage;
        }

        public delegate UIService.ReplyLayerSchema DelegateGetLayer(UIService.RequestLayerSchema rq);//定义个代理 

        public static List<string> R2R_UI_GetLayerOrStep(string userName, ref string serviceName, string strModule, string strProduct, string strStage)
        {
            int i = 0;
            int n = 0;int length = 0;

            List<string> strListLayer = new List<string>();
            UIService.ReplyLayerSchema rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestLayerSchema rq = new UIService.RequestLayerSchema();
                        rq.UserName = userName;
                        rq.Module = strModule;
                        if (strProduct.Equals("*"))
                        {
                            strProduct = "%";
                        }
                        rq.Product = strProduct;
                        if (strStage.Equals("*"))
                        {
                            strStage = "%";
                        }
                        rq.Stage = strStage;
                        rq.ClientMachine = System.Environment.MachineName;

                        //DelegateGetLayer fun = new DelegateGetLayer(cfg.R2R_UI_GetLayerOrStep);
                        //IAsyncResult result = fun.BeginInvoke(rq, null, null);
                        //WaitHandle waitHandle = result.AsyncWaitHandle;
                        //waitHandle.WaitOne();
                        //rly = fun.EndInvoke(result);//用于接收返回值 

                        rly = cfg.R2R_UI_GetLayerOrStep(rq);
                        if (rly.Success)
                        {
                            strListLayer = new List<string>(rly.Layer);
                            if (strListLayer.Count == 1)
                            {
                                if (strListLayer[0] == "")
                                {
                                    strListLayer[0] = "*";
                                }
                            }
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return strListLayer;
        }

        public static List<string> R2R_UI_GetController(string userName, ref string serviceName, string strModule, string strProduct, string strStage, string strLayer)
        {
            int i = 0;
            int n = 0;int length = 0;

            List<string> strListControlSys = new List<string>();
            UIService.ReplyCntrlSchema rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestCntrlSchema rq = new UIService.RequestCntrlSchema();
                        rq.UserName = userName;
                        rq.Module = strModule;
                        if (strProduct.Equals("*"))
                        {
                            strProduct = "%";
                        }
                        rq.Product = strProduct;
                        if (strStage.Equals("*"))
                        {
                            strStage = "%";
                        }
                        rq.Stage = strStage;
                        if (strLayer.Equals("*"))
                        {
                            strLayer = "%";
                        }
                        rq.StepOrLayer = strLayer;
                        rq.ClientMachine = System.Environment.MachineName;

                        rly = cfg.R2R_UI_GetController(rq);
                        if (rly.Success)
                        {
                            strListControlSys = new List<string>(rly.Controller);
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return strListControlSys;
        }

        public static List<string> R2R_UI_GetTool(string userName, ref string serviceName, string strModule, string strProduct, string strStage, string strLayer, string strController)
        {
            int i = 0;
            int n = 0;int length = 0;

            List<string> strListTool = new List<string>();
            UIService.ReplyLithoToolSchema rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestLithoToolSchema rq = new UIService.RequestLithoToolSchema();
                        rq.UserName = userName;
                        rq.Module = strModule;
                        if (strProduct.Equals("*"))
                        {
                            strProduct = "%";
                        }
                        rq.Product = strProduct;
                        if (strStage.Equals("*"))
                        {
                            strStage = "%";
                        }
                        rq.Stage = strStage;
                        if (strLayer.Equals("*"))
                        {
                            strLayer = "%";
                        }
                        rq.Layer = strLayer;
                        rq.Controller = strController;
                        rq.ClientMachine = System.Environment.MachineName;

                        rly = cfg.R2R_UI_GetTools(rq);
                        if (rly.Success)
                        {
                            strListTool = new List<string>(rly.Tool);
                            if (strListTool.Count == 1)
                            {
                                if (strListTool[0] == "")
                                {
                                    strListTool[0] = "*";
                                }
                            }
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return strListTool;
        }
        #endregion

        #region R2R_UI_GetR2RContext
        public struct structDataContext
        {
            public List<int> iListIndex;
            public List<string> strListContexts;
            public List<string> strListData_Context1;
            public List<string> strListData_Context2;
            public List<string> strListData_Context3;
            public List<string> strListData_Context4;
            public List<string> strListData_Context5;
            public List<string> strListData_Context6;
            public List<string> strListData_Context7;
            public List<string> strListData_Context8;
            public List<string> strListData_Context9;
            public List<string> strListData_Context10;
            public List<string> strListData_Context11;
            public List<string> strListData_Context12;
            public List<string> strListData_Context13;
            public List<string> strListData_Context14;
            public List<string> strListData_Context15;
            public List<string> strListData_Context16;
            public List<string> strListData_Context17;
            public List<string> strListData_Context18;
            public List<string> strListData_Context19;
            public List<string> strListData_Context20;
        };

        public struct structGetR2RContext
        {
            public List<string> strListChuckIds;
            public List<string> strListUsedTimeStamps;
            public structDataContext structContext;
        };

        public static structGetR2RContext R2R_UI_GetR2RContext(ref string serviceName, string strProduct, string strLayer, string strController, string strTool, int iRunCount)
        {
            int i = 0;
            int n = 0;int length = 0;

            structGetR2RContext structData = new structGetR2RContext();
            structDataContext structContext = new structDataContext();

            UIService.ReplySchema_R2R_UI_GetR2RContext rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_GetR2RContext rq = new UIService.RequestSchema_R2R_UI_GetR2RContext();

                        if (strProduct.Equals("*"))
                        {
                            strProduct = "%";
                        }
                        rq.Product = strProduct;

                        if (strLayer.Equals("*"))
                        {
                            strLayer = "%";
                        }
                        rq.LayerOrStep = strLayer;
                        rq.Controller = strController;
                        rq.ToolId = strTool;
                        rq.RunCount = iRunCount;

                        rly = cfg.R2R_UI_GetR2RContext(rq);

                        if (rly.Success)
                        {
                            structData.strListChuckIds = new List<string>(rly.ChuckIds);
                            structData.strListUsedTimeStamps = new List<string>(rly.UsedTimeStamps);

                            structContext.iListIndex = new List<int>(rly.Index);
                            structContext.strListContexts = new List<string>(rly.Contexts);
                            structContext.strListData_Context1 = new List<string>(rly.Data_Context1);
                            structContext.strListData_Context2 = new List<string>(rly.Data_Context2);
                            structContext.strListData_Context3 = new List<string>(rly.Data_Context3);
                            structContext.strListData_Context4 = new List<string>(rly.Data_Context4);
                            structContext.strListData_Context5 = new List<string>(rly.Data_Context5);
                            structContext.strListData_Context6 = new List<string>(rly.Data_Context6);
                            structContext.strListData_Context7 = new List<string>(rly.Data_Context7);
                            structContext.strListData_Context8 = new List<string>(rly.Data_Context8);
                            structContext.strListData_Context9 = new List<string>(rly.Data_Context9);
                            structContext.strListData_Context10 = new List<string>(rly.Data_Context10);
                            structContext.strListData_Context11 = new List<string>(rly.Data_Context11);
                            structContext.strListData_Context12 = new List<string>(rly.Data_Context12);
                            structContext.strListData_Context13 = new List<string>(rly.Data_Context13);
                            structContext.strListData_Context14 = new List<string>(rly.Data_Context14);
                            structContext.strListData_Context15 = new List<string>(rly.Data_Context15);
                            structContext.strListData_Context16 = new List<string>(rly.Data_Context16);
                            structContext.strListData_Context17 = new List<string>(rly.Data_Context17);
                            structContext.strListData_Context18 = new List<string>(rly.Data_Context18);
                            structContext.strListData_Context19 = new List<string>(rly.Data_Context19);
                            structContext.strListData_Context20 = new List<string>(rly.Data_Context20);

                            structData.structContext = structContext;

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }

            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }
        #endregion

        #region R2R_UI_OVLMode
        public struct structOVLMode
        {
            public List<string> strListAlignmentReticle;
            public List<string> strListAlignmentTool;
            public List<string> strListChuck;
            public List<string> strListLayer;
            public List<string> strListPreAreaTool;
            public List<string> strListPreLayerCPEModel;
            public List<string> strListPreLayerHOPEModel;
            public List<string> strListPreLayerIHOPEModel;
            public List<string> strListPreLayerReticle;
            public List<string> strListPreLayerTool;
            public List<string> strListPreLayerToolPMTime;
            public List<string> strListReticle;
            public List<string> strListRunTimeCTXs;
            //public structOVLModeContexts structContexts;
            public List<string> strListCPEModelName;
            public List<string> strListCPEModelUpdateTimestamp;
            public List<string> strListCurrentValueTimestamp;
            public List<string> strListModelUpdateTimestamp;
            public List<string> strListOVL_Model;
            public List<string> strListPM_Timestamp;
            public List<bool> bListIsActiveRunOn;
        };

        public static structOVLMode R2R_UI_OVLMode(string userName, ref string serviceName, string strProduct, string strStage, string strLayer, string strController, string strTool)
        {
            int i = 0;
            int n = 0;int length = 0;

            structOVLMode structData = new structOVLMode();

            UIService.ReplyOVLModeSchema rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestOVLModeSchema rq = new UIService.RequestOVLModeSchema();
                        rq.UserName = userName;
                        if (strProduct.Equals("*"))
                        {
                            strProduct = "%";
                        }
                        rq.Product = strProduct;
                        if (strStage.Equals("*"))
                        {
                            strStage = "%";
                        }
                        rq.Stage = strStage;
                        if (strLayer.Equals("*"))
                        {
                            strLayer = "%";
                        }
                        rq.Layer = strLayer;
                        rq.Controller = strController;
                        rq.Tool = strTool;
                        rq.ClientMachine = System.Environment.MachineName;

                        rly = cfg.R2R_UI_GetOVLMode(rq);
                        if (rly.Success)
                        {
                            structData.strListAlignmentReticle = new List<string>(rly.Contexts.AlignmentReticle);
                            structData.strListAlignmentTool = new List<string>(rly.Contexts.AlignmentTool);
                            structData.strListChuck = new List<string>(rly.Contexts.Chuck);
                            structData.strListLayer = new List<string>(rly.Contexts.Layer);
                            structData.strListPreAreaTool = new List<string>(rly.Contexts.PreAreaTool);
                            structData.strListPreLayerCPEModel = new List<string>(rly.Contexts.PreLayerCPEModel);
                            structData.strListPreLayerHOPEModel = new List<string>(rly.Contexts.PreLayerHOPEModel);
                            structData.strListPreLayerIHOPEModel = new List<string>(rly.Contexts.PreLayerIHOPEModel);
                            structData.strListPreLayerReticle = new List<string>(rly.Contexts.PreLayerReticle);
                            structData.strListPreLayerTool = new List<string>(rly.Contexts.PreLayerTool);
                            structData.strListPreLayerToolPMTime = new List<string>(rly.Contexts.PreLayerToolPMTime);
                            structData.strListReticle = new List<string>(rly.Contexts.Reticle);
                            structData.strListRunTimeCTXs = new List<string>(rly.Contexts.RunTimeCTXs);

                            structData.strListCPEModelName = new List<string>(rly.CPEModelName);
                            structData.strListCPEModelUpdateTimestamp = new List<string>(rly.CPEModelUpdateTimestamp);
                            structData.strListCurrentValueTimestamp = new List<string>(rly.CurrentValueTimestamp);
                            structData.strListModelUpdateTimestamp = new List<string>(rly.ModelUpdateTimestamp);
                            structData.strListOVL_Model = new List<string>(rly.OVL_Model);
                            structData.strListPM_Timestamp = new List<string>(rly.PM_Timestamp);
                            structData.bListIsActiveRunOn = new List<bool>(rly.IsActiveRunOn);

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        #endregion

        #region R2R_UI_PH_OVL
        public struct structPH_OVL_GetLotRunHistory
        {
            public int iHOPC_OutputSize;
            public string strHOPC_PMTimeStamp;
            public string strHOPC_ResetTimeStamp;
            public List<string> strListHOPC_IsValidRecords;
            public List<string> strListHOPC_ItemValues_UsedSettings;
            public List<string> strListHOPC_ItemNames_PostMetrology;
            public List<string> strListHOPC_ItemValues_PostMetrology;
            public List<string> strListHOPC_LotIds;
            public List<string> strListHOPC_UsedTimeStamps;

            public int iIHOPC_OutputSize;
            public string strIHOPC_PMTimeStamp;
            public string strIHOPC_ResetTimeStamp;
            public List<string> strListIHOPC_IsValidRecords;
            public List<string> strListIHOPC_ItemValues_UsedSettings;
            public List<string> strListIHOPC_ItemNames_PostMetrology;
            public List<string> strListIHOPC_ItemValues_PostMetrology;
            public List<string> strListIHOPC_LotIds;
            public List<string> strListIHOPC_UsedTimeStamps;

            public int iLinear_OutputSize;
            public string strLinear_PMTimeStamp;
            public string strLinear_ResetTimeStamp;
            public List<string> strListLinear_IsValidRecords;
            public List<string> strListLinear_ItemValues_UsedSettings;
            public List<string> strListLinear_ItemNames_PostMetrology;
            public List<string> strListLinear_ItemValues_PostMetrology;
            public List<string> strListLinear_LotIds;
            public List<string> strListLinear_UsedTimeStamps;

            public string strToolVendor;
            public string strCurrentOVLModel;
            public string strCurrentR2RMode;

            public bool bCPEMode;
            public bool bHOPCMode;
            public bool bIHOPCMode;
            public bool bLinearMode;
            public bool bForcePilot;
        };
        public static structPH_OVL_GetLotRunHistory R2R_UI_PH_OVL_GetLotRunHistory(ref string serviceName, string strController, List<string> strListR2RContexts, int iListOfRuns)
        {
            int i = 0;
            int n = 0;int length = 0;

            structPH_OVL_GetLotRunHistory structData = new structPH_OVL_GetLotRunHistory();
            UIService.ReplySchema_R2R_UI_PH_OVL_GetLotRunHistory rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_GetLotRunHistory rq = new UIService.RequestSchema_R2R_UI_PH_OVL_GetLotRunHistory();

                        rq.Controller = strController;
                        rq.R2RContexts = strListR2RContexts.ToArray();
                        rq.ListOfRuns = iListOfRuns;

                        rly = cfg.R2R_UI_PH_OVL_GetLotRunHistory(rq);

                        if (rly.Success)
                        {
                            structData.strHOPC_PMTimeStamp = rly.HOPC_PMTimeStamp;
                            structData.strHOPC_ResetTimeStamp = rly.HOPC_ResetTimeStamp;
                            structData.strListHOPC_IsValidRecords = new List<string>(rly.HOPC_IsValidRecords);
                            structData.strListHOPC_ItemValues_UsedSettings = new List<string>(rly.HOPC_ItemValues_UsedSettings);
                            structData.strListHOPC_ItemNames_PostMetrology = new List<string>(rly.HOPC_ItemNames_PostMetrology);
                            structData.strListHOPC_ItemValues_PostMetrology = new List<string>(rly.HOPC_ItemValues_PostMetrology);
                            structData.strListHOPC_LotIds = new List<string>(rly.HOPC_LotIds);

                            structData.strIHOPC_PMTimeStamp = rly.iHOPC_PMTimeStamp;
                            structData.strIHOPC_ResetTimeStamp = rly.iHOPC_ResetTimeStamp;
                            structData.strListIHOPC_IsValidRecords = new List<string>(rly.iHOPC_IsValidRecords);
                            structData.strListIHOPC_ItemValues_UsedSettings = new List<string>(rly.iHOPC_ItemValues_UsedSettings);
                            structData.iHOPC_OutputSize = rly.HOPC_OutputSize;
                            structData.strListHOPC_UsedTimeStamps = new List<string>(rly.HOPC_UsedTimeStamps);
                            structData.strListIHOPC_ItemNames_PostMetrology = new List<string>(rly.iHOPC_ItemNames_PostMetrology);
                            structData.strListIHOPC_ItemValues_PostMetrology = new List<string>(rly.iHOPC_ItemValues_PostMetrology);
                            structData.strListIHOPC_LotIds = new List<string>(rly.iHOPC_LotIds);
                            structData.iIHOPC_OutputSize = rly.iHOPC_OutputSize;
                            structData.strListIHOPC_UsedTimeStamps = new List<string>(rly.iHOPC_UsedTimeStamps);

                            structData.strLinear_PMTimeStamp = rly.Linear_PMTimeStamp;
                            structData.strLinear_ResetTimeStamp = rly.Linear_ResetTimeStamp;
                            structData.strListLinear_IsValidRecords = new List<string>(rly.Linear_IsValidRecords);
                            structData.strListLinear_ItemValues_UsedSettings = new List<string>(rly.Linear_ItemValues_UsedSettings);
                            structData.strListLinear_ItemNames_PostMetrology = new List<string>(rly.Linear_ItemNames_PostMetrology);
                            structData.strListLinear_ItemValues_PostMetrology = new List<string>(rly.Linear_ItemValues_PostMetrology);
                            structData.strListLinear_LotIds = new List<string>(rly.Linear_LotIds);
                            structData.iLinear_OutputSize = rly.Linear_OutputSize;
                            structData.strListLinear_UsedTimeStamps = new List<string>(rly.Linear_UsedTimeStamps);
                            structData.strToolVendor = rly.ToolVendor;
                            structData.strCurrentOVLModel = rly.CurrentOVLModel;
                            structData.strCurrentR2RMode = rly.CurrentR2RMode;

                            structData.bCPEMode = rly.CPEMode;
                            structData.bHOPCMode = rly.HOPCMode;
                            structData.bIHOPCMode = rly.iHOPCMode;
                            structData.bLinearMode = rly.LinearMode;
                            structData.bForcePilot = rly.ForcePilot;

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        public static bool R2R_UI_PH_OVL_UpdatePilotFlag(ref string serviceName, string strUserName, string strController, List<string> strListR2RContexts, bool bForcePilot)
        {
            int i = 0;
            int n = 0;int length = 0;

            bool bSuccess = false;
            UIService.ReplySchema_R2R_UI_PH_OVL_UpdatePilotFlag rly = null;
            try
            {
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_UpdatePilotFlag rq = new UIService.RequestSchema_R2R_UI_PH_OVL_UpdatePilotFlag();

                        rq.UserName = strUserName;
                        rq.Controller = strController;
                        rq.R2RContexts = strListR2RContexts.ToArray();
                        rq.ForcePilot = bForcePilot;

                        rly = cfg.R2R_UI_PH_OVL_UpdatePilotFlag(rq);
                        if (rly.Success)
                        {
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return bSuccess;
        }

        public struct structPH_OVL_GetResetModel
        {
            public List<int> iListInputIndex;
            public List<double> dListInputMax;
            public List<double> dListInputMin;
            public List<double> dListInputValues;
            public List<string> strListChuckIds;
            public List<string> strListInputNames;
            public string strOVLModel;
        };

        public static bool R2R_UI_PH_OVL_ResetModel(ref string serviceName, string strUserName, string strController, List<string> strListR2RContexts, string strCurrentOVLModel, string strCurrentR2RMode, structPH_OVL_GetResetModel structData)
        {
            int i = 0;
            int n = 0;int length = 0;

            bool bSuccess = false;
            UIService.ReplySchema_R2R_UI_PH_OVL_ResetModel rly = null;
            try
            {
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_ResetModel rq = new UIService.RequestSchema_R2R_UI_PH_OVL_ResetModel();

                        rq.UserName = strUserName;
                        rq.Controller = strController;
                        rq.R2RContexts = strListR2RContexts.ToArray();
                        rq.CurrentOVLModel = strCurrentOVLModel;
                        rq.CurrentR2RMode = strCurrentR2RMode;

                        rq.InputIndex = structData.iListInputIndex.ToArray();
                        rq.InputMax = structData.dListInputMax.ToArray();
                        rq.InputMin = structData.dListInputMin.ToArray();
                        rq.InputResetValues = structData.dListInputValues.ToArray();
                        rq.ChuckIds = structData.strListChuckIds.ToArray();
                        rq.InputNames = structData.strListInputNames.ToArray();
                        rq.OVLModel = structData.strOVLModel;

                        rly = cfg.R2R_UI_PH_OVL_ResetModel(rq);
                        if (rly.Success)
                        {
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return bSuccess;
        }

        public struct structPH_OVL_GetResetValues
        {
            public List<int> iListInputIndex;
            public List<double> dListInputMax;
            public List<double> dListInputMin;
            public List<double> dListInputValues;
            public List<string> strListChuckIds;
            public List<string> strListInputNames;
            public List<string> strListOVLModels;
        };

        public static structPH_OVL_GetResetValues R2R_UI_PH_OVL_GetResetValues(ref string serviceName, string strController, List<string> strListR2RContexts, string strCurrentOVLModel, string strCurrentR2RMode)
        {
            int i = 0;
            int n = 0;int length = 0;

            structPH_OVL_GetResetValues structData = new structPH_OVL_GetResetValues();
            UIService.ReplySchema_R2R_UI_PH_OVL_GetResetValues rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_GetResetValues rq = new UIService.RequestSchema_R2R_UI_PH_OVL_GetResetValues();


                        rq.Controller = strController;
                        rq.R2RContexts = strListR2RContexts.ToArray();
                        rq.CurrentOVLModel = strCurrentOVLModel;
                        rq.CurrentR2RMode = strCurrentR2RMode;

                        rly = cfg.R2R_UI_PH_OVL_GetResetValues(rq);
                        if (rly.Success)
                        {
                            structData.iListInputIndex = new List<int>(rly.InputIndex);
                            structData.dListInputMax = new List<double>(rly.InputMax);
                            structData.dListInputMin = new List<double>(rly.InputMin);
                            structData.dListInputValues = new List<double>(rly.InputValues);
                            structData.strListChuckIds = new List<string>(rly.ChuckIds);
                            structData.strListInputNames = new List<string>(rly.InputNames);
                            structData.strListOVLModels = new List<string>(rly.OVLModels);

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        public static bool R2R_UI_PH_OVL_ChuckDedication(ref string serviceName, string strUserName, string strLotId, string strLayer, List<string> strListSlotIds, List<string> strListChuckIds)
        {
            int i = 0;
            int n = 0;int length = 0;

            bool bSuccess = false;
            UIService.ReplySchema_R2R_UI_PH_OVL_ChuckDedication rly = null;
            try
            {
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_ChuckDedication rq = new UIService.RequestSchema_R2R_UI_PH_OVL_ChuckDedication();
                        rq.UserName = strUserName;
                        rq.LotId = strLotId;
                        rq.Layer = strLayer;
                        rq.ChuckIds = strListChuckIds.ToArray();
                        rq.SlotIds = strListSlotIds.ToArray();

                        rly = cfg.R2R_UI_PH_OVL_ChuckDedication(rq);
                        if (rly.Success)
                        {
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return bSuccess;
        }
        public struct structPH_OVL_ChuckDedication
        {
            public List<string> strListWaferIds;
            public List<string> strListSlotIds;
            public List<string> strListChuckIds;
            public bool bForPreLayer;
        };

        public static bool R2R_UI_PH_OVL_ChuckDedication(ref string serviceName, string strUserName, string strLotId, string strLayer, structPH_OVL_ChuckDedication structData)
        {
            int i = 0;
            int n = 0;int length = 0;

            bool bSuccess = false;
            UIService.ReplySchema_R2R_UI_PH_OVL_ChuckDedication rly = null;
            try
            {
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_ChuckDedication rq = new UIService.RequestSchema_R2R_UI_PH_OVL_ChuckDedication();

                        rq.UserName = strUserName;
                        rq.LotId = strLotId;
                        rq.Layer = strLayer;
                        rq.WaferIds = structData.strListWaferIds.ToArray();
                        rq.SlotIds = structData.strListSlotIds.ToArray();
                        rq.ChuckIds = structData.strListChuckIds.ToArray();
                        rq.ForPreLayer = structData.bForPreLayer;

                        rly = cfg.R2R_UI_PH_OVL_ChuckDedication(rq);
                        if (rly.Success)
                        {
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return bSuccess;
        }

        public struct structPH_OVL_QueryLotInfo
        {
            public string strCurrentStepSequence;
            public List<string> strListWaferIds;
            public List<string> strListSlotIds;
            public List<string> strListChuckIds;
        };

        public static structPH_OVL_QueryLotInfo R2R_UI_PH_OVL_QueryLotInfo(ref string serviceName, string strFabName, string strLotId, string strConfigLayer, bool bForPreLayer)
        {
            int i = 0;
            int n = 0;int length = 0;

            structPH_OVL_QueryLotInfo structData = new structPH_OVL_QueryLotInfo();
            UIService.ReplySchema_R2R_UI_PH_OVL_QueryLotInfo rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_QueryLotInfo rq = new UIService.RequestSchema_R2R_UI_PH_OVL_QueryLotInfo();

                        rq.FabName = strFabName;
                        rq.LotId = strLotId;
                        rq.ConfigLayer = strConfigLayer;
                        rq.ForPreLayer = bForPreLayer;

                        rly = cfg.R2R_UI_PH_OVL_QueryLotInfo(rq);
                        if (rly.Success)
                        {
                            structData.strCurrentStepSequence = rly.CurrentStepSequence;
                            structData.strListWaferIds = new List<string>(rly.WaferIds);
                            structData.strListSlotIds = new List<string>(rly.SlotIds);
                            structData.strListChuckIds = new List<string>(rly.ChuckIds);

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        public struct structPH_OVL_GetPreLayerInfo
        {
            public string strPreLayerTool;
            public string strPreLayerReticle;
            public string strPreLayerPMTime;
            public string strPreLayerCPEUpdatedTime;
            public string strPreLayerModelUpdatedTime;
        };

        public static structPH_OVL_GetPreLayerInfo R2R_UI_PH_OVL_GetPreLayerInfo(ref string serviceName, string strReferenceLayer, string strReferenceLotId, string strController)
        {
            int i = 0;
            int n = 0;int length = 0;

            structPH_OVL_GetPreLayerInfo structData = new structPH_OVL_GetPreLayerInfo();
            UIService.ReplySchema_R2R_UI_PH_OVL_GetPreLayerInfo rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_GetPreLayerInfo rq = new UIService.RequestSchema_R2R_UI_PH_OVL_GetPreLayerInfo();

                        rq.ReferenceLayer = strReferenceLayer;
                        rq.ReferenceLotId = strReferenceLotId;
                        rq.Controller = strController;

                        rly = cfg.R2R_UI_PH_OVL_GetPreLayerInfo(rq);
                        if (rly.Success)
                        {
                            structData.strPreLayerTool = rly.PreLayerTool;
                            structData.strPreLayerReticle = rly.PreLayerReticle;
                            structData.strPreLayerPMTime = rly.PreLayerPMTime;
                            structData.strPreLayerCPEUpdatedTime = rly.PreLayerCPEUpdatedTime;
                            structData.strPreLayerModelUpdatedTime = rly.PreLayerModelUpdatedTime;

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        public static bool R2R_UI_PH_OVL_ConfigPreLayerInfo(ref string serviceName, string strUserName, string strProduct, string strLayer, string strLotId, structPH_OVL_GetPreLayerInfo structData)
        {
            int i = 0;
            int n = 0;int length = 0;

            bool bSuccess = false;
            UIService.ReplySchema_R2R_UI_PH_OVL_ConfigPreLayerInfo rly = null;
            try
            {
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_ConfigPreLayerInfo rq = new UIService.RequestSchema_R2R_UI_PH_OVL_ConfigPreLayerInfo();

                        rq.UserName = strUserName;
                        rq.Product = strProduct;
                        rq.Layer = strLayer;
                        rq.LotId = strLotId;

                        rq.PreLayerTool = structData.strPreLayerTool;
                        rq.PreLayerReticle = structData.strPreLayerReticle;
                        rq.PreLayerPMTime = structData.strPreLayerPMTime;
                        rq.PreLayerCPEUpdatedTime = structData.strPreLayerCPEUpdatedTime;
                        rq.PreLayerModelUpdatedTime = structData.strPreLayerModelUpdatedTime;

                        rly = cfg.R2R_UI_PH_OVL_ConfigPreLayerInfo(rq);
                        if (rly.Success)
                        {
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return bSuccess;
        }
        #endregion

        #region R2R_UI_PH_OVL_Batch
        public static List<string> R2R_UI_PH_OVL_Batch_GetProducts(ref string serviceName, string strArea)
        {
            int i = 0;
            int n = 0;int length = 0;

            List<string> strListProducts = new List<string>();
            UIService.ReplySchema_R2R_UI_PH_OVL_Batch_GetProducts rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_Batch_GetProducts rq = new UIService.RequestSchema_R2R_UI_PH_OVL_Batch_GetProducts();

                        rq.Area = strArea;

                        rly = cfg.R2R_UI_PH_OVL_Batch_GetProducts(rq);
                        if (rly.Success)
                        {
                            strListProducts = new List<string>(rly.Products);

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return strListProducts;
        }

        public static List<string> R2R_UI_PH_OVL_Batch_GetLayers(ref string serviceName, string strProduct)
        {
            int i = 0;
            int n = 0;int length = 0;

            List<string> strListLayers = new List<string>();
            UIService.ReplySchema_R2R_UI_PH_OVL_Batch_GetLayers rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_Batch_GetLayers rq = new UIService.RequestSchema_R2R_UI_PH_OVL_Batch_GetLayers();

                        rq.Product = strProduct;

                        rly = cfg.R2R_UI_PH_OVL_Batch_GetLayers(rq);
                        if (rly.Success)
                        {
                            strListLayers = new List<string>(rly.Layers);

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return strListLayers;
        }

        public static List<string> R2R_UI_PH_OVL_Batch_GetTools(ref string serviceName, string strProduct, string strLayer)
        {
            int i = 0;
            int n = 0;int length = 0;

            List<string> strListTools = new List<string>();
            UIService.ReplySchema_R2R_UI_PH_OVL_Batch_GetTools rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_Batch_GetTools rq = new UIService.RequestSchema_R2R_UI_PH_OVL_Batch_GetTools();

                        rq.Product = strProduct;
                        rq.Layer = strLayer;

                        rly = cfg.R2R_UI_PH_OVL_Batch_GetTools(rq);
                        if (rly.Success)
                        {
                            strListTools = new List<string>(rly.Tools);

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return strListTools;
        }

        public struct structPH_OVL_Batch_GetContexts
        {
            public List<string> strListProducts;
            public List<string> strListLayers;
            public List<string> strListTools;

        };

        public static structPH_OVL_Batch_GetContexts R2R_UI_PH_OVL_Batch_GetContexts(ref string serviceName, string strArea)
        {
            int i = 0;
            int n = 0;int length = 0;

            structPH_OVL_Batch_GetContexts structData = new structPH_OVL_Batch_GetContexts();
            UIService.ReplySchema_R2R_UI_PH_OVL_Batch_GetContexts rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_Batch_GetContexts rq = new UIService.RequestSchema_R2R_UI_PH_OVL_Batch_GetContexts();

                        rq.Area = strArea;

                        rly = cfg.R2R_UI_PH_OVL_Batch_GetContexts(rq);
                        if (rly.Success)
                        {
                            structData.strListProducts = new List<string>(rly.Products);
                            structData.strListLayers = new List<string>(rly.Layers);
                            structData.strListTools = new List<string>(rly.Tools);

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        public struct structPH_OVL_Batch_GetOVLModel
        {
            public bool bIsCPEModelOn;
            public string strOVLModel;
            public string strCPEModelName;
            public string strCPEModelTimeStamp;

            public List<string> strListUsedTimeStamps;
            public structDataContext structContext;
        };

        public static structPH_OVL_Batch_GetOVLModel R2R_UI_PH_OVL_Batch_GetOVLModel(ref string serviceName, string strProduct, string strLayer, string strTool)
        {
            int i = 0;
            int n = 0;int length = 0;

            structPH_OVL_Batch_GetOVLModel structData = new structPH_OVL_Batch_GetOVLModel();
            structDataContext structContext = new structDataContext();

            UIService.ReplySchema_R2R_UI_PH_OVL_Batch_GetOVLModel rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_Batch_GetOVLModel rq = new UIService.RequestSchema_R2R_UI_PH_OVL_Batch_GetOVLModel();
                        if (strProduct.Equals("*"))
                        {
                            strProduct = "%";
                        }
                        rq.Product = strProduct;
                        if (strLayer.Equals("*"))
                        {
                            strLayer = "%";
                        }
                        rq.Layer = strLayer;
                        rq.Tool = strTool;

                        rly = cfg.R2R_UI_PH_OVL_Batch_GetOVLModel(rq);
                        if (rly.Success)
                        {
                            structData.strOVLModel = rly.OVLModel;
                            structData.strCPEModelName = rly.CPEModelName;
                            structData.strCPEModelTimeStamp = rly.CPEModelTimeStamp;
                            structData.bIsCPEModelOn = rly.IsCPEModelOn;

                            structData.strListUsedTimeStamps = new List<string>(rly.UsedTimeStamps);
                            structContext.iListIndex = new List<int>(rly.Index);
                            structContext.strListContexts = new List<string>(rly.Contexts);
                            structContext.strListData_Context1 = new List<string>(rly.Data_Context1);
                            structContext.strListData_Context2 = new List<string>(rly.Data_Context2);
                            structContext.strListData_Context3 = new List<string>(rly.Data_Context3);
                            structContext.strListData_Context4 = new List<string>(rly.Data_Context4);
                            structContext.strListData_Context5 = new List<string>(rly.Data_Context5);
                            structContext.strListData_Context6 = new List<string>(rly.Data_Context6);
                            structContext.strListData_Context7 = new List<string>(rly.Data_Context7);
                            structContext.strListData_Context8 = new List<string>(rly.Data_Context8);
                            structContext.strListData_Context9 = new List<string>(rly.Data_Context9);
                            structContext.strListData_Context10 = new List<string>(rly.Data_Context10);
                            structContext.strListData_Context11 = new List<string>(rly.Data_Context11);
                            structContext.strListData_Context12 = new List<string>(rly.Data_Context12);
                            structContext.strListData_Context13 = new List<string>(rly.Data_Context13);
                            structContext.strListData_Context14 = new List<string>(rly.Data_Context14);
                            structContext.strListData_Context15 = new List<string>(rly.Data_Context15);
                            structContext.strListData_Context16 = new List<string>(rly.Data_Context16);
                            structContext.strListData_Context17 = new List<string>(rly.Data_Context17);
                            structContext.strListData_Context18 = new List<string>(rly.Data_Context18);
                            structContext.strListData_Context19 = new List<string>(rly.Data_Context19);
                            structContext.strListData_Context20 = new List<string>(rly.Data_Context20);

                            structData.structContext = structContext;

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        public static bool R2R_UI_PH_OVL_Batch_UpdateOVLModel(ref string serviceName, string strUserName, string strProduct, string strLayer, string strTool, string strOVLModel, bool bIsCPEModelOn, string strCPEModeName)
        {
            int i = 0;
            int n = 0;int length = 0;

            bool bSuccess = false;
            UIService.ReplySchema_R2R_UI_PH_OVL_Batch_UpdateOVLModel rly = null;
            try
            {
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_Batch_UpdateOVLModel rq = new UIService.RequestSchema_R2R_UI_PH_OVL_Batch_UpdateOVLModel();

                        rq.UserName = strUserName;
                        rq.Product = strProduct;
                        rq.Layer = strLayer;
                        rq.Tool = strTool;
                        rq.OVLModel = strOVLModel;
                        rq.IsCPEModelOn = bIsCPEModelOn;
                        rq.CPEModelName = strCPEModeName;

                        rly = cfg.R2R_UI_PH_OVL_Batch_UpdateOVLModel(rq);
                        if (rly.Success)
                        {
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return bSuccess;
        }

        //public static bool R2R_UI_PH_OVL_Batch_UpdateOVLModel(ref string serviceName, structPH_OVL_Batch_GetOVLModel structData)
        //{
        //    bool bSuccess = false;
        //    UIService.ReplySchema_R2R_UI_PH_OVL_Batch_UpdateOVLModel rly = null;
        //    try
        //    {
        //        string url = @"http://" + serviceName + @":58251/Adapter/R2R_UIService.asmx";
        //        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
        //        cfg.Url = url;
        //        UIService.RequestSchema_R2R_UI_PH_OVL_Batch_UpdateOVLModel rq = new UIService.RequestSchema_R2R_UI_PH_OVL_Batch_UpdateOVLModel();

        //        rq.R2RMode = structData.strListR2RMode.ToArray();
        //        rq.OVLModels = structData.strListOVLModels.ToArray();
        //        rq.Products = structData.strListProducts.ToArray();
        //        rq.Layers = structData.strListLayers.ToArray();
        //        rq.Tools = structData.strListTools.ToArray();
        //        rq.IsCPEModelOn = structData.bListIsCPEModelOn.ToArray();

        //        rly = cfg.R2R_UI_PH_OVL_Batch_UpdateOVLModel(rq);
        //        if (rly.Success)
        //        {
        //            bSuccess = true;
        //        }
        //        else
        //        {
        //            MessageBox.Show(rly.Message);
        //        }
        //    }
        //    catch (Exception err)
        //    {
        //         MessageBox.Show(BaseFun.GetExceptionInformation(err));
        //        //System.Environment.Exit(0);
        //    }
        //    return bSuccess;
        //}

        public struct structPH_OVL_Batch_GetR2RMode
        {
            public List<string> strListR2RModes;
            public List<string> strListR2RModeReticleIds;
            public List<string> strListInputChuckIds;
            public List<string> strListInputReticleIds;
            public List<string> strListInputParameterNames;
            public List<double> dListInputFixedValues;
            public List<double> dListInputMax;
            public List<double> dListInputMin;

            public List<string> strListUsedTimeStamps;
            public structDataContext structContext;
        };

        public static structPH_OVL_Batch_GetR2RMode R2R_UI_PH_OVL_Batch_GetR2RMode(ref string serviceName, string strProduct, string strLayer, string strTool)
        {
            int i = 0;
            int n = 0;int length = 0;

            structPH_OVL_Batch_GetR2RMode structData = new structPH_OVL_Batch_GetR2RMode();
            structDataContext structContext = new structDataContext();

            UIService.ReplySchema_R2R_UI_PH_OVL_Batch_GetR2RMode rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_Batch_GetR2RMode rq = new UIService.RequestSchema_R2R_UI_PH_OVL_Batch_GetR2RMode();
                        if (strProduct.Equals("*"))
                        {
                            strProduct = "%";
                        }
                        rq.Product = strProduct;
                        if (strLayer.Equals("*"))
                        {
                            strLayer = "%";
                        }
                        rq.Layer = strLayer;
                        rq.Tool = strTool;

                        rly = cfg.R2R_UI_PH_OVL_Batch_GetR2RMode(rq);
                        if (rly.Success)
                        {
                            structData.strListR2RModes = new List<string>(rly.R2RModes);
                            structData.strListR2RModeReticleIds = new List<string>(rly.R2RModeReticleIds);
                            structData.strListInputReticleIds = new List<string>(rly.InputReticleIds);
                            structData.strListInputChuckIds = new List<string>(rly.InputChuckIds);
                            structData.strListInputParameterNames = new List<string>(rly.InputParameterNames);
                            structData.dListInputFixedValues = new List<double>(rly.InputFixedValues);
                            structData.dListInputMax = new List<double>(rly.InputMax);
                            structData.dListInputMin = new List<double>(rly.InputMin);

                            structData.strListUsedTimeStamps = new List<string>(rly.UsedTimeStamps);
                            structContext.iListIndex = new List<int>(rly.Index);
                            structContext.strListContexts = new List<string>(rly.Contexts);
                            structContext.strListData_Context1 = new List<string>(rly.Data_Context1);
                            structContext.strListData_Context2 = new List<string>(rly.Data_Context2);
                            structContext.strListData_Context3 = new List<string>(rly.Data_Context3);
                            structContext.strListData_Context4 = new List<string>(rly.Data_Context4);
                            structContext.strListData_Context5 = new List<string>(rly.Data_Context5);
                            structContext.strListData_Context6 = new List<string>(rly.Data_Context6);
                            structContext.strListData_Context7 = new List<string>(rly.Data_Context7);
                            structContext.strListData_Context8 = new List<string>(rly.Data_Context8);
                            structContext.strListData_Context9 = new List<string>(rly.Data_Context9);
                            structContext.strListData_Context10 = new List<string>(rly.Data_Context10);
                            structContext.strListData_Context11 = new List<string>(rly.Data_Context11);
                            structContext.strListData_Context12 = new List<string>(rly.Data_Context12);
                            structContext.strListData_Context13 = new List<string>(rly.Data_Context13);
                            structContext.strListData_Context14 = new List<string>(rly.Data_Context14);
                            structContext.strListData_Context15 = new List<string>(rly.Data_Context15);
                            structContext.strListData_Context16 = new List<string>(rly.Data_Context16);
                            structContext.strListData_Context17 = new List<string>(rly.Data_Context17);
                            structContext.strListData_Context18 = new List<string>(rly.Data_Context18);
                            structContext.strListData_Context19 = new List<string>(rly.Data_Context19);
                            structContext.strListData_Context20 = new List<string>(rly.Data_Context20);

                            structData.structContext = structContext;

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        public static bool R2R_UI_PH_OVL_Batch_UpdateR2RMode(ref string serviceName, string strUserName, string strProduct, string strLayer, string strTool, string strR2RMode, string strChuckId, string strReticleId, List<string> strListInputParameterNames, List<double> dListInputMax, List<double> dListInputMin, List<double> dListInputFixedValues)
        {
            int i = 0;
            int n = 0;int length = 0;

            bool bSuccess = false;
            UIService.ReplySchema_R2R_UI_PH_OVL_Batch_UpdateR2RMode rly = null;
            try
            {
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_Batch_UpdateR2RMode rq = new UIService.RequestSchema_R2R_UI_PH_OVL_Batch_UpdateR2RMode();

                        rq.UserName = strUserName;
                        rq.Product = strProduct;
                        rq.Layer = strLayer;
                        rq.Tool = strTool;
                        rq.R2RMode = strR2RMode;
                        rq.ReticleId = strReticleId;
                        rq.ChuckId = strChuckId;

                        rq.InputMax = dListInputMax.ToArray();
                        rq.InputMin = dListInputMin.ToArray();
                        rq.InputFixedValues = dListInputFixedValues.ToArray();
                        rq.InputParameterNames = strListInputParameterNames.ToArray();

                        rly = cfg.R2R_UI_PH_OVL_Batch_UpdateR2RMode(rq);
                        if (rly.Success)
                        {
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return bSuccess;
        }

        public struct structPH_OVL_Batch_GetPMOffsets
        {
            public List<string> strListInputModels;
            public List<string> strListInputNames;
            public List<double> dListPMOffsets;
            public List<int> iListInputIndex;

            public List<string> strListUsedTimeStamps;
            public structDataContext structContext;

        };

        public static structPH_OVL_Batch_GetPMOffsets R2R_UI_PH_OVL_Batch_GetPMOffsets(ref string serviceName, string strTool)
        {
            int i = 0;
            int n = 0;int length = 0;

            structPH_OVL_Batch_GetPMOffsets structData = new structPH_OVL_Batch_GetPMOffsets();
            structDataContext structContext = new structDataContext();

            UIService.ReplySchema_R2R_UI_PH_OVL_Batch_GetPMOffsets rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_Batch_GetPMOffsets rq = new UIService.RequestSchema_R2R_UI_PH_OVL_Batch_GetPMOffsets();

                        rq.Tool = strTool;

                        rly = cfg.R2R_UI_PH_OVL_Batch_GetPMOffsets(rq);
                        if (rly.Success)
                        {
                            structData.strListInputModels = new List<string>(rly.InputModels);
                            structData.strListInputNames = new List<string>(rly.InputNames);
                            structData.dListPMOffsets = new List<double>(rly.PMOffsets);
                            structData.iListInputIndex = new List<int>(rly.InputIndex);

                            structData.strListUsedTimeStamps = new List<string>(rly.UsedTimeStamps);
                            structContext.iListIndex = new List<int>(rly.Index);
                            structContext.strListContexts = new List<string>(rly.Contexts);
                            structContext.strListData_Context1 = new List<string>(rly.Data_Context1);
                            structContext.strListData_Context2 = new List<string>(rly.Data_Context2);
                            structContext.strListData_Context3 = new List<string>(rly.Data_Context3);
                            structContext.strListData_Context4 = new List<string>(rly.Data_Context4);
                            structContext.strListData_Context5 = new List<string>(rly.Data_Context5);
                            structContext.strListData_Context6 = new List<string>(rly.Data_Context6);
                            structContext.strListData_Context7 = new List<string>(rly.Data_Context7);
                            structContext.strListData_Context8 = new List<string>(rly.Data_Context8);
                            structContext.strListData_Context9 = new List<string>(rly.Data_Context9);
                            structContext.strListData_Context10 = new List<string>(rly.Data_Context10);
                            structContext.strListData_Context11 = new List<string>(rly.Data_Context11);
                            structContext.strListData_Context12 = new List<string>(rly.Data_Context12);
                            structContext.strListData_Context13 = new List<string>(rly.Data_Context13);
                            structContext.strListData_Context14 = new List<string>(rly.Data_Context14);
                            structContext.strListData_Context15 = new List<string>(rly.Data_Context15);
                            structContext.strListData_Context16 = new List<string>(rly.Data_Context16);
                            structContext.strListData_Context17 = new List<string>(rly.Data_Context17);
                            structContext.strListData_Context18 = new List<string>(rly.Data_Context18);
                            structContext.strListData_Context19 = new List<string>(rly.Data_Context19);
                            structContext.strListData_Context20 = new List<string>(rly.Data_Context20);

                            structData.structContext = structContext;

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        public static bool R2R_UI_PH_OVL_Batch_UpdatePMOffsets(ref string serviceName, string strUserName, string strTool, List<string> strListInputModels, List<string> strListInputNames, List<double> dListPMOffset)
        {
            int i = 0;
            int n = 0;int length = 0;

            bool bSuccess = false;
            UIService.ReplySchema_R2R_UI_PH_OVL_Batch_UpdatePMOffsets rly = null;
            try
            {
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_Batch_UpdatePMOffsets rq = new UIService.RequestSchema_R2R_UI_PH_OVL_Batch_UpdatePMOffsets();

                        rq.UserName = strUserName;
                        rq.Tool = strTool;
                        rq.InputModels = strListInputModels.ToArray();
                        rq.InputNames = strListInputNames.ToArray();
                        rq.PMOffsets = dListPMOffset.ToArray();

                        rly = cfg.R2R_UI_PH_OVL_Batch_UpdatePMOffsets(rq);
                        if (rly.Success)
                        {
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return bSuccess;
        }

        public struct structPH_OVL_Batch_UpdatePMOffsets
        {
            public List<string> strListInputModels;
            public List<string> strListInputNames;
            public List<double> dListPMOffset;
        };

        public static bool R2R_UI_PH_OVL_Batch_UpdatePMOffsets(ref string serviceName, string strUserName, string strTool, structPH_OVL_Batch_UpdatePMOffsets structData)
        {
            int i = 0;
            int n = 0;int length = 0;

            bool bSuccess = false;
            UIService.ReplySchema_R2R_UI_PH_OVL_Batch_UpdatePMOffsets rly = null;
            try
            {
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_OVL_Batch_UpdatePMOffsets rq = new UIService.RequestSchema_R2R_UI_PH_OVL_Batch_UpdatePMOffsets();

                        rq.UserName = strUserName;
                        rq.Tool = strTool;
                        rq.InputModels = structData.strListInputModels.ToArray();
                        rq.InputNames = structData.strListInputNames.ToArray();
                        rq.PMOffsets = structData.dListPMOffset.ToArray();

                        rly = cfg.R2R_UI_PH_OVL_Batch_UpdatePMOffsets(rq);
                        if (rly.Success)
                        {
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return bSuccess;
        }
        #endregion

        #region R2R_UI_PH_CD
        public struct structPH_CD_GetLotRunHistory
        {
            public List<string> strListCD;
            public List<string> strListDose;
            public List<string> strListLotIds;
            public List<string> strListIsValidRecords;
            public List<string> strListUsedTimeStamps;
            public string strCurrentR2RMode;
            public string strPMTimeStamp;
            public string strResetTimeStamp;
            public bool bForcePilot;
        };
        public static structPH_CD_GetLotRunHistory R2R_UI_PH_CD_GetLotRunHistory(ref string serviceName, List<string> strListR2RContexts, int iListOfRuns)
        {
            int i = 0;
            int n = 0;int length = 0;

            structPH_CD_GetLotRunHistory structData = new structPH_CD_GetLotRunHistory();
            UIService.ReplySchema_R2R_UI_PH_CD_GetLotRunHistory rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_CD_GetLotRunHistory rq = new UIService.RequestSchema_R2R_UI_PH_CD_GetLotRunHistory();

                        rq.R2RContexts = strListR2RContexts.ToArray();
                        rq.ListOfRuns = iListOfRuns;

                        rly = cfg.R2R_UI_PH_CD_GetLotRunHistory(rq);

                        if (rly.Success)
                        {
                            structData.bForcePilot = rly.ForcePilot;
                            structData.strCurrentR2RMode = rly.CurrentR2RMode;
                            structData.strPMTimeStamp = rly.PMTimeStamp;
                            structData.strResetTimeStamp = rly.ResetTimeStamp;
                            structData.strListCD = new List<string>(rly.CD);
                            structData.strListDose = new List<string>(rly.Dose);
                            structData.strListLotIds = new List<string>(rly.LotIds);
                            structData.strListIsValidRecords = new List<string>(rly.IsValidRecords);
                            structData.strListUsedTimeStamps = new List<string>(rly.UsedTimeStamps);

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        public static bool R2R_UI_PH_CD_UpdatePilotFlag(ref string serviceName, string strUserName, string strController, List<string> strListR2RContexts, bool bForcePilot)
        {
            int i = 0;
            int n = 0;int length = 0;

            bool bSuccess = false;
            UIService.ReplySchema_R2R_UI_PH_CD_UpdatePilotFlag rly = null;
            try
            {
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_CD_UpdatePilotFlag rq = new UIService.RequestSchema_R2R_UI_PH_CD_UpdatePilotFlag();

                        rq.UserName = strUserName;
                        rq.Controller = strController;
                        rq.R2RContexts = strListR2RContexts.ToArray();
                        rq.ForcePilot = bForcePilot;

                        rly = cfg.R2R_UI_PH_CD_UpdatePilotFlag(rq);
                        if (rly.Success)
                        {

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return bSuccess;
        }

        public struct structPH_CD_GetDoseSettings
        {
            public string strR2RMode;
            public double dDoseMax;
            public double dDoseMin;
            public double dDoseFixedValue;
            public double dDoseCurrentValue;
        };
        public static structPH_CD_GetDoseSettings R2R_UI_PH_CD_GetDoseSettings(ref string serviceName, List<string> strListR2RContexts)
        {
            int i = 0;
            int n = 0;int length = 0;

            structPH_CD_GetDoseSettings structData = new structPH_CD_GetDoseSettings();
            UIService.ReplySchema_R2R_UI_PH_CD_GetDoseSettings rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_CD_GetDoseSettings rq = new UIService.RequestSchema_R2R_UI_PH_CD_GetDoseSettings();

                        rq.R2RContexts = strListR2RContexts.ToArray();

                        rly = cfg.R2R_UI_PH_CD_GetDoseSettings(rq);

                        if (rly.Success)
                        {
                            structData.strR2RMode = rly.R2RMode;
                            structData.dDoseMax = rly.DoseMax;
                            structData.dDoseMin = rly.DoseMin;
                            structData.dDoseFixedValue = rly.DoseFixedValue;
                            structData.dDoseCurrentValue = rly.DoseCurrentValue;

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        public struct structPH_CD_UpdateDoseSettings
        {
            public string strR2RMode;
            public string strDoseNewValue;
            public double dDoseMax;
            public double dDoseMin;
        };
        public static bool R2R_UI_PH_CD_UpdateDoseSettings(ref string serviceName, string strUserName, List<string> strListR2RContexts, structPH_CD_UpdateDoseSettings structData)
        {
            int i = 0;
            int n = 0;int length = 0;

            bool bSuccess = false;
            UIService.ReplySchema_R2R_UI_PH_CD_UpdateDoseSettings rly = null;
            try
            {
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_CD_UpdateDoseSettings rq = new UIService.RequestSchema_R2R_UI_PH_CD_UpdateDoseSettings();

                        rq.UserName = strUserName;
                        rq.R2RContexts = strListR2RContexts.ToArray();
                        rq.R2RMode = structData.strR2RMode;
                        //rq.DoseFixedValue = structData.strDoseFixedValue;
                        rq.DoseNewValue = structData.strDoseNewValue;

                        rq.DoseMax = structData.dDoseMax;
                        rq.DoseMin = structData.dDoseMin;

                        rly = cfg.R2R_UI_PH_CD_UpdateDoseSettings(rq);

                        if (rly.Success)
                        {
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return bSuccess;
        }

        public struct structPH_CD_GetDoseResetSettings
        {
            public double dDoseMax;
            public double dDoseMin;
            public double dDoseCurrentValue;
        };
        public static structPH_CD_GetDoseResetSettings R2R_UI_PH_CD_GetDoseResetSettings(ref string serviceName, List<string> strListR2RContexts)
        {
            int i = 0;
            int n = 0;int length = 0;

            structPH_CD_GetDoseResetSettings structData = new structPH_CD_GetDoseResetSettings();
            UIService.ReplySchema_R2R_UI_PH_CD_GetDoseResetSettings rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_CD_GetDoseResetSettings rq = new UIService.RequestSchema_R2R_UI_PH_CD_GetDoseResetSettings();

                        rq.R2RContexts = strListR2RContexts.ToArray();

                        rly = cfg.R2R_UI_PH_CD_GetDoseResetSettings(rq);

                        if (rly.Success)
                        {
                            structData.dDoseMax = rly.DoseMax;
                            structData.dDoseMin = rly.DoseMin;
                            structData.dDoseCurrentValue = rly.DoseCurrentValue;

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        public struct structPH_CD_UpdateDoseResetSettings
        {
            public bool bIsPM;
            public bool bIsReset;
            public double dDoseMax;
            public double dDoseMin;
            public double dDoseDefaultValue;
        };

        public static bool R2R_UI_PH_CD_UpdateDoseResetSettings(ref string serviceName, string strUserName, List<string> strListR2RContexts, structPH_CD_UpdateDoseResetSettings structData)
        {
            int i = 0;
            int n = 0;int length = 0;

            bool bSuccess = false;
            UIService.ReplySchema_R2R_UI_PH_CD_UpdateDoseResetSettings rly = null;
            try
            {
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_CD_UpdateDoseResetSettings rq = new UIService.RequestSchema_R2R_UI_PH_CD_UpdateDoseResetSettings();

                        rq.UserName = strUserName;
                        rq.R2RContexts = strListR2RContexts.ToArray();
                        rq.DoseDefaultValue = structData.dDoseDefaultValue;
                        rq.DoseMax = structData.dDoseMax;
                        rq.DoseMin = structData.dDoseMin;
                        rq.IsReset = structData.bIsReset;
                        rq.IsPM = structData.bIsPM;

                        rly = cfg.R2R_UI_PH_CD_UpdateDoseResetSettings(rq);

                        if (rly.Success)
                        {
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return bSuccess;
        }
        #endregion

        #region R2R_UI_PH_Focus
        public struct structPH_Focus_GetLotRunHistory
        {
            public List<string> strListCD;
            public List<string> strListFocus;
            public List<string> strListLotIds;
            public List<string> strListIsValidRecords;
            public List<string> strListUsedTimeStamps;
            public string strCurrentR2RMode;
            public string strPMTimeStamp;
            public string strResetTimeStamp;
        };
        public static structPH_Focus_GetLotRunHistory R2R_UI_PH_Focus_GetLotRunHistory(ref string serviceName, List<string> strListR2RContexts, int iListOfRuns)
        {
            int i = 0;
            int n = 0;int length = 0;

            structPH_Focus_GetLotRunHistory structData = new structPH_Focus_GetLotRunHistory();
            UIService.ReplySchema_R2R_UI_PH_Focus_GetLotRunHistory rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_Focus_GetLotRunHistory rq = new UIService.RequestSchema_R2R_UI_PH_Focus_GetLotRunHistory();

                        rq.R2RContexts = strListR2RContexts.ToArray();
                        rq.ListOfRuns = iListOfRuns;
                        rly = cfg.R2R_UI_PH_Focus_GetLotRunHistory(rq);

                        if (rly.Success)
                        {
                            structData.strCurrentR2RMode = rly.CurrentR2RMode;
                            structData.strPMTimeStamp = rly.PMTimeStamp;
                            structData.strResetTimeStamp = rly.ResetTimeStamp;
                            structData.strListCD = new List<string>(rly.CD);
                            structData.strListFocus = new List<string>(rly.Focus);
                            structData.strListLotIds = new List<string>(rly.LotIds);
                            structData.strListIsValidRecords = new List<string>(rly.IsValidRecords);
                            structData.strListUsedTimeStamps = new List<string>(rly.UsedTimeStamps);

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        public static double R2R_UI_PH_Focus_GetFocusSettings(ref string serviceName, List<string> strListR2RContexts)
        {
            int i = 0;
            int n = 0;int length = 0;

            double dValue = 0.0;
            UIService.ReplySchema_R2R_UI_PH_Focus_GetFocusSettings rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_Focus_GetFocusSettings rq = new UIService.RequestSchema_R2R_UI_PH_Focus_GetFocusSettings();

                        rq.R2RContexts = strListR2RContexts.ToArray();

                        rly = cfg.R2R_UI_PH_Focus_GetFocusSettings(rq);

                        if (rly.Success)
                        {
                            dValue = rly.FocusFixedValue;

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return dValue;
        }

        public static bool R2R_UI_PH_Focus_UpdateFocusSettings(ref string serviceName, string strUserName, List<string> strListR2RContexts, double dValue)
        {
            int i = 0;
            int n = 0;int length = 0;

            bool bSuccess = false;
            UIService.ReplySchema_R2R_UI_PH_Focus_UpdateFocusSettings rly = null;
            try
            {
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_PH_Focus_UpdateFocusSettings rq = new UIService.RequestSchema_R2R_UI_PH_Focus_UpdateFocusSettings();

                        rq.UserName = strUserName;
                        rq.R2RContexts = strListR2RContexts.ToArray();
                        rq.FocusFixedValue = dValue;

                        rly = cfg.R2R_UI_PH_Focus_UpdateFocusSettings(rq);

                        if (rly.Success)
                        {
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return bSuccess;
        }

        #endregion

        #region R2R_UI_COMMON
        public struct structCOMMON_GetRawMetrology
        {
            public double dUpperLimit;
            public double dLowerLimit;
            public double dTarget;
            public List<string> strListWaferIds;
            public List<string> strListMeasDataItemNames;
            public List<string> strListMeasSiteCSV;
            public List<string> strListMeasValidityCSV;
            public List<string> strListMeasValueCSV;
        };
        public static structCOMMON_GetRawMetrology R2R_UI_COMMON_GetRawMetrology(ref string serviceName, string strController, List<string> strListR2RContexts, int iOutputIndex, string strLotId, string strGroup)
        {
            int i = 0;
            int n = 0;int length = 0;

            structCOMMON_GetRawMetrology structData = new structCOMMON_GetRawMetrology();
            UIService.ReplySchema_R2R_UI_COMMON_GetRawMetrology rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_COMMON_GetRawMetrology rq = new UIService.RequestSchema_R2R_UI_COMMON_GetRawMetrology();

                        rq.Controller = strController;
                        rq.R2RContexts = strListR2RContexts.ToArray();
                        rq.LotId = strLotId;
                        rq.Group = strGroup;
                        rq.OutputIndex = iOutputIndex;
                        rly = cfg.R2R_UI_COMMON_GetRawMetrology(rq);

                        if (rly.Success)
                        {
                            structData.dTarget = rly.Target;
                            structData.dUpperLimit = rly.UpperLimit;
                            structData.dLowerLimit = rly.LowerLimit;
                            structData.strListWaferIds = new List<string>(rly.WaferIds);
                            structData.strListMeasDataItemNames = new List<string>(rly.MeasDataItemNames);
                            structData.strListMeasSiteCSV = new List<string>(rly.MeasSiteCSV);
                            structData.strListMeasValidityCSV = new List<string>(rly.MeasValidityCSV);
                            structData.strListMeasValueCSV = new List<string>(rly.MeasValueCSV);

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        public struct structCOMMON_GetLotRunHistory
        {
            public int iFullInputSize;
            public int iFullOutputSize;
            public List<string> strListUniqueGroups;
            public List<string> strListCurrentR2RModes;
            public List<string> strListInputParameterNameCSVs;
            public List<string> strListOutputParameterNameCSVs;
            public List<string> strListPMTimeStamps_ByGroup;
            public List<string> strListResetTimeStamps_ByGroup;
            public List<int> iListActualInputSizes;
            public List<int> iListActualOutputSizes;
            public List<string> strListLotIds;
            public List<string> strListGroups;
            public List<string> strListInputValues;
            public List<string> strListOutputValues;
            public List<string> strListIsValidRecords;
            public List<string> strListUsedTimeStamps;
        };
        public static structCOMMON_GetLotRunHistory R2R_UI_COMMON_GetLotRunHistory(ref string serviceName, string strController, List<string> strListR2RContexts, int iListOfRuns)
        {
            int i = 0;
            int n = 0;int length = 0;

            structCOMMON_GetLotRunHistory structData = new structCOMMON_GetLotRunHistory();
            UIService.ReplySchema_R2R_UI_COMMON_GetLotRunHistory rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_COMMON_GetLotRunHistory rq = new UIService.RequestSchema_R2R_UI_COMMON_GetLotRunHistory();

                        rq.Controller = strController;
                        rq.R2RContexts = strListR2RContexts.ToArray();
                        rq.ListOfRuns = iListOfRuns;
                        rly = cfg.R2R_UI_COMMON_GetLotRunHistory(rq);

                        if (rly.Success)
                        {
                            structData.iFullInputSize = rly.FullInputSize;
                            structData.iFullOutputSize = rly.FullOutputSize;
                            structData.strListUniqueGroups = new List<string>(rly.UniqueGroups);
                            structData.strListCurrentR2RModes = new List<string>(rly.CurrentR2RModes);
                            structData.strListInputParameterNameCSVs = new List<string>(rly.InputParameterNameCSVs);
                            structData.strListOutputParameterNameCSVs = new List<string>(rly.OutputParameterNameCSVs);
                            structData.strListPMTimeStamps_ByGroup = new List<string>(rly.PMTimeStamps_ByGroup);
                            structData.strListResetTimeStamps_ByGroup = new List<string>(rly.ResetTimeStamps_ByGroup);
                            structData.iListActualInputSizes = new List<int>(rly.ActualInputSizes);
                            structData.iListActualOutputSizes = new List<int>(rly.ActualOutputSizes);
                            structData.strListLotIds = new List<string>(rly.LotIds);
                            structData.strListGroups = new List<string>(rly.Groups);
                            structData.strListInputValues = new List<string>(rly.InputValues);
                            structData.strListOutputValues = new List<string>(rly.OutputValues);
                            structData.strListIsValidRecords = new List<string>(rly.IsValidRecords);
                            structData.strListUsedTimeStamps = new List<string>(rly.UsedTimeStamps);

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        public struct structCOMMON_GetInputSettings
        {
            public string strR2RMode;
            public List<int> iListInputIndex;
            public List<double> dListInputMax;
            public List<double> dListInputMin;
            public List<double> dListInputFixedValues;
            public List<double> dListInputCurrentValues;
            public List<string> strListInputParameterNames;
        };
        public static structCOMMON_GetInputSettings R2R_UI_COMMON_GetInputSettings(ref string serviceName, string strController, string strGroup, List<string> strListR2RContexts)
        {
            int i = 0;
            int n = 0;int length = 0;

            structCOMMON_GetInputSettings structData = new structCOMMON_GetInputSettings();
            UIService.ReplySchema_R2R_UI_COMMON_GetInputSettings rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_COMMON_GetInputSettings rq = new UIService.RequestSchema_R2R_UI_COMMON_GetInputSettings();


                        rq.Group = strGroup;
                        rq.Controller = strController;
                        rq.R2RContexts = strListR2RContexts.ToArray();

                        rly = cfg.R2R_UI_COMMON_GetInputSettings(rq);

                        if (rly.Success)
                        {
                            structData.strR2RMode = rly.R2RMode;
                            structData.iListInputIndex = new List<int>(rly.InputIndex);
                            structData.dListInputMax = new List<double>(rly.InputMax);
                            structData.dListInputMin = new List<double>(rly.InputMin);
                            structData.dListInputFixedValues = new List<double>(rly.InputFixedValues);
                            structData.dListInputCurrentValues = new List<double>(rly.InputCurrentValues);
                            structData.strListInputParameterNames = new List<string>(rly.InputParameterNames);

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        public struct structCOMMON_UpdateInputSettings
        {
            public string strR2RMode;
            public List<int> iListInputIndex;
            public List<double> dListInputMax;
            public List<double> dListInputMin;
            public List<double> dListInputNewValues;
            //public List<string> strListInputParameterNames;
        };

        public static bool R2R_UI_COMMON_UpdateInputSettings(ref string serviceName, string strUserName, string strController, string strGroup, List<string> strListR2RContexts, structCOMMON_UpdateInputSettings structData)
        {
            int i = 0;
            int n = 0;int length = 0;

            bool bSuccess = false;
            UIService.ReplySchema_R2R_UI_COMMON_UpdateInputSettings rly = null;
            try
            {
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_COMMON_UpdateInputSettings rq = new UIService.RequestSchema_R2R_UI_COMMON_UpdateInputSettings();

                        rq.UserName = strUserName;
                        rq.Group = strGroup;
                        rq.Controller = strController;
                        rq.R2RContexts = strListR2RContexts.ToArray();
                        rq.R2RMode = structData.strR2RMode;
                        rq.InputIndex = structData.iListInputIndex.ToArray();
                        rq.InputNewValues = structData.dListInputNewValues.ToArray();
                        rq.InputMax = structData.dListInputMax.ToArray();
                        rq.InputMin = structData.dListInputMin.ToArray();

                        //rq.InputParameterNames = structData.strListInputParameterNames.ToArray();

                        rly = cfg.R2R_UI_COMMON_UpdateInputSettings(rq);

                        if (rly.Success)
                        {
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return bSuccess;
        }

        public struct structCOMMON_GetInputResetSettings
        {
            public List<int> iListInputIndex;
            public List<double> dListInputMax;
            public List<double> dListInputMin;
            public List<double> dListInputPMValues;
            public List<double> dListInputResetValues;
            public List<string> strListInputParameterNames;
        };
        public static structCOMMON_GetInputResetSettings R2R_UI_COMMON_GetInputResetSettings(ref string serviceName, string strController, string strGroup, List<string> strListR2RContexts)
        {
            int i = 0;
            int n = 0;int length = 0;

            structCOMMON_GetInputResetSettings structData = new structCOMMON_GetInputResetSettings();
            UIService.ReplySchema_R2R_UI_COMMON_GetInputResetSettings rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_COMMON_GetInputResetSettings rq = new UIService.RequestSchema_R2R_UI_COMMON_GetInputResetSettings();

                        rq.Group = strGroup;
                        rq.Controller = strController;
                        rq.R2RContexts = strListR2RContexts.ToArray();

                        rly = cfg.R2R_UI_COMMON_GetInputResetSettings(rq);

                        if (rly.Success)
                        {
                            structData.iListInputIndex = new List<int>(rly.InputIndex);
                            structData.dListInputMax = new List<double>(rly.InputMax);
                            structData.dListInputMin = new List<double>(rly.InputMin);
                            structData.dListInputPMValues = new List<double>(rly.InputPMValues);
                            structData.dListInputResetValues = new List<double>(rly.InputResetValues);
                            structData.strListInputParameterNames = new List<string>(rly.InputParameterNames);

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }

        public struct structCOMMON_UpdateInputResetSettings
        {
            public bool bIsPM;
            public bool bIsReset;
            public List<int> iListInputIndex;
            public List<double> dListInputMax;
            public List<double> dListInputMin;
            public List<double> dListInputPMValues;
            public List<double> dListInputResetValues;
        };
        public static bool R2R_UI_COMMON_UpdateInputResetSettings(ref string serviceName, string strUserName, string strController, string strGroup, List<string> strListR2RContexts, structCOMMON_UpdateInputResetSettings structData)
        {
            int i = 0;
            int n = 0;int length = 0;

            bool bSuccess = false;
            UIService.ReplySchema_R2R_UI_COMMON_UpdateInputResetSettings rly = null;
            try
            {
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_COMMON_UpdateInputResetSettings rq = new UIService.RequestSchema_R2R_UI_COMMON_UpdateInputResetSettings();

                        rq.UserName = strUserName;
                        rq.Group = strGroup;
                        rq.Controller = strController;
                        rq.IsPM = structData.bIsPM;
                        rq.IsReset = structData.bIsReset;
                        rq.R2RContexts = strListR2RContexts.ToArray();
                        rq.InputIndex = structData.iListInputIndex.ToArray();
                        rq.InputMax = structData.dListInputMax.ToArray();
                        rq.InputMin = structData.dListInputMin.ToArray();
                        rq.InputPMValues = structData.dListInputPMValues.ToArray();
                        rq.InputResetValues = structData.dListInputResetValues.ToArray();

                        rly = cfg.R2R_UI_COMMON_UpdateInputResetSettings(rq);

                        if (rly.Success)
                        {
                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return bSuccess;
        }
        #endregion

        #region R2R_UI_GetDBInfo
        public static string R2R_UI_GetDBInfoConn(ref string serviceName, string strServer, string strDomain)
        {
            int i = 0;
            int n = 0;int length = 0;

            string strConn = string.Empty;
            UIService.ReplySchema_R2R_UI_GetDBInfo rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_GetDBInfo rq = new UIService.RequestSchema_R2R_UI_GetDBInfo();

                        rq.Server = strServer;
                        rq.Domain = strDomain;

                        rly = cfg.R2R_UI_GetDBInfo(rq);

                        if (rly.Success)
                        {
                            if (rly.IP.Contains(";"))  //冗余
                                strConn = "User Id=" + rly.User + "; Password=" + rly.Password + "; Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST="
                                                             + rly.IP.Split(';')[0] + ")(PORT=" + rly.Port + "))(ADDRESS=(PROTOCOL=TCP)(HOST="
                                                             + rly.IP.Split(';')[1] + ")(PORT=" + rly.Port + ")))(CONNECT_DATA=(SERVICE_NAME=" + rly.ServiceName + ")))";
                            else
                            strConn = "User Id=" + rly.User + "; Password=" + rly.Password + "; Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST="
                               + rly.IP + ")(PORT=" + rly.Port + ")))(CONNECT_DATA=(SERVICE_NAME=" + rly.ServiceName + ")))";

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return strConn;
        }

        public struct structGetDBInfo
        {
            public string strUser;
            public string strPassword;
            public string strIP;
            public string strPort;
            public string strServiceName;
        };
        public static structGetDBInfo R2R_UI_GetDBInfo(ref string serviceName, string strServer, string strDomain)
        {
            int i = 0;
            int n = 0;int length = 0;

            structGetDBInfo structData = new structGetDBInfo();
            UIService.ReplySchema_R2R_UI_GetDBInfo rly = null;
            try
            {
                bool bSuccess = false;
                List<string> strListServerAddress = new List<string>();
                strListServerAddress = BaseFun.GetServerAddress(serviceName);

                if (strListServerAddress.Count > 0)
                {
                    n = strListServerAddress.Count;
                    foreach (var str in strListServerAddress)
                    {
                        i++; length = str.Length;
                        string url = @"http://" + str + @":58251/Adapter/R2R_UIService.asmx";
                        UIService.R2R_UIService cfg = new UIService.R2R_UIService();
                        cfg.Url = url;
                        UIService.RequestSchema_R2R_UI_GetDBInfo rq = new UIService.RequestSchema_R2R_UI_GetDBInfo();

                        rq.Server = strServer;
                        rq.Domain = strDomain;

                        rly = cfg.R2R_UI_GetDBInfo(rq);

                        if (rly.Success)
                        {
                            structData.strUser = rly.User;
                            structData.strPassword = rly.Password;
                            structData.strIP = rly.IP;
                            structData.strPort = rly.Port;
                            structData.strServiceName = rly.ServiceName;

                            bSuccess = true;
                            break;
                        }
                        else
                        {
                            if (rly.Message.Equals("Connet Failed"))
                            {
                                serviceName = serviceName.Substring(str.Length).TrimStart(';');
                            }
                            continue;
                        }
                    }
                }
                if (!bSuccess)
                {
                    MessageBox.Show(rly.Message);
                }
            }
            catch (Exception err)
            {
                if (n == i)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            return structData;
        }
        #endregion
    }
}
