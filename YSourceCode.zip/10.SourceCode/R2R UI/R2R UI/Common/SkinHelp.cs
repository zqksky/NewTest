﻿using MaterialSkin;
using MaterialSkin.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R_UI.Common
{
    class SkinHelp
    {
        public static void SkinSet(MaterialForm frm,string strType)
        {
            MaterialSkinManager materialSkinManager;
            materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(frm);
            materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;

            if (strType.ToUpper().Contains("PRODUCT"))
            {
                materialSkinManager.ColorScheme = new ColorScheme(Primary.Red800, Primary.Red900, Primary.Red500, Accent.Pink200, TextShade.WHITE);                
            }
            else if (strType.ToUpper().Contains("PIRUN"))
            {
                materialSkinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue200, TextShade.WHITE);
            }
            else if (strType.ToUpper().Contains("TEST"))
            {
                materialSkinManager.ColorScheme = new ColorScheme(Primary.Indigo500, Primary.Indigo700, Primary.Indigo100, Accent.Pink200, TextShade.WHITE);
            }
            else
            {
                materialSkinManager.ColorScheme = new ColorScheme(Primary.Yellow800, Primary.Yellow900, Primary.Indigo100, Accent.Pink200, TextShade.WHITE);
            }
        }
    }
}
