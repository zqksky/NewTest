﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace R2R_UI.Common
{
    class RegexHelp
    {

        public static bool IsNumber(string str)
        {
            string strPattern = @"^[0-9]*$";//只允许输入数字
            Match m = Regex.Match(str, strPattern);   // 匹配正则表达式

            return m.Success;
        }

        public static bool IsDoubleValue(string str)
        {
            bool bFlag = false;
            double dValue;
            //double.TryParse(str, out dValue); //如果返回True 说明是double 否则不是double 型

            if (double.TryParse(str, out dValue))
            {
                if (double.IsNaN(dValue))
                {
                    bFlag = false;
                }
                else
                {
                    bFlag = true;
                }
            }

            //bFlag = Regex.IsMatch(str, @"^[+-]?\d*[.]?\d*$", RegexOptions.IgnoreCase | RegexOptions.Compiled);  //如果string字符串可以转换为double，则返回True，反之为False。
            return bFlag;
        }

        public static bool IsIntValue(string str)
        {
            bool bFlag = Regex.IsMatch(str, @"^[+-]?\d*$");  //如果string字符串可以转换为int，则返回true，反之为false。
            return bFlag;
        }
    }
}
