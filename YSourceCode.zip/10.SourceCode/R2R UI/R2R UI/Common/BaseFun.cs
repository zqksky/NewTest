﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;
using static R2R_UI.Common.UIServiceFun;

namespace R2R_UI.Common
{
    class BaseFun
    {
        #region GetServerAddress
        public static List<string> GetServerAddress(string strServerAddress)
        {
            List<string> strList = new List<string>();
            try
            {

                strServerAddress = new Regex("[\\s]+").Replace(strServerAddress, " ");
                if (strServerAddress.Contains(";"))
                {
                    string[] sArray = Regex.Split(strServerAddress.TrimEnd(';'), ";", RegexOptions.IgnoreCase);
                    foreach (string str in sArray)
                    {
                        if (IsIP4(str))
                        {
                            strList.Add(str);
                        }
                    }
                }
                else
                {
                    if (IsIP4(strServerAddress))
                    {
                        strList.Add(strServerAddress);
                    }
                }
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
            }

            return strList;
        }

        private static bool IsIP4(string str)
        {
            //System.Net.IPAddress ip;
            //if (System.Net.IPAddress.TryParse(str, out ip))
            //{
            //    flag = true;
            //}
            //else
            //{
            //    flag= false;
            //}

            bool flag = false;
            if (str.ToLower().Equals("localhost"))
            {
                flag = true;
            }
            else
            {
                Regex reg = new Regex(@"^\d{1,3}(\.\d{1,3}){3}$", RegexOptions.Singleline);
                flag = reg.Match(str).Success;
            }

            return flag;
        }

        #endregion

        #region GetExceptionInformation
        public static string GetExceptionInformation(Exception ee)
        {
            string strTmp = string.Empty;
            string strResult = string.Empty;
            string strStackTrace = ee.StackTrace;

            try
            {
                if (strStackTrace.Length > 6 && strStackTrace.IndexOf(" in ") > 6)
                {
                    strTmp = strStackTrace.Substring(6, strStackTrace.IndexOf(" in ") - 6);
                }
                else if (strStackTrace.Length > 6)
                {
                    strTmp = strStackTrace.Substring(6);
                }

                strResult += strTmp + "\r\n";

                strTmp = strStackTrace.Substring(strStackTrace.LastIndexOf(":line") + 1);
                strResult += strTmp + "\r\n";

                strResult += ee.Message;
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
            }

            return strResult;

            //return ee.Message;
        }
        #endregion

        #region Get Group
        public static List<List<int>> GetGroupIndex(List<string> strList)
        {
            List<List<int>> iListIndexs = new List<List<int>>();
            List<string> strListGroup = new List<string>();

            try
            {
                strListGroup = GetGroupName(strList);
                foreach (var str in strListGroup)
                {
                    List<int> iListIndex = new List<int>();
                    for (int i = 0; i < strList.Count; i++)
                    {
                        if (str.Equals(strList[i]))
                        {
                            iListIndex.Add(i);
                        }
                    }
                    iListIndexs.Add(iListIndex);
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(GetExceptionInformation(err));
            }

            return iListIndexs;
        }

        public static List<string> GetGroupName(List<string> strList)
        {
            List<string> strGroup = new List<string>();

            try
            {
                //strList = new List<string>() { "p1", "p1", "p1", "p2", "p2", "p3", "p3", "p4" };
                var q = strList.GroupBy(x => x).Where(x => x.Count() > 0).ToList();

                foreach (var item in q)
                {
                    //List<string> str = new List<string>(item.ToList());
                    //foreach (var s in str)
                    //{
                    //    MessageBox.Show(s);
                    //}
                    //MessageBox.Show(item.Key);
                    strGroup.Add(item.Key);
                }
                strGroup.Sort();
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(GetExceptionInformation(err));
            }
            return strGroup;
        }
        #endregion

        #region PM/RESET TIME VALUE
        public static bool IsDate(string date)
        {
            try
            {
                DateTime.Parse(date);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static List<DateTime> StrToDateTime(List<string> strListUsedTime)
        {
            List<DateTime> strDateTime = new List<DateTime>();
            try
            {
                foreach (var str in strListUsedTime)
                {
                    if (IsDate(str))
                    {
                        strDateTime.Add(Convert.ToDateTime(str));
                    }
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(GetExceptionInformation(err));
            }

            return strDateTime;
        }

        public static int GetPMResetTimeValue(string strPMRestTime, List<string> strListUsedTime)
        {
            int num = 0;
            DateTime dtPMResetTime;
            DateTime dtMax;
            DateTime dtMin;
            List<DateTime> strDateTime = new List<DateTime>();

            if (strPMRestTime.Equals("NA"))
            {
                num = -1;
            }
            else
            {
                try
                {
                    strDateTime = StrToDateTime(strListUsedTime);
                    if (strDateTime.Count > 0)
                    {
                        if (IsDate(strPMRestTime))
                        {
                            dtPMResetTime = Convert.ToDateTime(strPMRestTime);
                            dtMax = strDateTime.Max();
                            dtMin = strDateTime.Min();
                            if (DateTime.Compare(dtMin, dtPMResetTime) > 0)
                            {
                                num = 0;
                            }
                            else if (DateTime.Compare(dtMax, dtPMResetTime) < 0)
                            {
                                num = strDateTime.Count;
                            }
                            else
                            {
                                for (int i = 0; i < strListUsedTime.Count; i++)
                                {
                                    if (DateTime.Compare(dtPMResetTime, Convert.ToDateTime(strListUsedTime[i])) < 0)
                                    {
                                        num++;
                                    }
                                    else
                                    {
                                        num = strDateTime.Count - num;
                                        break;
                                    }
                                }
                            }
                        }
                        else
                        {
                            num = 0;
                        }

                    }
                }
                catch (Exception err)
                {
                    System.Windows.Forms.MessageBox.Show(GetExceptionInformation(err));
                }
            }

            return num;
        }
        #endregion

        #region Sort Value ListId UsedTime
        private static void GetSortListAndValue(List<string> strListUsedTime, ref List<string> strListValue, ref List<string> strListId)
        {
            List<int> iListIndex = new List<int>();
            List<string> strListIdSort = new List<string>();
            List<string> strListItemValuesSort = new List<string>();

            try
            {
                iListIndex = GetSortListIndex(strListUsedTime);
                strListItemValuesSort = GetSortList(strListValue, iListIndex);
                strListIdSort = GetSortList(strListId, iListIndex);

                strListValue = new List<string>(strListItemValuesSort);
                strListId = new List<string>(strListIdSort);
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(GetExceptionInformation(err));
            }
        }

        private static List<int> GetSortListIndex(List<string> strList)
        {
            List<int> iListIndex = new List<int>();
            List<string> strListSort = new List<string>(strList);

            try
            {
                strListSort.Sort();

                foreach (var str in strListSort)
                {
                    for (int i = 0; i < strList.Count; i++)
                    {
                        if (str.Equals(strList[i]))
                        {
                            iListIndex.Add(i);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(GetExceptionInformation(err));
            }
            return iListIndex;
        }

        private static List<string> GetSortList(List<string> strList, List<int> iListIndex)
        {
            List<string> strListSort = new List<string>();

            try
            {
                for (int i = 0; i < iListIndex.Count; i++)
                {
                    strListSort.Add(strList[iListIndex[i]]);
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(GetExceptionInformation(err));
            }
            return strListSort;
        }
        #endregion

        #region Get Item Values
        //CD/Focus
        public static List<double> GetCDFocusItemValues(List<string> strListUsedTime, List<string> strListValue, List<string> strListLotIds, ref List<string> strListLotIdSort)
        {
            List<double> dListValue = new List<double>();
            List<string> strListTemp = new List<string>();

            try
            {
                GetSortListAndValue(strListUsedTime, ref strListValue, ref strListLotIds);
                strListTemp = FormatItemValues(strListValue);

                if (strListTemp.Count > 0)
                {
                    for (int n = 0; n < strListTemp.Count; n++)
                    {
                        List<string> strListLotIdsNew = new List<string>();

                        if (RegexHelp.IsDoubleValue(strListTemp[n]))
                        {
                            dListValue.Add(double.Parse(strListTemp[n]));
                        }
                        else
                        {
                            //System.Windows.Forms.MessageBox.Show("Add NaN");
                            dListValue.Add(double.NaN);
                        }
                    }
                    strListLotIdSort = new List<string>(strListLotIds);
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(GetExceptionInformation(err));
            }

            return dListValue;
        }

        //CD/Focus/Common
        public static List<List<double>> GetCommonItemValues(List<string> strListUsedTime, List<string> strListValue, ref List<List<string>> strGroupListLotIds, List<string> strListLotIds)
        {
            List<List<string>> strListTemp = new List<List<string>>();
            List<List<double>> dGroupListValue = new List<List<double>>();

            try
            {
                GetSortListAndValue(strListUsedTime, ref strListValue, ref strListLotIds);
                strListTemp = GetItemValues(strListValue);
                //dGroupListValue.Clear();
                if (strListTemp.Count > 0)
                {
                    strGroupListLotIds = new List<List<string>>();
                    for (int n = 0; n < strListTemp[0].Count; n++)
                    {
                        List<double> dListValue = new List<double>();
                        List<string> strListLotIdsNew = new List<string>();

                        for (int i = 0; i < strListTemp.Count; i++)
                        {
                            if (RegexHelp.IsDoubleValue(strListTemp[i][n]))
                            {
                                dListValue.Add(double.Parse(strListTemp[i][n]));
                            }
                            else
                            {
                                //System.Windows.Forms.MessageBox.Show("Add NaN");
                                dListValue.Add(double.NaN);
                            }
                        }
                        dGroupListValue.Add(dListValue);
                        strGroupListLotIds.Add(strListLotIds);
                    }
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(GetExceptionInformation(err));
            }

            return dGroupListValue;
        }

        //OVL
        public static List<List<double>> GetOVLItemValues(List<string> strListUsedTime, List<string> strListValue, int index, int count, ref List<List<string>> strGroupListLotIds, List<string> strListLotIds)
        {
            List<List<string>> strListTemp = new List<List<string>>();
            List<List<double>> dGroupListValue = new List<List<double>>();
            try
            {
                GetSortListAndValue(strListUsedTime, ref strListValue, ref strListLotIds);

                strGroupListLotIds.Clear();
                strListTemp = GetItemValues(strListValue);
                //dGroupListValue.Clear();
                if (strListTemp.Count > 0)
                {
                    for (int n = index; n < index + count; n++)
                    {
                        List<double> dListValue = new List<double>();
                        List<string> strListLotIdsNew = new List<string>();

                        for (int i = 0; i < strListTemp.Count; i++)
                        {
                            if (strListTemp[i].Count > n)
                            {
                                if (RegexHelp.IsDoubleValue(strListTemp[i][n]))
                                {
                                    dListValue.Add(double.Parse(strListTemp[i][n]));
                                }
                                else
                                {
                                    //System.Windows.Forms.MessageBox.Show("Add NaN");
                                    dListValue.Add(double.NaN);
                                }
                            }
                            else
                            {
                                //System.Windows.Forms.MessageBox.Show("Add NaN");
                                dListValue.Add(double.NaN);
                            }
                        }
                        dGroupListValue.Add(dListValue);
                        strGroupListLotIds.Add(strListLotIds);
                    }
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(GetExceptionInformation(err));
            }

            return dGroupListValue;
        }

        public static List<List<string>> GetItemValues(List<string> strList)
        {
            List<string> strListTemp = new List<string>();
            List<string> strListFormat = new List<string>();
            List<List<string>> strListResult = new List<List<string>>();

            try
            {
                if (strList.Count > 0)
                {
                    strListFormat = FormatItemValues(strList);
                    foreach (var str in strListFormat)
                    {
                        strListTemp = SplitString(str);
                        strListResult.Add(strListTemp);
                    }
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(GetExceptionInformation(err));
            }

            return strListResult;
        }

        private static List<string> FormatItemValues(List<string> strList)
        {
            List<string> strListResult = new List<string>();
            try
            {
                if (strList.Count > 0)
                {
                    string str;
                    for (int i = 0; i < strList.Count; i++)
                    {
                        str = strList[i].TrimEnd(']');
                        str = str.TrimStart('[');
                        strListResult.Add(str.Trim());
                    }
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(GetExceptionInformation(err));
            }

            return strListResult;
        }
        private static List<string> SplitString(string str)
        {
            List<string> strList = new List<string>();
            try
            {
                if (str != "")
                {
                    string[] strArray = str.Split(new char[] { ' ' });
                    strList = new List<string>(strArray);
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(GetExceptionInformation(err));
            }

            return strList;
        }

        private static string FormatString(string str)
        {
            string strResult = "";
            try
            {
                if (str != "")
                {
                    strResult = str.TrimEnd(']');
                    strResult = strResult.TrimStart('[');
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(GetExceptionInformation(err));
            }

            return strResult.Trim();
        }
        #endregion
    }
}
