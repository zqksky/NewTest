﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;
using static R2R_UI.Common.UIServiceFun;

namespace R2R_UI.Model
{
    class LotRunHistory_Common
    {
        private string strServiceAddress;
        private string strController;
        private List<string> strListR2RContexts = new List<string>();
        structCOMMON_GetLotRunHistory structData = new structCOMMON_GetLotRunHistory();
        public List<int> iListGroupIndexs = new List<int>();
        public List<string> strListGroupNames = new List<string>();
        public List<string> strListCurrentR2RMode = new List<string>();
        public List<List<int>> iGroupListValueIndexs = new List<List<int>>();

        public structGroupValue structGroupData = new structGroupValue();
        public string strCurrentR2RMode;
        public bool bIsActive;
        public bool bNotData;


        private void Test()
        {
            #region
            //structData.iFullInputSize = 10;
            //structData.iFullOutputSize = 10;
            //structData.strListUniqueGroups = new List<string> { "P1" };
            //structData.strListCurrentR2RModes = new List<string> { "Active" };
            //structData.strListInputParameterNameCSVs = new List<string> { "LK_P1_STEP10" };
            //structData.strListOutputParameterNameCSVs = new List<string> { "THK" };
            //structData.strListPMTimeStamps_ByGroup = new List<string> { "2018-11-07T10:15:26.5313242+08:00" };
            //structData.strListResetTimeStamps_ByGroup = new List<string> { "2018-11-07T10:15:26.5313242+08:00" };
            //structData.iListActualInputSizes = new List<int> { 1 };
            //structData.iListActualOutputSizes = new List<int> { 1 };
            //structData.strListLotIds = new List<string> { "DummyLotId" };
            //structData.strListGroups = new List<string> { "P1" };
            //structData.strListInputValues = new List<string> { "[14 14 14 14 14 14 14 14 14 14]" };
            //structData.strListOutputValues = new List<string> { "[1000 1000 1000 1000 1000 1000 1000 1000 1000 1000 ]" };
            //structData.strListIsValidRecords = new List<string> { "False" };
            //structData.strListUsedTimeStamps = new List<string> { "2018-11-10 15:33:25.728" };
            #endregion

            #region
            //structData.iFullInputSize = 10;
            //structData.iFullOutputSize = 10;
            //structData.strListUniqueGroups = new List<string> { "P1", "P2", "P3" };
            //structData.strListCurrentR2RModes = new List<string> { "Active", "Active", "Active" };
            //structData.strListInputParameterNameCSVs = new List<string> { "LK_P1_STEP10", "LK_P2_STEP10", "LK_P3_STEP10" };
            //structData.strListOutputParameterNameCSVs = new List<string> { "THK", "THK", "THK" };
            //structData.strListPMTimeStamps_ByGroup = new List<string> { "2018-11-07T10:15:26.5313242+08:00", "2018-11-07T10:15:26.5313242+08:00", "2018-11-07T10:15:26.5313242+08:00" };
            //structData.strListResetTimeStamps_ByGroup = new List<string> { "2018-11-07T10:15:26.5313242+08:00", "2018-11-07T10:15:26.5313242+08:00", "2018-11-07T10:15:26.5313242+08:00" };
            //structData.iListActualInputSizes = new List<int> { 1, 1, 1, 1, 1, 1, 1, 1, 1 };
            //structData.iListActualOutputSizes = new List<int> { 1, 1, 1, 1, 1, 1, 1, 1, 1 };
            //structData.strListLotIds = new List<string> { "DummyLotId", "DummyLotId", "DummyLotId", "A00002.01", "A00002.01", "A00002.01", "A00001.01", "A00001.01", "A00001.01" };
            //structData.strListGroups = new List<string> { "P1", "P2", "P3", "P3", "P2", "P1", "P3", "P2", "P1" };
            //structData.strListInputValues = new List<string> {"[14 14 14 14 14 14 14 14 14 14]","[14 14 14 14 14 14 14 14 14 14]","[24 24 24 24 24 24 24 24 24 24]","[25 25 25 25 25 25 25 25 25 25] ","[15 15 15 15 15 15 15 15 15 15] ",
            //"[15 15 15 15 15 15 15 15 15 15] ",
            //"[22 22 22 22 22 22 22 22 22 22] ",
            //"[12 12 12 12 12 12 12 12 12 12] ",
            //"[12 12 12 12 12 12 12 12 12 12] "};
            //structData.strListOutputValues = new List<string> { "[1000 1000 1000 1000 1000 1000 1000 1000 1000 1000 ]","[1000 1000 1000 1000 1000 1000 1000 1000 1000 1000 ]","[1000 1000 1000 1000 1000 1000 1000 1000 1000 1000 ]",
            //"[1532 1532 1532 1532 1532 1532 1532 1532 1532 1532 ]",
            //"[1532 1532 1532 1532 1532 1532 1532 1532 1532 1532 ]",
            //"[1532 1532 1532 1532 1532 1532 1532 1532 1532 1532 ]",
            //"[1532 1532 1532 1532 1532 1532 1532 1532 1532 1532 ]",
            //"[1532 1532 1532 1532 1532 1532 1532 1532 1532 1532 ]",
            //"[1532 1532 1532 1532 1532 1532 1532 1532 1532 1532 ]"};
            //structData.strListIsValidRecords = new List<string> { "False", "False", "False", "True", "True", "True", "True", "True", "True" };
            //structData.strListUsedTimeStamps = new List<string> {"2018-11-10 15:33:25.728","2018-11-10 15:33:24.496","2018-11-10 15:33:23.271","2018-11-10 15:33:07.450","2018-11-10 15:33:07.063","2018-11-10 15:33:06.689",
            //"2018-11-07 10:23:35.260",
            //"2018-11-07 10:23:34.891",
            //"2018-11-07 10:23:34.494" };
            #endregion

            #region ETCH
            //            structData.iFullInputSize = 7;
            //            structData.iFullOutputSize = 7;
            //            structData.strListUniqueGroups = new List<string> { "AOXEL03_A" };
            //            structData.strListCurrentR2RModes = new List<string> { "Fix" };
            //            structData.strListInputParameterNameCSVs = new List<string> { "NA" };
            //            structData.strListOutputParameterNameCSVs = new List<string> { "NA" };
            //            structData.strListPMTimeStamps_ByGroup = new List<string> { "NA" };
            //            structData.strListResetTimeStamps_ByGroup = new List<string> { "NA" };
            //            structData.iListActualInputSizes = new List<int> { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
            //            structData.iListActualOutputSizes = new List<int> { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
            //            structData.strListLotIds = new List<string> { "A00030",
            //"A00031",
            //"A00022",
            //"A00021",
            //"A00020",
            //"A00019",
            //"A00018",
            //"A00017",
            //"A00016",
            //"A00015",
            //"A00014",
            //"A00013",
            //"A00011",
            //"A00012",
            //"A00010",
            //"A00009",
            //"A00008" };
            //            structData.strListGroups = new List<string> { "AOXEL03_A",
            //"AOXEL03_A",
            //"AOXEL03_A",
            //"AOXEL03_A",
            //"AOXEL03_A",
            //"AOXEL03_A",
            //"AOXEL03_A",
            //"AOXEL03_A",
            //"AOXEL03_A",
            //"AOXEL03_A",
            //"AOXEL03_A",
            //"AOXEL03_A",
            //"AOXEL03_A",
            //"AOXEL03_A",
            //"AOXEL03_A",
            //"AOXEL03_A",
            //"AOXEL03_A" };
            //            structData.strListInputValues = new List<string> {"[ 500 0 0 0 0 0 0 ]",
            //"[ NaN NaN NaN NaN NaN NaN NaN ]",
            //"[ 500 0 0 0 0 0 0 ]",
            //"[ 500 0 0 0 0 0 0 ]",
            //"[ NaN NaN NaN NaN NaN NaN NaN ]",
            //"[ 500 0 0 0 0 0 0 ]",
            //"[ 500 0 0 0 0 0 0 ]",
            //"[ 500 0 0 0 0 0 0 ]",
            //"[ 500 0 0 0 0 0 0 ]",
            //"[ 500 0 0 0 0 0 0 ]",
            //"[ 500 0 0 0 0 0 0 ]",
            //"[ 500 0 0 0 0 0 0 ]",
            //"[ 500 0 0 0 0 0 0 ]",
            //"[ NaN NaN NaN NaN NaN NaN NaN ]",
            //"[ NaN NaN NaN NaN NaN NaN NaN ]",
            //"[ 500 0 0 0 0 0 0 ]",
            //"[ 500 0 0 0 0 0 0 ]"};
            //            structData.strListOutputValues = new List<string> { "[ 0.178433333333333 0 0 0 0 0 0 ]",
            //"[ NaN NaN NaN NaN NaN NaN NaN ]",
            //"[ 0.178433333333333 0 0 0 0 0 0 ]",
            //"[ 0.178433333333333 0 0 0 0 0 0 ]",
            //"[ NaN NaN NaN NaN NaN NaN NaN ]",
            //"[ 0.178433333333333 0 0 0 0 0 0 ]",
            //"[ 0.178433333333333 0 0 0 0 0 0 ]",
            //"[ 0.178433333333333 0 0 0 0 0 0 ]",
            //"[ 0.178433333333333 0 0 0 0 0 0 ]",
            //"[ 0.178433333333333 0 0 0 0 0 0 ]",
            //"[ 0.178433333333333 0 0 0 0 0 0 ]",
            //"[ 0.178433333333333 0 0 0 0 0 0 ]",
            //"[ 0.178433333333333 0 0 0 0 0 0 ]",
            //"[ NaN NaN NaN NaN NaN NaN NaN ]",
            //"[ NaN NaN NaN NaN NaN NaN NaN ]",
            //"[ 0.178433333333333 0 0 0 0 0 0 ]",
            //"[ 0.178433333333333 0 0 0 0 0 0 ]"};
            //            structData.strListIsValidRecords = new List<string> { "False",
            //"False",
            //"False",
            //"False",
            //"False",
            //"False",
            //"False",
            //"False",
            //"False",
            //"False",
            //"False",
            //"False",
            //"False",
            //"False",
            //"False",
            //"True",
            //"True" };
            //            structData.strListUsedTimeStamps = new List<string> {"2018-11-11 17:41:19.025",
            //"2018-11-11 17:39:20.766",
            //"2018-11-11 17:16:23.248",
            //"2018-11-11 17:16:13.856",
            //"2018-11-11 15:19:01.159",
            //"2018-11-11 15:17:56.113",
            //"2018-11-11 15:16:33.089",
            //"2018-11-11 15:14:32.563",
            //"2018-11-11 15:10:27.885",
            //"2018-11-11 15:02:22.348",
            //"2018-11-11 14:59:37.313",
            //"2018-11-11 14:44:37.625",
            //"2018-11-11 14:27:13.598",
            //"2018-11-11 14:27:10.943",
            //"2018-11-11 14:15:46.683",
            //"2018-11-11 14:14:09.966",
            //"2018-11-11 13:55:35.4654" };
            #endregion

            #region CMP
            //structData.iFullInputSize = 10;
            //structData.iFullOutputSize = 10;
            //structData.strListUniqueGroups = new List<string> { "P3", "P2", "P1" };
            //structData.strListCurrentR2RModes = new List<string> { "Active", "Active", "Active" };
            //structData.strListInputParameterNameCSVs = new List<string> { "LK_P3_STEP10", "LK_P2_STEP10", "LK_P1_STEP10" };
            //structData.strListOutputParameterNameCSVs = new List<string> { "THK", "THK", "THK" };
            //structData.strListPMTimeStamps_ByGroup = new List<string> { "2018-12-07T11:26:44.1987343+08:00", "2018-12-07T11:26:44.1987343+08:00", "2018-12-07T11:26:44.1987343+08:00" };
            //structData.strListResetTimeStamps_ByGroup = new List<string> { "2018-12-07T11:26:44.1987343+08:00", "2018-12-07T11:26:44.1987343+08:00", "2018-12-07T11:26:44.1987343+08:00" };
            //structData.iListActualInputSizes = new List<int> { 1, 1, 1};
            //structData.iListActualOutputSizes = new List<int> { 1, 1, 1};
            //structData.strListLotIds = new List<string> {  "A00002.01", "A00002.01", "A00002.01" };
            //structData.strListGroups = new List<string> { "P3", "P2", "P1" };
            //structData.strListInputValues = new List<string> {"[25 25 25 25 25 25 25 25 25 25 ]", "[15 15 15 15 15 15 15 15 15 15]", "[15 15 15 15 15 15 15 15 15 15]" };
            //structData.strListOutputValues = new List<string> { "[ 1532 1532 1532 1532 1532 1532 1532 1532 1532 1532 ]", "[ 1532 1532 1532 1532 1532 1532 1532 1532 1532 1532 ]", "[ 1532 1532 1532 1532 1532 1532 1532 1532 1532 1532 ]" };
            //structData.strListIsValidRecords = new List<string> { "True", "False", "True" };
            //structData.strListUsedTimeStamps = new List<string> {"2018-12-07 11:27:49.659","2018-12-07 11:27:49.232","2018-12-07 11:27:48.688" };
            #endregion

            #region CMP
            structData.iFullInputSize = 7;
            structData.iFullOutputSize = 7;
            structData.strListUniqueGroups = new List<string> { "ANOSA03_B" };
            structData.strListCurrentR2RModes = new List<string> { "Active"};
            structData.strListInputParameterNameCSVs = new List<string> { "CHB_TEOS1450A_DepTime,CHB_TEOS295A_DepTime,CHB_LS200_SIN410A_DepTime" };
            structData.strListOutputParameterNameCSVs = new List<string> { "THK1,THK2,THK3" };
            structData.strListPMTimeStamps_ByGroup = new List<string> { "NA" };
            structData.strListResetTimeStamps_ByGroup = new List<string> { "NA" };
            structData.iListActualInputSizes = new List<int> { 3, 3, 3,3,3 };
            structData.iListActualOutputSizes = new List<int> { 3, 3, 3, 3, 3 };
            structData.strListLotIds = new List<string> { "G00006","G00004","G00003","G00002","G00001" };
            structData.strListGroups = new List<string> { "ANOSA03_B",
"ANOSA03_B",
"ANOSA03_B",
"ANOSA03_B",
"ANOSA03_B" };
            structData.strListInputValues = new List<string> { "[ NaN NaN NaN NaN NaN NaN NaN ]",
"[ 513.46 524.71 513.5 0 0 0 0 ]",
"[ 513.48 524.84 513.5 0 0 0 0 ]",
"[ 513.48 524.87 513.5 0 0 0 0 ]",
"[ 513.5 525 513.5 NaN NaN NaN NaN ]" };
            structData.strListOutputValues = new List<string> { "[ NaN NaN NaN NaN NaN NaN NaN ]",
"[ 41 35.3333333333333 35.3333333333333 0 0 0 0 ]",
"[ 41 35.3333333333333 35.3333333333333 0 0 0 0 ]",
"[ 41 35.3333333333333 35.3333333333333 0 0 0 0 ]",
"[ 41 35.3333333333333 35.3333333333333 0 0 0 0 ]" };
            structData.strListIsValidRecords = new List<string> {"False", "True", "False", "False", "False"};
            structData.strListUsedTimeStamps = new List<string> { "2018-12-28 11:24:07.040",
"2018-12-28 11:01:42.554",
"2018-12-28 10:52:54.315",
"2018-12-28 10:32:25.494",
"2018-12-28 10:31:11.375" };
            #endregion
        }

        public LotRunHistory_Common(string strServiceAddress, string strController, List<string> strListR2RContexts,int iListOfRuns, int ListLotType)
        {
            this.strServiceAddress = strServiceAddress;
            this.strController = strController;
            this.strListR2RContexts = new List<string>(strListR2RContexts);

            structCOMMON_GetLotRunHistory structDataNull = new structCOMMON_GetLotRunHistory();
            structCOMMON_GetLotRunHistory structDataAll = new structCOMMON_GetLotRunHistory();
            structDataAll = R2R_UI_COMMON_GetLotRunHistory(ref strServiceAddress, strController, strListR2RContexts, iListOfRuns);
            if (structDataAll.Equals(structDataNull))
            {
                bNotData = true;
            }
            else
            {
                try
                {
                    if (ListLotType == 1)
                    {
                        //Test();

                        this.structData = structDataAll; 
                        if (structData.strListInputValues.Count < 1 || structData.strListOutputValues.Count < 1 || structData.iListActualInputSizes.Count < 1 || structData.iListActualOutputSizes.Count < 1)
                        {
                            bNotData = true;
                            return;
                        }
                    }
                    else if (ListLotType == 2)
                    {
                        //Test();
                        //this.structData = ListLotsValid(structData);

                        this.structData = ListLotsValid(structDataAll);

                        if (structData.strListIsValidRecords.Count < 1)
                        {
                            bNotData = true;
                            return;
                        }
                    }
                    else if (ListLotType == 3)
                    {
                        //Test();
                        //this.structData = ListLotsWithMetrology(structData);

                        this.structData = ListLotsWithMetrology(structDataAll);

                        if (structData.strListInputValues.Count < 1 || structData.strListOutputValues.Count < 1)
                        {
                            bNotData = true;
                            return;
                        }
                    }

                    this.iListGroupIndexs = GetGroupIndex();
                    this.strListGroupNames = GetGroupName(iListGroupIndexs);
                    this.strListCurrentR2RMode = GetGroupR2RMode(iListGroupIndexs);
                    this.iGroupListValueIndexs = GetGroupValueIndex(strListGroupNames, structData.strListGroups);
                    this.structGroupData = GetStructGroupValue();

                    //this.strCurrentR2RMode = structData.strCurrentR2RMode;
                    //this.bIsActive = IsActive(this.strCurrentR2RMode);
                }
                catch (Exception err)
                {
                    System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
        }

        private bool IsActive(string strR2RMode)
        {
            bool flag = false;
            if (strR2RMode.Equals("Active"))
            {
                flag = true;
            }
            else
            {
                //btnOptReset.Enabled = false;
            }
            return flag;
        }

        private List<string> GetGroupR2RMode(List<int> strGroupIndex)
        {
            List<string> strList = new List<string>();
            try
            {
                for (int i = 0; i < strGroupIndex.Count; i++)
                {
                    strList.Add(structData.strListCurrentR2RModes[strGroupIndex[i]]);
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            return strList;
        }

        private List<int> GetGroupIndex()
        {
            List<int> iListIndexs = new List<int>();
            List<string> strList = new List<string>(structData.strListUniqueGroups);
            try
            {
                if (strList.Count > 0)
                {
                    strList.Sort();
                    foreach (var str in strList)
                    {
                        int index = structData.strListUniqueGroups.FindIndex(item => item.Equals(str));
                        iListIndexs.Add(index);
                    }
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            return iListIndexs;
        }

        private List<string> GetGroupName(List<int> iListIndex)
        {
            List<string> strList = new List<string>();
            try
            {
                for (int i = 0; i < iListIndex.Count; i++)
                {
                    strList.Add(structData.strListUniqueGroups[iListIndex[i]]);
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            return strList;
        }

        private List<List<int>> GetGroupValueIndex(List<string> strListGroupName, List<string> strListGroups)
        {
            List<List<int>> iListIndexs = new List<List<int>>();
            try
            {
                foreach (var str in strListGroupName)
                {
                    List<int> iListIndex = new List<int>();
                    for (int i = 0; i < strListGroups.Count; i++)
                    {
                        if (str.Equals(strListGroups[i]))
                        {
                            iListIndex.Add(i);
                        }
                    }
                    iListIndexs.Add(iListIndex);
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            return iListIndexs;
        }

        public struct structGroupValue
        {
            public List<List<int>> iListGroupActualInputSizes;
            public List<List<int>> iListGroupActualOutputSizes;
            public List<List<string>> strListGroupLotIds;
            public List<List<string>> strListGroupUsedTimeStamps;
            public List<List<string>> strListGroupInputValues;
            public List<List<string>> strListGroupOutputValues;
            public List<List<string>> strListGroupInputNames;
            public List<List<string>> strListGroupOutputNames;
            public List<string> strListGroupPMTimeStamps;
            public List<string> strListGroupResetTimeStamps;
        };

        private List<string> SplitString(string str)
        {
            List<string> strList = new List<string>();
            if (str.Contains(","))
            {
                string[] strArray = str.Split(',');
                strList = new List<string>(strArray.ToList());
            }
            else
            {
                strList.Add(str);
            }
            return strList;
        }

        private structGroupValue GetStructGroupValue()
        {
            List<List<string>> strListGroupLotIds = new List<List<string>>();
            List<List<string>> strListGroupUsedTimeStamps = new List<List<string>>();
            List<List<string>> strListGroupInputValues = new List<List<string>>();
            List<List<string>> strListGroupOutputValues = new List<List<string>>();
            List<List<int>> iListGroupActualInputSizes = new List<List<int>>();
            List<List<int>> iListGroupActualOutputSizes = new List<List<int>>();

            List<List<string>> strListGroupInputNames = new List<List<string>>();
            List<List<string>> strListGroupOutputNames = new List<List<string>>();
            List<string> strListGroupPMTimeStamps = new List<string>();
            List<string> strListGroupResetTimeStamps = new List<string>();
            List<string> strListCurrentR2RModes = new List<string>();

            structGroupValue structValue = new structGroupValue();
            try
            {
                for (int i = 0; i < iListGroupIndexs.Count; i++)
                {
                    strListGroupInputNames.Add(SplitString(structData.strListInputParameterNameCSVs[iListGroupIndexs[i]]));
                    strListGroupOutputNames.Add(SplitString(structData.strListOutputParameterNameCSVs[iListGroupIndexs[i]]));
                    strListGroupPMTimeStamps.Add(structData.strListPMTimeStamps_ByGroup[iListGroupIndexs[i]]);
                    strListGroupResetTimeStamps.Add(structData.strListResetTimeStamps_ByGroup[iListGroupIndexs[i]]);
                    strListCurrentR2RModes.Add(structData.strListCurrentR2RModes[iListGroupIndexs[i]]);
                }

                for (int i = 0; i < iGroupListValueIndexs.Count; i++)
                {
                    List<string> strListLotIdsTemp = new List<string>();
                    List<string> strListUsedTimeStampsTemp = new List<string>();
                    List<string> strListInputValuesTemp = new List<string>();
                    List<string> strListOutputValuesTemp = new List<string>();
                    List<int> iListActualInputSizesTemp = new List<int>();
                    List<int> iListActualOutputSizesTemp = new List<int>();
                    for (int t = 0; t < iGroupListValueIndexs[i].Count; t++)
                    {
                        strListLotIdsTemp.Add(structData.strListLotIds[iGroupListValueIndexs[i][t]]);
                        strListUsedTimeStampsTemp.Add(structData.strListUsedTimeStamps[iGroupListValueIndexs[i][t]]);
                        strListInputValuesTemp.Add(structData.strListInputValues[iGroupListValueIndexs[i][t]]);
                        strListOutputValuesTemp.Add(structData.strListOutputValues[iGroupListValueIndexs[i][t]]);
                        iListActualInputSizesTemp.Add(structData.iListActualInputSizes[iGroupListValueIndexs[i][t]]);
                        iListActualOutputSizesTemp.Add(structData.iListActualOutputSizes[iGroupListValueIndexs[i][t]]);
                    }
                    strListGroupLotIds.Add(strListLotIdsTemp);
                    strListGroupUsedTimeStamps.Add(strListUsedTimeStampsTemp);
                    strListGroupInputValues.Add(strListInputValuesTemp);
                    strListGroupOutputValues.Add(strListOutputValuesTemp);
                    iListGroupActualInputSizes.Add(iListActualInputSizesTemp);
                    iListGroupActualOutputSizes.Add(iListActualOutputSizesTemp);
                }
                structValue.strListGroupLotIds = new List<List<string>>(strListGroupLotIds);
                structValue.strListGroupUsedTimeStamps = new List<List<string>>(strListGroupUsedTimeStamps);
                structValue.strListGroupInputValues = new List<List<string>>(strListGroupInputValues);
                structValue.strListGroupOutputValues = new List<List<string>>(strListGroupOutputValues);
                structValue.iListGroupActualInputSizes = new List<List<int>>(iListGroupActualInputSizes);
                structValue.iListGroupActualOutputSizes = new List<List<int>>(iListGroupActualOutputSizes);
                structValue.strListGroupInputNames = new List<List<string>>(strListGroupInputNames);
                structValue.strListGroupOutputNames = new List<List<string>>(strListGroupOutputNames);
                structValue.strListGroupPMTimeStamps = new List<string>(strListGroupPMTimeStamps);
                structValue.strListGroupResetTimeStamps = new List<string>(strListGroupResetTimeStamps);
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }

            return structValue;
        }

        private static structCOMMON_GetLotRunHistory ListLotsValid(structCOMMON_GetLotRunHistory structData)
        {
            structCOMMON_GetLotRunHistory structDataNew = new structCOMMON_GetLotRunHistory();
            structDataNew.iListActualInputSizes = new List<int>();
            structDataNew.iListActualOutputSizes = new List<int>();
            structDataNew.strListIsValidRecords = new List<string>();
            structDataNew.strListLotIds = new List<string>();
            structDataNew.strListUsedTimeStamps = new List<string>();
            structDataNew.strListInputValues = new List<string>();
            structDataNew.strListOutputValues = new List<string>();
            structDataNew.strListGroups = new List<string>();
            structDataNew.strListInputParameterNameCSVs = new List<string>();
            structDataNew.strListOutputParameterNameCSVs = new List<string>();
            structDataNew.strListPMTimeStamps_ByGroup = new List<string>();
            structDataNew.strListResetTimeStamps_ByGroup = new List<string>();
            structDataNew.strListUniqueGroups = new List<string>();
            structDataNew.strListCurrentR2RModes = new List<string>();

            try
            {
                if (structData.strListUniqueGroups.Count > 0)
                {
                    structDataNew.iFullInputSize = structData.iFullInputSize;
                    structDataNew.iFullOutputSize = structData.iFullOutputSize;
                    structDataNew.strListUniqueGroups = new List<string>(structData.strListUniqueGroups);
                    structDataNew.strListInputParameterNameCSVs = new List<string>(structData.strListInputParameterNameCSVs);
                    structDataNew.strListOutputParameterNameCSVs = new List<string>(structData.strListOutputParameterNameCSVs);
                    structDataNew.strListPMTimeStamps_ByGroup = new List<string>(structData.strListPMTimeStamps_ByGroup);
                    structDataNew.strListResetTimeStamps_ByGroup = new List<string>(structData.strListResetTimeStamps_ByGroup);
                    structDataNew.strListCurrentR2RModes = new List<string>(structData.strListCurrentR2RModes);
                }

                if (structData.strListIsValidRecords.Count > 0)
                {
                    for (int i = 0; i < structData.strListIsValidRecords.Count; i++)
                    {
                        if (structData.strListIsValidRecords[i].Equals("True"))
                        {
                            structDataNew.iListActualInputSizes.Add(structData.iListActualInputSizes[i]);
                            structDataNew.iListActualOutputSizes.Add(structData.iListActualOutputSizes[i]);
                            structDataNew.strListIsValidRecords.Add(structData.strListIsValidRecords[i]);
                            structDataNew.strListLotIds.Add(structData.strListLotIds[i]);
                            structDataNew.strListUsedTimeStamps.Add(structData.strListUsedTimeStamps[i]);
                            structDataNew.strListInputValues.Add(structData.strListInputValues[i]);
                            structDataNew.strListOutputValues.Add(structData.strListOutputValues[i]);
                            structDataNew.strListGroups.Add(structData.strListGroups[i]);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }

            return structDataNew;
        }

        private static structCOMMON_GetLotRunHistory ListLotsWithMetrology(structCOMMON_GetLotRunHistory structData)
        {
            structCOMMON_GetLotRunHistory structDataNew = new structCOMMON_GetLotRunHistory();
            structDataNew.iListActualInputSizes = new List<int>();
            structDataNew.iListActualOutputSizes = new List<int>();
            structDataNew.strListIsValidRecords = new List<string>();
            structDataNew.strListLotIds = new List<string>();
            structDataNew.strListUsedTimeStamps = new List<string>();
            structDataNew.strListInputValues = new List<string>();
            structDataNew.strListOutputValues = new List<string>();
            structDataNew.strListGroups = new List<string>();
            structDataNew.strListInputParameterNameCSVs = new List<string>();
            structDataNew.strListOutputParameterNameCSVs = new List<string>();
            structDataNew.strListPMTimeStamps_ByGroup = new List<string>();
            structDataNew.strListResetTimeStamps_ByGroup = new List<string>();
            structDataNew.strListUniqueGroups = new List<string>();
            structDataNew.strListCurrentR2RModes = new List<string>();
            structDataNew.iFullInputSize = 0;
            structDataNew.iFullOutputSize = 0;

            try
            {
                if (structData.strListUniqueGroups.Count > 0)
                {
                    structDataNew.iFullInputSize = structData.iFullInputSize;
                    structDataNew.iFullOutputSize = structData.iFullOutputSize;
                    structDataNew.strListUniqueGroups = new List<string>(structData.strListUniqueGroups);
                    structDataNew.strListInputParameterNameCSVs = new List<string>(structData.strListInputParameterNameCSVs);
                    structDataNew.strListOutputParameterNameCSVs = new List<string>(structData.strListOutputParameterNameCSVs);
                    structDataNew.strListPMTimeStamps_ByGroup = new List<string>(structData.strListPMTimeStamps_ByGroup);
                    structDataNew.strListResetTimeStamps_ByGroup = new List<string>(structData.strListResetTimeStamps_ByGroup);
                    structDataNew.strListCurrentR2RModes = new List<string>(structData.strListCurrentR2RModes);
                }

                for (int i = 0; i < structData.strListOutputValues.Count; i++)
                {
                    if (!structData.strListOutputValues[i].Contains("NaN"))
                    {
                        structDataNew.iListActualInputSizes.Add(structData.iListActualInputSizes[i]);
                        structDataNew.iListActualOutputSizes.Add(structData.iListActualOutputSizes[i]);
                        structDataNew.strListIsValidRecords.Add(structData.strListIsValidRecords[i]);
                        structDataNew.strListLotIds.Add(structData.strListLotIds[i]);
                        structDataNew.strListUsedTimeStamps.Add(structData.strListUsedTimeStamps[i]);
                        structDataNew.strListInputValues.Add(structData.strListInputValues[i]);
                        structDataNew.strListOutputValues.Add(structData.strListOutputValues[i]);
                        structDataNew.strListGroups.Add(structData.strListGroups[i]);
                    }
                }
            }
            catch(Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            
            return structDataNew;
        }

        #region New
        public string GetR2RMode(string strName)
        {
            string strR2RMode = "";
            int index = strListGroupNames.IndexOf(strName);
            strR2RMode = strListCurrentR2RMode[index];

            return strR2RMode;
        }

        public struct structGroup
        {
            public int index;
            public string strName;
            public DataTable db;
            public List<Chart> ctlListInputChart;
            public List<Chart> ctlListOutputChart;
        };

        public structGroup GetGroup(string strName)
        {
            structGroup structData = new structGroup();
            try
            {
                int index = strListGroupNames.IndexOf(strName);

                structData.ctlListInputChart = new List<Chart>();
                structData.ctlListOutputChart = new List<Chart>();

                List<List<string>> strGroupListLotIdsInput = new List<List<string>>();
                List<List<string>> strGroupListLotIdsOutput = new List<List<string>>();

                List<List<double>> dListInputValuesResultGroup = new List<List<double>>();
                List<List<double>> dListOutputValuesResultGroup = new List<List<double>>();


                structData.index = index;
                structData.strName = strName;
                structData.db = new DataTable();

                if (structGroupData.strListGroupLotIds[index].Count > 0 && structGroupData.strListGroupUsedTimeStamps[index].Count > 0 && structGroupData.strListGroupInputValues[index].Count > 0)
                {
                    structData.db = DataTableHelp.CreateCommonTableNew(structGroupData.strListGroupLotIds[index], structGroupData.strListGroupUsedTimeStamps[index], structGroupData.strListGroupInputValues[index], structGroupData.strListGroupOutputValues[index], structGroupData.strListGroupInputNames[index], structGroupData.strListGroupOutputNames[index], structGroupData.iListGroupActualInputSizes[index], structGroupData.iListGroupActualOutputSizes[index]);
                }

                if (structGroupData.strListGroupUsedTimeStamps[index].Count > 0 && structGroupData.strListGroupInputValues[index].Count > 0 && structGroupData.strListGroupLotIds[index].Count > 0)
                {
                    dListInputValuesResultGroup = BaseFun.GetCommonItemValues(structGroupData.strListGroupUsedTimeStamps[index], structGroupData.strListGroupInputValues[index], ref strGroupListLotIdsInput, structGroupData.strListGroupLotIds[index]);
                }

                if (structGroupData.strListGroupUsedTimeStamps[index].Count > 0 && structGroupData.strListGroupOutputValues[index].Count > 0 && structGroupData.strListGroupLotIds[index].Count > 0)
                {
                    dListOutputValuesResultGroup = BaseFun.GetCommonItemValues(structGroupData.strListGroupUsedTimeStamps[index], structGroupData.strListGroupOutputValues[index], ref strGroupListLotIdsOutput, structGroupData.strListGroupLotIds[index]);
                }

                int chartInputNumber = dListInputValuesResultGroup.Count();
                if (chartInputNumber > 0)
                {
                    int pmNum = BaseFun.GetPMResetTimeValue(structGroupData.strListGroupPMTimeStamps[index], structGroupData.strListGroupUsedTimeStamps[index]);
                    int resetNum = BaseFun.GetPMResetTimeValue(structGroupData.strListGroupResetTimeStamps[index], structGroupData.strListGroupUsedTimeStamps[index]);
                    structData.ctlListInputChart = AddControlHelp.GetCommonChart(2, structGroupData.strListGroupInputNames[index], dListInputValuesResultGroup, strGroupListLotIdsInput, pmNum, resetNum, structGroupData.iListGroupActualInputSizes[index][0]);
                }

                int chartOutputNumber = dListOutputValuesResultGroup.Count();
                if (chartOutputNumber > 0)
                {
                    int pmNum = BaseFun.GetPMResetTimeValue(structGroupData.strListGroupPMTimeStamps[index], structGroupData.strListGroupUsedTimeStamps[index]);
                    int resetNum = BaseFun.GetPMResetTimeValue(structGroupData.strListGroupResetTimeStamps[index], structGroupData.strListGroupUsedTimeStamps[index]);
                    structData.ctlListOutputChart = AddControlHelp.GetCommonChart(2, structGroupData.strListGroupOutputNames[index], dListOutputValuesResultGroup, strGroupListLotIdsOutput, pmNum, resetNum, structGroupData.iListGroupActualOutputSizes[index][0]);
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }

            return structData;
        }
        #endregion
    }
}
