﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;
using static R2R_UI.Common.UIServiceFun;

namespace R2R_UI.Model
{
    class LotRunHistory_Focus
    {
        private string strServiceAddress;
        private List<string> strListR2RContexts = new List<string>();
        structPH_Focus_GetLotRunHistory structData = new structPH_Focus_GetLotRunHistory();
        public string strCurrentR2RMode;
        public bool bIsFixed;
        public bool bNotData;

        private void Test()
        {
            #region
            structData.strCurrentR2RMode = "Fixed";
            structData.strPMTimeStamp = "NA";
            structData.strResetTimeStamp = "NA";
            structData.strListCD = new List<string> { "[ NaN ]", "[ 10 ]" };
            structData.strListFocus= new List<string> { "[ NaN ]", "[ 0.3]" };
            structData.strListLotIds = new List<string> { "TESTLOT01.01","TESTLOT06.01"};
            structData.strListIsValidRecords = new List<string> { "False", "False" };
            structData.strListUsedTimeStamps = new List<string> { "2018-12-01 14:34:20.789","2018-11-27 10:29:12.176" };
            #endregion
        }

        public LotRunHistory_Focus(string strServiceAddress, List<string> strListR2RContexts, int iListOfRuns, int ListLotType)
        {
            this.strServiceAddress = strServiceAddress;
            this.strListR2RContexts = new List<string>(strListR2RContexts);

            structPH_Focus_GetLotRunHistory structDataNull = new structPH_Focus_GetLotRunHistory();
            structPH_Focus_GetLotRunHistory structDataAll = new structPH_Focus_GetLotRunHistory();
            structDataAll = R2R_UI_PH_Focus_GetLotRunHistory(ref strServiceAddress, strListR2RContexts, iListOfRuns);
            if (structDataAll.Equals(structDataNull))
            {
                bNotData = true;
            }
            else
            {
                try
                {
                    if (ListLotType == 1)
                    {
                        //Test();

                        this.structData = structDataAll;

                        if (structData.strListCD.Count < 1 || structData.strListFocus.Count < 1)
                        {
                            bNotData = true;
                            return;
                        }
                    }
                    else if (ListLotType == 2)
                    {
                        //Test();
                        //this.structData = ListLotsValid(structData);

                        this.structData = ListLotsValid(structDataAll);

                        if (structData.strListIsValidRecords.Count < 1)
                        {
                            bNotData = true;
                            return;
                        }
                    }
                    else if (ListLotType == 3)
                    {
                        //Test();
                        //this.structData = ListLotsWithMetrology(structData);

                        this.structData = ListLotsWithMetrology(structDataAll);

                        if (structData.strListCD.Count < 1 || structData.strListFocus.Count < 1)
                        {
                            bNotData = true;
                            return;
                        }
                    }
                    this.strCurrentR2RMode = structData.strCurrentR2RMode;
                    //this.bIsFixed = IsFixed(this.strCurrentR2RMode);
                    this.bIsFixed = true;
                }
                catch (Exception err)
                {
                    System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
        }

        private bool IsFixed(string strR2RMode)
        {
            bool flag = false;
            if (strR2RMode.Equals("Fixed"))
            {
                flag = true;
            }
            else
            {
                //btnOptReset.Enabled = false;
            }
            return flag;
        }
        private bool IsActive(string strR2RMode)
        {
            bool flag = false;
            if (strR2RMode.Equals("Active"))
            {
                flag = true;
            }
            else
            {
                //btnOptReset.Enabled = false;
            }
            return flag;
        }

        private structPH_Focus_GetLotRunHistory ListLotsWithMetrology(structPH_Focus_GetLotRunHistory structData)
        {
            structPH_Focus_GetLotRunHistory structDataNew = new structPH_Focus_GetLotRunHistory();
            structDataNew.strCurrentR2RMode = structData.strCurrentR2RMode;
            structDataNew.strListIsValidRecords = new List<string>();
            structDataNew.strListLotIds = new List<string>();
            structDataNew.strListUsedTimeStamps = new List<string>();
            structDataNew.strListCD = new List<string>();
            structDataNew.strListFocus = new List<string>();

            try
            {
                if (structData.strListCD.Count > 0)
                {
                    for (int i = 0; i < structData.strListCD.Count; i++)
                    {
                        if (!structData.strListCD[i].Equals("[ NaN ]"))
                        {
                            structDataNew.strListIsValidRecords.Add(structData.strListIsValidRecords[i]);
                            structDataNew.strListLotIds.Add(structData.strListLotIds[i]);
                            structDataNew.strListUsedTimeStamps.Add(structData.strListUsedTimeStamps[i]);
                            structDataNew.strListCD.Add(structData.strListCD[i]);
                            structDataNew.strListFocus.Add(structData.strListFocus[i]);
                        }
                    }
                    structDataNew.strPMTimeStamp = structData.strPMTimeStamp;
                    structDataNew.strResetTimeStamp = structData.strResetTimeStamp;
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            return structDataNew;
        }

        private structPH_Focus_GetLotRunHistory ListLotsValid(structPH_Focus_GetLotRunHistory structData)
        {
            structPH_Focus_GetLotRunHistory structDataNew = new structPH_Focus_GetLotRunHistory();
            structDataNew.strCurrentR2RMode = structData.strCurrentR2RMode;
            structDataNew.strListIsValidRecords = new List<string>();
            structDataNew.strListLotIds = new List<string>();
            structDataNew.strListUsedTimeStamps = new List<string>();
            structDataNew.strListCD = new List<string>();
            structDataNew.strListFocus = new List<string>();
            try
            {
                if (structData.strListIsValidRecords.Count > 0)
                {
                    for (int i = 0; i < structData.strListIsValidRecords.Count; i++)
                    {
                        if (structData.strListIsValidRecords[i].Equals("True"))
                        {
                            structDataNew.strListIsValidRecords.Add(structData.strListIsValidRecords[i]);
                            structDataNew.strListLotIds.Add(structData.strListLotIds[i]);
                            structDataNew.strListUsedTimeStamps.Add(structData.strListUsedTimeStamps[i]);
                            structDataNew.strListCD.Add(structData.strListCD[i]);
                            structDataNew.strListFocus.Add(structData.strListFocus[i]);
                        }
                    }
                    structDataNew.strPMTimeStamp = structData.strPMTimeStamp;
                    structDataNew.strResetTimeStamp = structData.strResetTimeStamp;
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            return structDataNew;
        }

        public DataTable GetTable()
        {
            DataTable db = new DataTable();
            //db = DataTableHelp.CreateCDFocusTable(structData.strListLotIds, structData.strListUsedTimeStamps, structData.strListFocus, structData.strListCD,"Focus_","CD_");
            db = DataTableHelp.CreateCDFocusTableNew(structData.strListLotIds, structData.strListUsedTimeStamps, structData.strListFocus, structData.strListCD, "Focus", "CD");

            return db;
        }

        private List<string> GetChartName(int chartNum, int chartType)
        {
            List<string> strListName = new List<string>();
            for (int i = 0; i < chartNum; i++)
            {
                if (chartType == 1)
                {
                    strListName.Add("Focus");//_" + (i + 1));
                }
                else if (chartType == 2)
                {
                    strListName.Add("CD");//_" + (i + 1));
                }
            }
            return strListName;
        }
        public List<Chart> GetChart(int chartNametype, int chartType)
        {
            int chartNumber;
            List<Chart> ctlListChart = new List<Chart>();
            List<string> strListNames = new List<string>();
            List<List<double>> dGroupListItemValues = new List<List<double>>();

            dGroupListItemValues.Clear();

            List<List<string>> strGroupListLotIds = new List<List<string>>();
            try
            {
                if (chartNametype == 1)
                {
                    if (structData.strListUsedTimeStamps.Count > 0 && structData.strListFocus.Count > 0 && structData.strListLotIds.Count > 0)
                    {
                        dGroupListItemValues = BaseFun.GetCommonItemValues(structData.strListUsedTimeStamps, structData.strListFocus, ref strGroupListLotIds, structData.strListLotIds);
                    }
                }
                else
                {
                    if (structData.strListUsedTimeStamps.Count > 0 && structData.strListCD.Count > 0 && structData.strListLotIds.Count > 0)
                    {
                        dGroupListItemValues = BaseFun.GetCommonItemValues(structData.strListUsedTimeStamps, structData.strListCD, ref strGroupListLotIds, structData.strListLotIds);
                    }
                }
                if (dGroupListItemValues.Count > 0)
                {
                    chartNumber = dGroupListItemValues.Count();
                    strListNames = GetChartName(chartNumber, chartNametype);

                    int pmNum = BaseFun.GetPMResetTimeValue(structData.strPMTimeStamp, structData.strListUsedTimeStamps);
                    int resetNum = BaseFun.GetPMResetTimeValue(structData.strResetTimeStamp, structData.strListUsedTimeStamps);
                    ctlListChart = AddControlHelp.GetCDFocusChart(chartType, strListNames, dGroupListItemValues, strGroupListLotIds, pmNum, resetNum);

                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            return ctlListChart;
        }
    }
}
