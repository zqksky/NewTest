﻿using Microsoft.CSharp.RuntimeBinder;
using mshtml;
using R2R_UI.Common;
using R2R_UI.Model;
using R2R_UI.Present.BatchOperation;
using R2R_UI.Present.Common;
using R2R_UI.Present.OVL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using MaterialSkin;
using MaterialSkin.Controls;

namespace R2R_UI
{
    public partial class frmMain : MaterialForm
    {
        //private readonly MaterialSkinManager meterialSkinManager;

        #region
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0014) // 禁掉清除背景消息
                return;
            base.WndProc(ref m);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;
                return cp;
            }
        }

        private void CtlDoubleBuffer()
        {
            this.DoubleBuffered = true;//设置本窗体
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲
            //SetStyle(ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
            UpdateStyles();
        }
        #endregion

        public frmMain()
        {
            #region Login 
            frmLogin frm = new frmLogin();
            if (frm.ShowDialog() != DialogResult.OK)
            {
                System.Environment.Exit(0);
            }
            strDomainName = frm.strDomainName;
            strUserName = frm.strUserName;
            strPassword = frm.strPassword;
            strServiceAddress = frm.strServerAddressNew;
            strServiceType = frm.strServerType;
            #endregion

            #region UIService
            strListModule = UIServiceFun.R2R_UI_GetModule(strUserName, ref strServiceAddress);
           
            #endregion

            InitializeComponent();

            #region SetSkin
            SkinHelp.SkinSet(this, strServiceType);
            #endregion
        }

        #region Param Define
        const string STR_VERSION = "Version: V1.2.6";
        const int OVL_LINEAR = 1;
        const int OVL_HOPC = 2;
        const int OVL_IHOPC = 3;
        const int CHART_TYPE_COLUMN = 1;
        const int CHART_TYPE_LINE = 2;
        const int INPUT_CHART = 1;
        const int OUTPUT_CHART = 2;

        bool bPilotFlag = false;

        bool bIsOVLType = false;
        bool bIsOVLCANON = false;
        bool bIsLITHOType = false;
        bool bIsETCHType = false;
        bool bIsCMPType = false;
        int iRunCount;
        bool bToolVendorASML;
        bool bChuckOne;
        string strChuckId;
        string strReticleId;
        string strToolVendor;

        bool bIsActive = false;
        string strCurrentOVLModel;
        string strCurrentR2RMode;

        bool bContextGroupNotClick = true;
        bool bContextGroupClicked = false;
        string strContextText = "Context Group:";

        string strDomainName;
        string strUserName;// = "XNi160297";
        string strPassword;
        string strServiceAddress;// = "localhost";
        string strServiceType;// = "localhost";

        string strCurrentModule = "LITHO";
        string strCurrentProduct;
        string strCurrentStage;
        string strCurrentLayer;
        string strCurrentController;
        string strCurrentTool;
        string strArea;
        string strGroup = "";

        List<string> strListCommonGroup = new List<string>();
        List<string> strListR2RContexts = new List<string>();

        List<string> strListChuckDedicationColumnName = new List<string>();
        List<string> strListChuckDedicationValue = new List<string>();

        List<string> strListColNum = new List<string>();
        List<string> strListModule = new List<string>();
        List<string> strListProduct = new List<string>();
        List<string> strListStage = new List<string>();// { "*" };
        List<string> strListLayer = new List<string>();
        List<string> strListController = new List<string>();
        List<string> strListTool = new List<string>();
        #endregion

        #region Set Param
        private void GetOVLChartParam(ref int iOutputCount, ref int iOutputStartIndex, int iOutputSize)
        {
            if (strToolVendor.Equals("ASML"))
            {
                bToolVendorASML = true;
                iOutputCount = iOutputSize / 2;

                iOutputStartIndex = bChuckOne ? 0 : iOutputSize / 2;
            }
            else
            {
                bToolVendorASML = false;
                iOutputCount = iOutputSize;
                iOutputStartIndex = 0;
            }
        }

        private void ClearContextParam()
        {
            strListModule.Clear();
            strListProduct.Clear();
            strListStage.Clear();
            strListLayer.Clear();
            strListController.Clear();
            strListTool.Clear();
        }
        #endregion

        #region Set Control
        private void DgvDoubleBuffer()
        {
            DataGridViewHelp.DoubleBuffered(grdOptContextGroup, true);
            DataGridViewHelp.DoubleBuffered(grdOptLinear, true);
            DataGridViewHelp.DoubleBuffered(grdOptHOPC, true);
            DataGridViewHelp.DoubleBuffered(grdOptIHOPC, true);
            DataGridViewHelp.DoubleBuffered(grdOptCD, true);
            DataGridViewHelp.DoubleBuffered(grdOptFocus, true);
            DataGridViewHelp.DoubleBuffered(dgvContext_History, true);
        }

        private void InitTabSubShow()
        {
            tabOptSubTab.Visible = false;
            HideTabPage();
        }

        private void InitControlVisible()
        {
            btnPreLayerConfig.Visible = true;
            btnChuckDedication.Visible = true;
            btnOptBatchOperation.Visible = true;
            rdoChuck1.Visible = true;
            rdoChuck2.Visible = true;

            panListLot.Visible = false;
            panBtn.Visible = false;
            rdoLotAll.Visible = false;
            rdoListValid.Visible = false;
            rdoMetrology.Visible = false;
            btnOptReset.Visible = false;
            btnOptMode.Visible = false;
            lblCurrentOVLMode.Visible = false;
            lblCurrentR2RMode.Visible = false;
        }

        private void InitControlEnable()
        {
            btnPreLayerConfig.Enabled = false;
            btnChuckDedication.Enabled = false;
            btnOptBatchOperation.Enabled = false;
            rdoChuck1.Enabled = false;
            rdoChuck2.Enabled = false;

            rdoLotAll.Enabled = false;
            rdoListValid.Enabled = false;
            rdoMetrology.Enabled = false;
            btnOptReset.Enabled = false;
            btnOptMode.Enabled = false;
            lblCurrentOVLMode.Enabled = false;
            lblCurrentR2RMode.Enabled = false;
        }
        private void InitControl()
        {
            bChuckOne = true;
            iRunCount = int.Parse(txtLots.Text.ToString());

            InitTabSubShow();
            InitControlVisible();
            InitControlEnable();
        }
        private void ClearContextGrid()
        {
            grdOptContextGroup.DataSource = null;
        }
        private void ClearOVLGrid()
        {
            grdOptLinear.DataSource = null;
            grdOptHOPC.DataSource = null;
            grdOptIHOPC.DataSource = null;
            grdOptCD.DataSource = null;
            grdOptFocus.DataSource = null;
        }

        private void ClearChartPanel()
        {
            panOptChart.AutoScroll = false;
            panOptChart.Controls.Clear();//清空panel
            panOptChart.AutoScroll = true;
        }
        private void ClearControl()
        {
            ClearContextGrid();
            ClearGridAndChart();
        }
        private void ClearGridAndChart()
        {
            ClearOVLGrid();
            ClearChartPanel();
        }

        private void SetTextShow(string strOVLMode, string strRunMode)
        {
            lblCurrentOVLMode.Text = "Current OVL Mode:" + strOVLMode;
            lblCurrentR2RMode.Text = "Current R2R Mode:" + strRunMode;
        }

        private bool IsActive(string strR2RMode)
        {
            bool flag = false;
            if (strR2RMode.Equals("Active"))
            {
                flag = true;
            }
            else
            {
                //btnOptReset.Enabled = false;
            }
            return flag;
        }

        private string GetTextContextGroup(List<string> strList)
        {
            string strResult = "Context Group:";
            if (strList.Count > 0)
            {
                int i = 0;
                foreach (var str in strList)
                {
                    if (i < 4)
                    {
                        strResult += str + " /";
                        i++;
                    }
                }
            }
            return strResult.TrimEnd('/');
        }

        private void SetChuckType(string strChuckId)
        {
            if (strChuckId == "C1")
            {
                //rdoChuck.CheckedIndex = 0;
                rdoChuck1.Checked = true;
            }
            else
            {
                //rdoChuck.CheckedIndex = 1;
                rdoChuck2.Checked = true;
            }
        }

        private void SetControlShow(bool flgCommon, bool flagOVL, bool flgMode, bool flgRest, bool flgActive)
        {
            SetControlVisible(flgCommon, flagOVL);
            SetControlEnable(flgCommon, flagOVL, flgMode, flgRest, flgActive);
        }
        private void SetControlVisible(bool flgCommonType, bool flgOVLType)
        {
            if (flgCommonType)
            {
                panForcePilot.Visible = false;
                panListLot.Visible = true;

                rdoLotAll.Visible = true;
                rdoListValid.Visible = true;
                rdoMetrology.Visible = true;

                lblCurrentOVLMode.Visible = false;
                lblCurrentR2RMode.Visible = true;

                lblCurrentR2RMode.Location = new Point(32, 30);
                panListLot.Location = new Point(32, 70);
                panBtn.Location = new Point(32, 170);
            }
            else
            {
                panForcePilot.Visible = true;

                if (flgOVLType)
                {
                    panListLot.Visible = false;
                    rdoLotAll.Visible = false;
                    rdoListValid.Visible = false;
                    rdoMetrology.Visible = false;

                    lblCurrentOVLMode.Visible = true;
                    lblCurrentR2RMode.Visible = true;

                    lblCurrentOVLMode.Location = new Point(32, 30);
                    lblCurrentR2RMode.Location = new Point(32, 70);
                    panForcePilot.Location = new Point(32, 110);
                    panBtn.Location = new Point(32, 170);
                }
                else
                {
                    panListLot.Visible = true;

                    rdoLotAll.Visible = true;
                    rdoListValid.Visible = true;
                    rdoMetrology.Visible = true;

                    lblCurrentOVLMode.Visible = false;
                    lblCurrentR2RMode.Visible = true;

                    lblCurrentR2RMode.Location = new Point(32, 20);
                    panListLot.Location = new Point(32, 45);
                    panForcePilot.Location = new Point(32, 140);
                    panBtn.Location = new Point(32, 190);
                }
            }
            panBtn.Visible = true;
            btnOptReset.Visible = true;
            btnOptMode.Visible = true;
        }

        private void SetControlEnable(bool flgCommonType, bool flgOVLType, bool flgBtnOptMode, bool flgBtnOptReset, bool flgActive)
        {
            if (flgCommonType)
            {
                btnPreLayerConfig.Enabled = false;
                btnChuckDedication.Enabled = false;
                btnOptBatchOperation.Enabled = false;
                rdoChuck1.Enabled = false;
                rdoChuck2.Enabled = false;
                //rdoList.Enabled = true;
                rdoLotAll.Enabled = true;
                rdoListValid.Enabled = true;
                rdoMetrology.Enabled = true;
            }
            else
            {
                if (flgOVLType)
                {
                    btnPreLayerConfig.Enabled = true;
                    btnChuckDedication.Enabled = bIsOVLCANON ? false : true;
                    btnOptBatchOperation.Enabled = true;
                    rdoChuck1.Enabled = true;
                    rdoChuck2.Enabled = bIsOVLCANON ? false : true;
                    rdoLotAll.Enabled = false;
                    rdoListValid.Enabled = false;
                    rdoMetrology.Enabled = false;
                }
                else
                {
                    btnPreLayerConfig.Enabled = false;
                    btnChuckDedication.Enabled = false;
                    btnOptBatchOperation.Enabled = false;
                    rdoChuck1.Enabled = false;
                    rdoChuck2.Enabled = false;
                    rdoLotAll.Enabled = true;
                    rdoListValid.Enabled = true;
                    rdoMetrology.Enabled = true;
                }
            }

            btnOptReset.Enabled = flgActive ? flgBtnOptReset : false;
            btnOptMode.Enabled = flgBtnOptMode;
        }
        private void panOptBtnShow(bool flagType)
        {
            if (flagType)
            {
                panOptBtn.Width = 267;
                panOptBtn.Height = 240;
                //grpOptBtn.Visible = true;
            }
            else
            {
                panOptBtn.Width = 0;
                panOptBtn.Height = 240;
                //grpOptBtn.Visible = false;
            }
        }

        private void panOptSubBtnShow(bool flagShow)
        {
            if (flagShow)
            {
                panOptSubBtn.Width = 267;
                panOptSubBtn.Height = 245;
                //grpOptSubBtn.Visible = true;
            }
            else
            {
                panOptSubBtn.Width = 0;
                panOptSubBtn.Height = 245;
                //grpOptSubBtn.Visible = false;
            }
        }
        private bool IsLITHOType(string strModel)
        {
            bool bFlag = true;
            if (strModel.ToUpper().Equals("LITHO"))
            {
                bFlag = true;
            }
            else
            {
                bFlag = false;
            }
            return bFlag;
        }
        private bool IsETCHType(string strModel)
        {
            bool bFlag = true;
            if (strModel.ToUpper().Equals("ETCH"))
            {
                bFlag = true;
            }
            else
            {
                bFlag = false;
            }
            return bFlag;
        }

        private bool IsCMPType(string strModel)
        {
            bool bFlag = false;
            if (strModel.ToUpper().Equals("LITHO"))
            {
                bFlag = false;
            }
            else
            {
                bFlag = true;
            }
            return bFlag;
        }

        private string GetLayerOrStep(string strModel)
        {
            string str = "Layer";
            if (strModel.ToUpper().Equals("LITHO"))
            {
                str = "Layer";
            }
            else
            {
                str = "Step";
            }
            return str;
        }
        private bool IsOVLType(string strControl)
        {
            bool bFlag = true;
            if (strControl.ToUpper().Contains("PH_OVL"))
            {
                bFlag = true;
            }
            else
            {
                rdoChuck1.Enabled = false;
                rdoChuck2.Enabled = false;
                bFlag = false;
            }
            return bFlag;
        }
        private bool IsOVLCANON(string strControl)
        {
            bool bFlag = false;
            if (strControl.ToUpper().Contains("PH_OVL_CANON"))
            {
                bFlag = true;
                btnChuckDedication.Enabled = false;
                rdoChuck2.Enabled = false;
            }
            else
            {
                bFlag = false;
            }
            return bFlag;
        }
        private void HideTabPage()
        {
            foreach (TabPage tab in tabOptSubTab.TabPages)
            {
                tab.Parent = null;
            }

            #region
            //隐藏：
            //tabPageLinear.Parent = null;
            //tabPageHOPC.Parent = null;
            //tabPageIHOPC.Parent = null;
            //tabPageCD.Parent = null;
            //tabPageFocus.Parent = null;
            #endregion
        }

        private void ShowTabPage(bool flagCommon, bool flagOVL)
        {
            tabOptSubTab.Visible = true;
            if (flagCommon)
            {

            }
            else
            {
                if (flagOVL)
                {
                    tabPageLinear.Parent = tabOptSubTab;
                    tabPageHOPC.Parent = tabOptSubTab;
                    tabPageIHOPC.Parent = tabOptSubTab;
                }
                else
                {
                    tabPageCD.Parent = tabOptSubTab;
                    tabPageFocus.Parent = tabOptSubTab;
                }
            }
        }

        public DataTable dbChuckDeditation = new DataTable();
        private void InitDbChuckDeditation(DataTable db, int rowIndex)
        {
            if (rowIndex >= 0)
            {
                strListChuckDedicationValue.Clear();
                strListChuckDedicationColumnName.Clear();
                for (int i = 0; i < db.Columns.Count; i++)
                {

                    strListChuckDedicationValue.Add(grdOptContextGroup.Rows[rowIndex].Cells[i].Value.ToString());

                }
                foreach (DataColumn dc in dbGetContext.Columns)
                {
                    strListChuckDedicationColumnName.Add(dc.ColumnName.ToString());
                }
                dbChuckDeditation = DataTableHelp.CreateChuckDedicationTable(strListChuckDedicationColumnName, strListChuckDedicationValue);
            }
        }
        #endregion

        private void frmMain_Load(object sender, EventArgs e)
        {
            #region  Double Buffer
            DgvDoubleBuffer();
            CtlDoubleBuffer();
            #endregion

            #region Version Control
            statusStrip1.Items[0].Text = STR_VERSION + "        DomainName: " + strDomainName + "       ServiceAddress: " + strServiceType;
            statusStrip1.Items[1].Text = DateTime.Now.ToString("HH:mm:ss");
            statusStrip1.Items[2].Text = DateTime.Now.Year.ToString() + "/" + DateTime.Now.ToString("MM/dd");
            #endregion

            #region Init Control
            InitControl();
            cmbModule.DataSource = strListModule;
            AddControlHelp.SetLable(panContextGroupLbl, lblContextGroup, "List of Context Group");
            #endregion

            #region Init History
            //tabPage2.Parent = null;
            tabPage2.Show();//by zqk add important
            #endregion
        }

        #region Chart Event
        int iCMPOutputChartIndex = 0;
        string strCMPGroupName = "";
        private void ChartClick(List<Chart> ctChart)
        {
            if (ctChart.Count > 0)
            {
                for (int i = 0; i < ctChart.Count; i++)
                {
                    iCMPOutputChartIndex = i + 1;

                    ctChart[i].MouseClick -= chart_MouseClick;
                    ctChart[i].MouseClick += chart_MouseClick;
                }
            }
        }

        private void chart_MouseClick(object sender, MouseEventArgs e)
        {
            var chart = sender as Chart;

            if (e.Button == MouseButtons.Left)
            {
                var pos = e.Location;

                var results = chart.HitTest(pos.X, pos.Y, false, ChartElementType.DataPoint);
                foreach (var result in results)
                {
                    if (result.ChartElementType == ChartElementType.DataPoint)
                    {
                        DataPoint selected = result.Object as DataPoint;
                        var xVal = selected.AxisLabel;

                        UIServiceFun.structCOMMON_GetRawMetrology structRawMetrologyNull = new UIServiceFun.structCOMMON_GetRawMetrology();
                        UIServiceFun.structCOMMON_GetRawMetrology structRawMetrology = new UIServiceFun.structCOMMON_GetRawMetrology();
                        structRawMetrology = UIServiceFun.R2R_UI_COMMON_GetRawMetrology(ref strServiceAddress, strCurrentController, strListR2RContexts, iCMPOutputChartIndex, xVal, strCMPGroupName);

                        if (structRawMetrology.Equals(structRawMetrologyNull))
                        {
                            //MessageBox.Show("Data is empty!");
                        }
                        else
                        {
                            frmRawMetrology frm = new frmRawMetrology(structRawMetrology, xVal, strServiceType);
                            frm.ShowDialog();
                        }
                    }
                }
            }
        }

        #region test
        private string GetToolTipInformationString(UIServiceFun.structCOMMON_GetRawMetrology structData)
        {
            StringBuilder strInformation = new StringBuilder();
            strInformation.Append("Target:     " + structData.dTarget + Environment.NewLine);
            strInformation.Append("LowerLimit: " + +structData.dLowerLimit + Environment.NewLine);
            strInformation.Append("UpperLimit: " + +structData.dUpperLimit + Environment.NewLine + Environment.NewLine);
            strInformation.Append("WaferIds" + Environment.NewLine + GetString(structData.strListWaferIds) + Environment.NewLine + Environment.NewLine);
            strInformation.Append("MeasDataItemNames:" + Environment.NewLine + GetString(structData.strListMeasDataItemNames) + Environment.NewLine + Environment.NewLine);
            strInformation.Append("MeasSiteCSV" + Environment.NewLine + GetString(structData.strListMeasSiteCSV) + Environment.NewLine + Environment.NewLine);
            strInformation.Append("MeasValidityCSV" + Environment.NewLine + GetString(structData.strListMeasValueCSV) + Environment.NewLine + Environment.NewLine);
            strInformation.Append("MeasValueCSV" + Environment.NewLine + GetString(structData.strListMeasValueCSV) + Environment.NewLine + Environment.NewLine);

            return strInformation.ToString();
        }

        private string GetString(List<string> strList)
        {
            string strResult = "";
            foreach (var str in strList)
            {
                strResult += str + "; ";
            }
            return strResult;
        }
        #endregion

        #endregion

        #region txtLots Event 
        int iListOfRuns;
        private string strRunCount = "20";
        private void txtLots_TextChanged(object sender, EventArgs e)
        {
            bool bIsNumber = false;
            bIsNumber = RegexHelp.IsNumber(txtLots.Text.ToString());
            if (bIsNumber)
            {
                strRunCount = txtLots.Text;   // 将现在textBox的值保存下来
            }
            else
            {
                txtLots.Text = strRunCount;   // textBox内容不变

                txtLots.SelectionStart = txtLots.Text.Length; // 将光标定位到文本框的最后
                //MessageBox.Show("Please input a number!");
            }
        }

        private void txtLots_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)//如果输入的是回车键
            {
                this.btnOptRun_Click(sender, e);//触发button事件
            }
        }
        #endregion

        #region rdo Event
        private void rdoChuck_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rdo = (RadioButton)sender;
            if (rdo.Name.Equals("rdoChuck1"))
            {
                if (rdoChuck1.Checked)
                {
                    bChuckOne = true;
                    strChuckId = "C1";
                    //MessageBox.Show("chuck1");

                    if (bContextGroupClicked)
                    {
                        ContextGroupDoubleClick_OVL();
                    }
                }
            }
            else if (rdo.Name.Equals("rdoChuck2"))
            {
                if (rdoChuck2.Checked)
                {
                    bChuckOne = false;
                    strChuckId = "C2";
                    //MessageBox.Show("chuck2");

                    if (bContextGroupClicked)
                    {
                        ContextGroupDoubleClick_OVL();
                    }
                }
            }

        }
        private void rdoChuck1_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoChuck1.Checked)
            {
                bChuckOne = true;
                strChuckId = "C1";
                //MessageBox.Show("chuck1");

                if (bContextGroupClicked)
                {
                    ContextGroupDoubleClick_OVL();
                }
            }
        }

        private void rdoChuck2_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoChuck2.Checked)
            {
                bChuckOne = false;
                strChuckId = "C2";
                //MessageBox.Show("chuck2");

                if (bContextGroupClicked)
                {
                    ContextGroupDoubleClick_OVL();
                }
            }
        }

        int rdoLotType = 1;
        private void rdoLotAll_CheckedChanged(object sender, EventArgs e)
        {
            #region
            if (rdoLotAll.Checked)
            {
                rdoLotType = 1;
                if (bIsCMPType)
                {
                    GetLotRunHistory_Common();
                }
                else
                {
                    ClearGridAndChart();

                    string strTabName = tabOptSubTab.SelectedTab.Name;

                    if (strTabName.Equals("tabPageCD"))
                    {
                        GetLotRunHistory_CD();
                    }
                    else if (strTabName.Equals("tabPageFocus"))
                    {
                        GetLotRunHistory_Focus();
                    }
                }
            }
            #endregion
        }
        private void rdoListValid_CheckedChanged(object sender, EventArgs e)
        {
            #region
            if (rdoListValid.Checked)
            {
                rdoLotType = 2;
                if (bIsCMPType)
                {
                    GetLotRunHistory_Common();
                }
                else
                {
                    ClearGridAndChart();

                    string strTabName = tabOptSubTab.SelectedTab.Name;

                    if (strTabName.Equals("tabPageCD"))
                    {
                        GetLotRunHistory_CD();
                    }
                    else if (strTabName.Equals("tabPageFocus"))
                    {
                        GetLotRunHistory_Focus();
                    }
                }
            }
            #endregion
        }
        private void rdoMetrology_CheckedChanged(object sender, EventArgs e)
        {
            #region
            if (rdoMetrology.Checked)
            {
                rdoLotType = 3;
                if (bIsCMPType)
                {
                    GetLotRunHistory_Common();
                }
                else
                {
                    ClearGridAndChart();

                    string strTabName = tabOptSubTab.SelectedTab.Name;

                    if (strTabName.Equals("tabPageCD"))
                    {
                        GetLotRunHistory_CD();
                    }
                    else if (strTabName.Equals("tabPageFocus"))
                    {
                        GetLotRunHistory_Focus();
                    }
                }
            }
            #endregion
        }
        #endregion

        #region Btn Event
        DataTable dbGetContext = new DataTable("GetContext");
        private void btnOptRun_Click(object sender, EventArgs e)
        {
            bContextGroupNotClick = true;
            bContextGroupClicked = false;
            rdoChuck1.Checked = true;
            ClearControl();
            InitTabSubShow();

            panOptSubBtnShow(false);
            if (bIsOVLType)
            {
                btnPreLayerConfig.Enabled = true;
                btnOptBatchOperation.Enabled = true;
                btnChuckDedication.Enabled = bIsOVLCANON ? false : true;

                rdoChuck1.Enabled = true;
                rdoChuck2.Enabled = bIsOVLCANON ? false : true;//by zqk modify 20180731
            }
            try
            {
                #region GetR2RContext
                iRunCount = int.Parse(txtLots.Text.ToString());
                if (cmbModule.Text.ToString().Equals("") || cmbProduct.Text.ToString().Equals("") || cmbStage.Text.ToString().Equals("") || cmbLayer.Text.ToString().Equals("") || cmbControl.Text.ToString().Equals("") || cmbTool.Text.ToString().Equals("") || iRunCount == 0)
                {
                    MessageBox.Show("The parameter cannot be empty");
                }
                else
                {
                    UIServiceFun.structGetR2RContext structR2RContextNull = new UIServiceFun.structGetR2RContext();
                    UIServiceFun.structGetR2RContext structR2RContext = new UIServiceFun.structGetR2RContext();
                    structR2RContext = UIServiceFun.R2R_UI_GetR2RContext(ref strServiceAddress, strCurrentProduct, strCurrentLayer, strCurrentController, strCurrentTool, iRunCount);

                    if (structR2RContext.Equals(structR2RContextNull))
                    {
                        //MessageBox.Show("Data is empty!");
                    }
                    else
                    {
                        #region Get DataContext by zqk modify 20180809
                        dbGetContext = DataTableHelp.CreateContextGroupTable(structR2RContext.structContext);

                        DataTable dbContextGroup = new DataTable("ContextGroup");
                        List<string> strListColumn = new List<string>(structR2RContext.structContext.strListContexts);
                        dbContextGroup = DataTableHelp.GetDistinctTable(dbGetContext, strListColumn);

                        DataGridViewHelp.InitDgvGrid(grdOptContextGroup, dbContextGroup);

                        InitDbChuckDeditation(dbGetContext, 0);
                        #endregion
                    }
                }
                #endregion
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private void btnPreLayer_Click(object sender, EventArgs e)
        {
            frmPreLayerConfig frm = new frmPreLayerConfig(strServiceAddress, strUserName, strPassword, strCurrentController, strServiceType);
            frm.ShowDialog();
        }

        private void btnChuckDedication_Click(object sender, EventArgs e)
        {
            frmChuckDedication frm = new frmChuckDedication(strServiceAddress, strUserName, strPassword, dbChuckDeditation, strServiceType);
            frm.ShowDialog();
        }

        private void btnBatchOperation_Click(object sender, EventArgs e)
        {
            //strArea = "LITHO";
            //strPassword = "Amat2018.";
            strArea = strCurrentModule;

            frmBatchOperation frm = new frmBatchOperation(strServiceAddress, strUserName, strPassword, strArea, strCurrentProduct, strCurrentLayer, strCurrentController, strCurrentTool, strServiceType);
            frm.ShowDialog();
        }

        private void btnPilotUpdate_Click(object sender, EventArgs e)
        {
            frmCheckedPwd frmChecked = new frmCheckedPwd(strUserName);
            if (frmChecked.ShowDialog() == DialogResult.OK)
            {
                if (frmChecked.strPassword.Equals(strPassword))
                {
                    #region UpdatePilotFlag
                    bool bSuccess = false;
                    try
                    {

                        if (bIsLITHOType && bIsOVLType)
                        {
                            bSuccess = UIServiceFun.R2R_UI_PH_OVL_UpdatePilotFlag(ref strServiceAddress, strUserName, strCurrentController, strListR2RContexts, chkForcePilot.Checked);
                        }
                        else if (bIsLITHOType)
                        {
                            bSuccess = UIServiceFun.R2R_UI_PH_CD_UpdatePilotFlag(ref strServiceAddress, strUserName, strCurrentController, strListR2RContexts, chkForcePilot.Checked);
                        }

                        if (bSuccess)
                        {
                            //this.Close();
                        }
                        else
                        {

                        }
                        //this.DialogResult = DialogResult.OK;
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show(BaseFun.GetExceptionInformation(err));
                    }
                    #endregion
                }
                else
                {
                    MessageBox.Show("Invalid password!");
                }
            }
            else
            {
                //MessageBox.Show("Invalid password!");
            }
        }

        private void btnOptCDModeClick()
        {
            #region PH_CD_GetDoseSettings
            UIServiceFun.structPH_CD_GetDoseSettings structSettingsNull = new UIServiceFun.structPH_CD_GetDoseSettings();
            UIServiceFun.structPH_CD_GetDoseSettings structSettings = new UIServiceFun.structPH_CD_GetDoseSettings();
            structSettings = UIServiceFun.R2R_UI_PH_CD_GetDoseSettings(ref strServiceAddress, strListR2RContexts);

            if (structSettings.Equals(structSettingsNull))
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
                frmCDMode frm = new frmCDMode(strServiceAddress, strUserName, strPassword, strListR2RContexts, structSettings, strServiceType);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    //MessageBox.Show(frm.strListCurrent[0]);
                }
                else
                {

                }
            }
            #endregion
        }

        private void btnOptCommonModeClick()
        {
            #region R2R_UI_COMMON_GetInputSettings
            UIServiceFun.structCOMMON_GetInputSettings structCommonInputSettingNull = new UIServiceFun.structCOMMON_GetInputSettings();
            UIServiceFun.structCOMMON_GetInputSettings structCommonInputSetting = new UIServiceFun.structCOMMON_GetInputSettings();
            structCommonInputSetting = UIServiceFun.R2R_UI_COMMON_GetInputSettings(ref strServiceAddress, strCurrentController, strGroup, strListR2RContexts);

            if (structCommonInputSetting.Equals(structCommonInputSettingNull))
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
                frmCommonMode frm = new frmCommonMode(strServiceAddress, strUserName, strPassword, strCurrentController, strGroup, strListR2RContexts, structCommonInputSetting, strServiceType);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    //MessageBox.Show(frm.strListCurrent[0]);
                }
                else
                {

                }
            }
            #endregion
        }
        private void btnOptMode_Click(object sender, EventArgs e)
        {
            #region
            string strTabName = tabOptSubTab.SelectedTab.Name;
            switch (strTabName)
            {
                case "tabPageLinear":
                    break;
                case "tabPageHOPC":
                    break;
                case "tabPageIHOPC":
                    break;
                case "tabPageCD":
                    btnOptCDModeClick();
                    break;
                case "tabPageFocus":
                    break;
                default:
                    btnOptCommonModeClick();
                    break;
            }
            #endregion
        }
        private void btnOptOVLResetClick()
        {
            #region PH_OVL_GetResetValues
            UIServiceFun.structPH_OVL_GetResetValues structResetValuesNull = new UIServiceFun.structPH_OVL_GetResetValues();
            UIServiceFun.structPH_OVL_GetResetValues structResetValues = new UIServiceFun.structPH_OVL_GetResetValues();
            structResetValues = UIServiceFun.R2R_UI_PH_OVL_GetResetValues(ref strServiceAddress, strCurrentController, strListR2RContexts, strCurrentOVLModel, strCurrentR2RMode);

            if (structResetValues.Equals(structResetValuesNull))
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
                //frmLinearReset frm = new frmLinearReset(strServiceAddres, strCurrentController, strListR2RContexts, strCurrentOVLModel, strCurrentR2RMode, structResetValues);
                frmOVLReset frm = new frmOVLReset(strServiceAddress, strUserName, strPassword, strCurrentController, strListR2RContexts, strCurrentOVLModel, strCurrentR2RMode, structResetValues, strServiceType);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    //MessageBox.Show(frm.strListCurrent[0]);
                }
                else
                {

                }
            }
            #endregion
        }
        private void btnOptCDResetClick()
        {
            #region PH_CD_GetDoseResetSettings
            UIServiceFun.structPH_CD_GetDoseResetSettings structResetSettingsNull = new UIServiceFun.structPH_CD_GetDoseResetSettings();
            UIServiceFun.structPH_CD_GetDoseResetSettings structResetSettings = new UIServiceFun.structPH_CD_GetDoseResetSettings();
            structResetSettings = UIServiceFun.R2R_UI_PH_CD_GetDoseResetSettings(ref strServiceAddress, strListR2RContexts);

            if (structResetSettings.Equals(structResetSettingsNull))
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
                frmCDReset frm = new frmCDReset(strServiceAddress, strUserName, strPassword, strListR2RContexts, structResetSettings, strServiceType);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    //MessageBox.Show(frm.strListCurrent[0]);
                }
                else
                {

                }
            }
            #endregion
        }

        private void btnOptFocusResetClick()
        {
            #region R2R_UI_PH_Focus_GetFocusSettings
            double dValue = 0.0;
            dValue = UIServiceFun.R2R_UI_PH_Focus_GetFocusSettings(ref strServiceAddress, strListR2RContexts);

            frmFocusUpdate frm = new frmFocusUpdate(strServiceAddress, strUserName, strPassword, strListR2RContexts, dValue, strServiceType);
            if (frm.ShowDialog() == DialogResult.OK)
            {
                //MessageBox.Show(frm.strListCurrent[0]);
            }
            else
            {

            }
            #endregion
        }
        private void btnOptCommonResetClick()
        {
            #region R2R_UI_COMMON_GetInputResetSettings
            UIServiceFun.structCOMMON_GetInputResetSettings structCommonInputResetSettingNull = new UIServiceFun.structCOMMON_GetInputResetSettings();
            UIServiceFun.structCOMMON_GetInputResetSettings structCommonInputResetSetting = new UIServiceFun.structCOMMON_GetInputResetSettings();
            structCommonInputResetSetting = UIServiceFun.R2R_UI_COMMON_GetInputResetSettings(ref strServiceAddress, strCurrentController, strGroup, strListR2RContexts);

            if (structCommonInputResetSetting.Equals(structCommonInputResetSettingNull))
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
                frmCommonReset frm = new frmCommonReset(strServiceAddress, strUserName, strPassword, strCurrentController, strGroup, strListR2RContexts, structCommonInputResetSetting, strServiceType);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    //MessageBox.Show(frm.strListCurrent[0]);
                }
                else
                {

                }
            }
            #endregion
        }
        private void btnOptReset_Click(object sender, EventArgs e)
        {
            #region
            string strTabName = tabOptSubTab.SelectedTab.Name;
            switch (strTabName)
            {
                case "tabPageLinear":
                    btnOptOVLResetClick();
                    break;
                case "tabPageHOPC":
                    btnOptOVLResetClick();
                    break;
                case "tabPageIHOPC":
                    btnOptOVLResetClick();
                    break;
                case "tabPageCD":
                    btnOptCDResetClick();
                    break;
                case "tabPageFocus":
                    btnOptFocusResetClick();
                    break;
                default:
                    btnOptCommonResetClick();
                    break;
            }
            #endregion
        }
        #endregion

        #region OptContextGroup Event
        private void grdOptContextGroup_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView dgv = (DataGridView)sender;
            try
            {
                if (e.RowIndex >= 0)
                {
                    bContextGroupClicked = true;
                    ClearGridAndChart();
                    panOptSubBtnShow(true);

                    if (bContextGroupNotClick)
                    {
                        if (tabOptSubTab.TabCount > 0)
                        {
                            HideTabPage();
                        }
                        ShowTabPage(bIsCMPType, bIsOVLType);
                        SetControlShow(bIsCMPType, bIsOVLType, false, true, bIsActive);
                    }

                    strListR2RContexts.Clear();
                    for (int i = 0; i < dbGetContext.Columns.Count; i++)
                    {
                        strListR2RContexts.Add(dgv.Rows[e.RowIndex].Cells[i].Value.ToString());
                    }
                    strContextText = GetTextContextGroup(strListR2RContexts);

                    if (bIsCMPType)
                    {
                        RemoveTabPage();
                        rdoLotAll.Checked = true;
                        tabOptSubTab.Visible = true;
                        GetLotRunHistory_Common();
                    }
                    else
                    {
                        strReticleId = dgv.Rows[e.RowIndex].Cells["RETICLE"].Value.ToString();
                        ContextGroupDoubleClick_OVL();
                    }
                    bContextGroupNotClick = false;

                    DataGridViewHelp.SetDgvRowColor(dgv, e.RowIndex);
                    //dgv.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Aqua;

                    chkForcePilot.Checked = bPilotFlag;
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private void grdOptContextGroup_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    InitDbChuckDeditation(dbGetContext, e.RowIndex);
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private void ContextGroupDoubleClick_OVL()
        {
            ClearOVLGrid();
            ClearChartPanel();
            strContextText = GetTextContextGroup(strListR2RContexts);
            try
            {
                if (strCurrentController.Contains("PH_OVL"))
                {
                    GetLotRunHistory_OVL();
                }
                else
                {
                    tabOptSubTab.SelectedTab = tabPageCD;
                    GetLotRunHistory_CD();
                    //GetLotRunHistory_Focus();
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }
        #endregion

        #region grdOptContextGroup Fun
        private void AddChartToPanel(List<Chart> ctlListChartInput, List<Chart> ctlListChartOutput, string strMsgType)
        {
            try
            {
                ClearChartPanel();
                if (ctlListChartInput.Count > 0 && ctlListChartOutput.Count > 0)
                {
                    if (ctlListChartInput.Count < 3)
                    {
                        List<Chart> ctlListInputAndOutputChart = new List<Chart>();
                        for (int i = 0; i < ctlListChartInput.Count; i++)
                        {
                            ctlListInputAndOutputChart.Add(ctlListChartInput[i]);
                            ctlListInputAndOutputChart.Add(ctlListChartOutput[i]);
                        }
                        AddControlHelp.AddChartToPanel(panOptChart, ctlListInputAndOutputChart);
                    }
                    else
                    {
                        AddControlHelp.AddChartToPanel(panOptChart, ctlListChartInput, ctlListChartOutput);
                    }
                }
                else
                {
                    if (ctlListChartInput.Count > 0)
                    {
                        AddControlHelp.AddChartToPanel(panOptChart, ctlListChartInput);
                        //MessageBox.Show(strMsgType + " No available Output chart");
                    }
                    else if (ctlListChartOutput.Count > 0)
                    {
                        AddControlHelp.AddChartToPanel(panOptChart, ctlListChartOutput);
                        //MessageBox.Show(strMsgType + " No available Input chart");
                    }
                    else
                    {
                        //MessageBox.Show(strMsgType + " No available Input/Output chart");
                    }
                }

                strCMPGroupName = tabOptSubTab.SelectedTab.Text;
                if (!bIsOVLType)
                {
                    ChartClick(ctlListChartOutput);
                }

            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private void GetLotRunHistory_OVL()
        {
            #region
            ClearGridAndChart();
            AddControlHelp.SetLable(panLinearLbl, lblLinear, strContextText);
            AddControlHelp.SetLable(panHOPCLbl, lblHOPC, strContextText);
            AddControlHelp.SetLable(panIHOPCLbl, lblIHOPC, strContextText);

            iListOfRuns = int.Parse(txtLots.Text.ToString());
            LotRunHistory_OVL myClass = new LotRunHistory_OVL(strServiceAddress, strCurrentController, strListR2RContexts, iListOfRuns);
            if (myClass.bNotData)
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
                try
                {
                    bPilotFlag = myClass.bPilotFlag;

                    strCurrentOVLModel = myClass.strCurrentOVLModel;
                    strCurrentR2RMode = myClass.strCurrentR2RMode;
                    bIsActive = myClass.bIsActive;

                    SetTextShow(strCurrentOVLModel, strCurrentR2RMode);
                    SetControlShow(bIsCMPType, bIsOVLType, false, true, bIsActive);

                    string strTabName = tabOptSubTab.SelectedTab.Name;
                    LotRunHistory_OVL.structGroup structGroup = new LotRunHistory_OVL.structGroup();

                    structGroup = myClass.GetGroup(strTabName, CHART_TYPE_LINE, 1, bChuckOne);
                    if (structGroup.ovlType == 1)
                    {
                        AddControlHelp.SetLable(panLinearLbl, lblLinear, strContextText);

                        if (structGroup.bMode)
                        {
                            DataGridViewHelp.InitDgvGrid(grdOptLinear, structGroup.db);
                            AddChartToPanel(structGroup.ctlListInputChart, structGroup.ctlListOutputChart, structGroup.strType);
                        }
                    }
                    else if (structGroup.ovlType == 2)
                    {
                        AddControlHelp.SetLable(panHOPCLbl, lblHOPC, strContextText);

                        if (structGroup.bMode)
                        {
                            DataGridViewHelp.InitDgvGrid(grdOptHOPC, structGroup.db);
                            AddChartToPanel(structGroup.ctlListInputChart, structGroup.ctlListOutputChart, structGroup.strType);
                        }
                    }
                    else if (structGroup.ovlType == 3)
                    {
                        AddControlHelp.SetLable(panIHOPCLbl, lblIHOPC, strContextText);

                        if (structGroup.bMode)
                        {
                            DataGridViewHelp.InitDgvGrid(grdOptIHOPC, structGroup.db);
                            AddChartToPanel(structGroup.ctlListInputChart, structGroup.ctlListOutputChart, structGroup.strType);
                        }
                    }
                }
                catch (Exception err)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
            #endregion
        }

        private void GetLotRunHistory_CD()
        {
            ClearChartPanel();
            AddControlHelp.SetLable(panCDLbl, lblCD, strContextText);

            iListOfRuns = int.Parse(txtLots.Text.ToString());
            LotRunHistory_CD myClass = new LotRunHistory_CD(strServiceAddress, strListR2RContexts, iListOfRuns, rdoLotType);
            if (myClass.bNotData)
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
                try
                {
                    bool bIsActive = myClass.bIsActive;
                    bPilotFlag = myClass.bPilotFlag;
                    strCurrentR2RMode = myClass.strCurrentR2RMode;

                    SetControlShow(bIsCMPType, bIsOVLType, true, true, bIsActive);
                    if (bIsActive)
                    {
                        lblCurrentR2RMode.Text = "Current R2R Mode:Active";
                    }
                    else
                    {
                        lblCurrentR2RMode.Text = "Current R2R Mode:Fixed";
                    }
                    AddControlHelp.SetLable(panCDLbl, lblCD, strContextText);


                    DataTable db = myClass.GetTable();
                    DataGridViewHelp.InitDgvGrid(grdOptCD, db);

                    List<Chart> ctlListChartInput = myClass.GetChart(INPUT_CHART, CHART_TYPE_LINE);
                    List<Chart> ctlListChartOutput = myClass.GetChart(OUTPUT_CHART, CHART_TYPE_LINE);

                    AddChartToPanel(ctlListChartInput, ctlListChartOutput, "PH_OVL_CD");
                }
                catch (Exception err)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
        }

        private void GetLotRunHistory_Focus()
        {
            ClearChartPanel();
            AddControlHelp.SetLable(panFocusLbl, lblFocus, strContextText);

            iListOfRuns = int.Parse(txtLots.Text.ToString());
            LotRunHistory_Focus myClass = new LotRunHistory_Focus(strServiceAddress, strListR2RContexts, iListOfRuns, rdoLotType);
            if (myClass.bNotData)
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
                try
                {
                    bool bIsFixed = myClass.bIsFixed;
                    strCurrentR2RMode = myClass.strCurrentR2RMode;

                    bIsFixed = true;
                    SetControlShow(bIsCMPType, bIsOVLType, false, true, bIsFixed);
                    if (bIsFixed)
                    {
                        lblCurrentR2RMode.Text = "Current R2R Mode:Fixed";
                    }
                    else
                    {
                        lblCurrentR2RMode.Text = "Current R2R Mode:Active";
                    }
                    AddControlHelp.SetLable(panFocusLbl, lblFocus, strContextText);

                    DataTable db = myClass.GetTable();
                    DataGridViewHelp.InitDgvGrid(grdOptFocus, db);

                    List<Chart> ctlListChartInput = myClass.GetChart(INPUT_CHART, CHART_TYPE_LINE);
                    List<Chart> ctlListChartOutput = myClass.GetChart(OUTPUT_CHART, CHART_TYPE_LINE);

                    AddChartToPanel(ctlListChartInput, ctlListChartOutput, "PH_OVL_Focus");
                }
                catch (Exception err)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
        }

        private void GetLotRunHistory_Common()
        {
            ClearChartPanel();
            //RemoveTabPage();

            iListOfRuns = int.Parse(txtLots.Text.ToString());
            LotRunHistory_Common myClass = new LotRunHistory_Common(strServiceAddress, strCurrentController, strListR2RContexts, iListOfRuns, rdoLotType);
            if (myClass.bNotData)
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
                try
                {
                    strCurrentR2RMode = "Active";
                    lblCurrentR2RMode.Text = "Current R2R Mode:" + strCurrentR2RMode;

                    bIsActive = true;
                    SetControlShow(bIsCMPType, bIsOVLType, true, true, bIsActive);

                    btnOptReset.Enabled = true;
                    btnOptMode.Enabled = true;

                    strContextText = GetTextContextGroup(strListR2RContexts);

                    int index = myClass.iGroupListValueIndexs.Count;
                    if (tabOptSubTab.TabCount == 0)
                    {
                        AddControlHelp.AddTabPageToTabControl(tabOptSubTab, index, myClass.strListGroupNames);
                    }

                    if (index > 0)
                    {
                        TabPage tabPage = tabOptSubTab.SelectedTab;
                        tabPage.Controls.Clear();

                        string strTabName = tabOptSubTab.SelectedTab.Name;

                        strCurrentR2RMode = myClass.GetR2RMode(strTabName);
                        lblCurrentR2RMode.Text = "Current R2R Mode:" + strCurrentR2RMode;

                        LotRunHistory_Common.structGroup structGroup = new LotRunHistory_Common.structGroup();
                        structGroup = myClass.GetGroup(strTabName);

                        strGroup = strTabName;
                        AddControlHelp.AddPanelToTabPage(tabPage, strContextText, structGroup.db);

                        AddChartToPanel(structGroup.ctlListInputChart, structGroup.ctlListOutputChart, "PH_Common");

                    }
                    else
                    {
                    }
                }
                catch (Exception err)
                {
                    MessageBox.Show(BaseFun.GetExceptionInformation(err));
                }
            }
        }

        private void RemoveTabPage()
        {
            if (tabOptSubTab.TabCount > 0)
            {
                int tabCount = tabOptSubTab.TabCount;
                for (int i = tabCount - 1; i >= 0; i--)
                {
                    if (tabOptSubTab.TabPages[i].Name.Equals("tabPageLinear") || tabOptSubTab.TabPages[i].Name.Equals("tabPageHOPC") || tabOptSubTab.TabPages[i].Name.Equals("tabPageIHOPC") || tabOptSubTab.TabPages[i].Name.Equals("tabPageCD") || tabOptSubTab.TabPages[i].Name.Equals("tabPageFocus"))
                    {
                        tabOptSubTab.TabPages[i].Parent = null;
                    }
                    else
                    {
                        tabOptSubTab.TabPages.RemoveAt(i);
                    }

                }
            }
        }

        #endregion

        #region TabSub Event
        private void tabOptSubTab_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (bContextGroupClicked)
            {
                if (tabOptSubTab.TabCount > 0)
                {
                    SetTextShow(strCurrentOVLModel, strCurrentR2RMode);
                    string strTabName = tabOptSubTab.SelectedTab.Name;
                    string strTabTxt = tabOptSubTab.SelectedTab.Text;
                    strCMPGroupName = strTabTxt;

                    if (bIsCMPType)
                    {
                        GetLotRunHistory_Common();
                    }
                    else if (bIsLITHOType)
                    {
                        if (bIsOVLType)
                        {
                            GetLotRunHistory_OVL();
                        }
                        else
                        {
                            switch (strTabName)
                            {
                                case "tabPageCD":
                                    GetLotRunHistory_CD();
                                    break;
                                case "tabPageFocus":
                                    GetLotRunHistory_Focus();
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }
            }
        }
        #endregion

        #region cmbContext Event
        private void ClearCmbContext(int index)
        {
            switch (index)
            {
                case 1:
                    cmbProduct.DataSource = null;
                    cmbStage.DataSource = null;
                    cmbLayer.DataSource = null;
                    cmbControl.DataSource = null;
                    cmbTool.DataSource = null;
                    break;
                case 2:
                    cmbStage.DataSource = null;
                    cmbLayer.DataSource = null;
                    cmbControl.DataSource = null;
                    cmbTool.DataSource = null;
                    break;
                case 3:
                    cmbLayer.DataSource = null;
                    cmbControl.DataSource = null;
                    cmbTool.DataSource = null;
                    break;
                case 4:
                    cmbControl.DataSource = null;
                    cmbTool.DataSource = null;
                    break;
                case 5:
                    cmbTool.DataSource = null;
                    break;
                default:
                    break;
            }
        }

        private void cmbContext_SelectedIndexChanged(object sender, EventArgs e)
        {
            //bContextGroupNotClick = true;
            //bContextGroupClicked = false;

            //rdoLotAll.Checked = true;
            //ClearControl();
            //InitControl();

            //ComboBox cmb = (ComboBox)sender;
            //string strCmbName = cmb.Name;
            //switch (strCmbName)
            //{
            //    case "cmbModule":
            //        bIsOVLType = false;
            //        string strLayerOrStep = "Layer";

            //        ClearCmbContext(1);

            //        strCurrentModule = cmbModule.Text.ToString();

            //        bIsLITHOType = IsLITHOType(strCurrentModule);
            //        bIsETCHType = IsETCHType(strCurrentModule);
            //        panOptBtnShow(bIsLITHOType);

            //        bIsCMPType = IsCMPType(strCurrentModule);
            //        strLayerOrStep = GetLayerOrStep(strCurrentModule);
            //        txtLayer.Text = strLayerOrStep;

            //        if (cmbModule.Text.ToString().Equals(""))
            //        {
            //        }
            //        else
            //        {
            //            strListProduct = UIServiceFun.R2R_UI_GetProduct(strUserName, ref strServiceAddress, strCurrentModule);
            //            cmbProduct.DataSource = strListProduct;
            //        }
            //        break;
            //    case "cmbProduct":
            //        ClearCmbContext(2);
            //        strCurrentProduct = cmbProduct.Text.ToString();
            //        if (cmbProduct.Text.ToString().Equals(""))
            //        {
            //            strListStage.Clear();
            //        }
            //        else
            //        {
            //            strListStage = new List<string>() { "*" };
            //            cmbStage.DataSource = strListStage;
            //        }
            //        break;
            //    case "cmbStage":
            //        ClearCmbContext(3);
            //        strCurrentStage = cmbStage.Text.ToString();
            //        if (cmbModule.Text.ToString().Equals("") || cmbProduct.Text.ToString().Equals("") || cmbStage.Text.ToString().Equals(""))
            //        {
            //        }
            //        else
            //        {
            //            strListLayer = UIServiceFun.R2R_UI_GetLayerOrStep(strUserName, ref strServiceAddress, strCurrentModule, strCurrentProduct, strCurrentStage);
            //            cmbLayer.DataSource = strListLayer;
            //        }
            //        break;
            //    case "cmbLayer":
            //        ClearCmbContext(4);
            //        strCurrentLayer = cmbLayer.Text.ToString();
            //        if (cmbModule.Text.ToString().Equals("") || cmbProduct.Text.ToString().Equals("") || cmbStage.Text.ToString().Equals("") || cmbLayer.Text.ToString().Equals(""))
            //        {
            //        }
            //        else
            //        {
            //            strListController = UIServiceFun.R2R_UI_GetController(strUserName, ref strServiceAddress, strCurrentModule, strCurrentProduct, strCurrentStage, strCurrentLayer);
            //            cmbControl.DataSource = strListController;
            //        }
            //        break;
            //    case "cmbControl":
            //        ClearCmbContext(5);
            //        strCurrentController = cmbControl.Text.ToString();

            //        bIsOVLType = IsOVLType(strCurrentController);
            //        bIsOVLCANON = false;
            //        bIsOVLCANON = IsOVLCANON(strCurrentController);

            //        if (cmbModule.Text.ToString().Equals("") || cmbProduct.Text.ToString().Equals("") || cmbStage.Text.ToString().Equals("") || cmbLayer.Text.ToString().Equals("") || cmbControl.Text.ToString().Equals(""))
            //        {
            //        }
            //        else
            //        {
            //            strListTool = UIServiceFun.R2R_UI_GetTool(strUserName, ref strServiceAddress, strCurrentModule, strCurrentProduct, strCurrentStage, strCurrentLayer, strCurrentController);
            //            cmbTool.DataSource = strListTool;
            //        }
            //        break;
            //    case "cmbTool":
            //        if (cmbTool.Text.ToString().Equals(""))
            //        {
            //        }
            //        else
            //        {
            //            strCurrentTool = cmbTool.Text.ToString();
            //        }
            //        break;
            //    default:
            //        break;
            //}
            //panOptSubBtnShow(false);
        }

        private void cmbContext_TextChanged(object sender, EventArgs e)
        {
            bContextGroupNotClick = true;
            bContextGroupClicked = false;

            rdoLotAll.Checked = true;
            ClearControl();
            InitControl();

            ComboBox cmb = (ComboBox)sender;
            string strCmbName = cmb.Name;
            switch (strCmbName)
            {
                case "cmbModule":
                    bIsOVLType = false;
                    string strLayerOrStep = "Layer";

                    ClearCmbContext(1);

                    strCurrentModule = cmbModule.Text.ToString();

                    bIsLITHOType = IsLITHOType(strCurrentModule);
                    bIsETCHType = IsETCHType(strCurrentModule);
                    panOptBtnShow(bIsLITHOType);

                    bIsCMPType = IsCMPType(strCurrentModule);
                    strLayerOrStep = GetLayerOrStep(strCurrentModule);
                    txtLayer.Text = strLayerOrStep;

                    if (cmbModule.Text.ToString().Equals(""))
                    {
                    }
                    else
                    {
                        strListProduct = UIServiceFun.R2R_UI_GetProduct(strUserName, ref strServiceAddress, strCurrentModule);
                        cmbProduct.DataSource = strListProduct;
                    }
                    break;
                case "cmbProduct":
                    ClearCmbContext(2);
                    strCurrentProduct = cmbProduct.Text.ToString();
                    if (cmbProduct.Text.ToString().Equals(""))
                    {
                        strListStage.Clear();
                    }
                    else
                    {
                        strListStage = new List<string>() { "*" };
                        cmbStage.DataSource = strListStage;
                    }
                    break;
                case "cmbStage":
                    ClearCmbContext(3);
                    strCurrentStage = cmbStage.Text.ToString();
                    if (cmbModule.Text.ToString().Equals("") || cmbProduct.Text.ToString().Equals("") || cmbStage.Text.ToString().Equals(""))
                    {
                    }
                    else
                    {
                        strListLayer = UIServiceFun.R2R_UI_GetLayerOrStep(strUserName, ref strServiceAddress, strCurrentModule, strCurrentProduct, strCurrentStage);
                        cmbLayer.DataSource = strListLayer;
                    }
                    break;
                case "cmbLayer":
                    ClearCmbContext(4);
                    strCurrentLayer = cmbLayer.Text.ToString();
                    if (cmbModule.Text.ToString().Equals("") || cmbProduct.Text.ToString().Equals("") || cmbStage.Text.ToString().Equals("") || cmbLayer.Text.ToString().Equals(""))
                    {
                    }
                    else
                    {
                        strListController = UIServiceFun.R2R_UI_GetController(strUserName, ref strServiceAddress, strCurrentModule, strCurrentProduct, strCurrentStage, strCurrentLayer);
                        cmbControl.DataSource = strListController;
                    }
                    break;
                case "cmbControl":
                    ClearCmbContext(5);
                    strCurrentController = cmbControl.Text.ToString();

                    bIsOVLType = IsOVLType(strCurrentController);
                    bIsOVLCANON = false;
                    bIsOVLCANON = IsOVLCANON(strCurrentController);

                    if (cmbModule.Text.ToString().Equals("") || cmbProduct.Text.ToString().Equals("") || cmbStage.Text.ToString().Equals("") || cmbLayer.Text.ToString().Equals("") || cmbControl.Text.ToString().Equals(""))
                    {
                    }
                    else
                    {
                        strListTool = UIServiceFun.R2R_UI_GetTool(strUserName, ref strServiceAddress, strCurrentModule, strCurrentProduct, strCurrentStage, strCurrentLayer, strCurrentController);
                        cmbTool.DataSource = strListTool;
                    }
                    break;
                case "cmbTool":
                    if (cmbTool.Text.ToString().Equals(""))
                    {
                    }
                    else
                    {
                        strCurrentTool = cmbTool.Text.ToString();
                    }
                    break;
                default:
                    break;
            }
            panOptSubBtnShow(false);
        }
        #endregion

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        #region TabMain Event
        private void tabMain_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (tabMain.SelectedTab.Name.Equals("tabPage1"))
                {
                    //tabPage1.Refresh();
                    //tabPage1.Update();
                    //tabPage1.Show();
                }
                else if (tabMain.SelectedTab.Name.Equals("tabPage2"))
                {
                    strConn = UIServiceFun.R2R_UI_GetDBInfoConn(ref strServiceAddress, strServiceType, strDomainName);
                    if (strConn.Equals(""))
                    {
                        MessageBox.Show("The oracle configuration parameter is empty!");
                        tabMain.SelectedTab = tabPage1;
                    }
                    else
                    {
                        if (bRunClick_History)
                        {
                        }
                        else
                        {
                            bool flag = false;
                            flag = History.OracleHelp.bIsConnect(strConn);
                            if (flag)
                            {
                                #region Init History
                                InitDateTime();
                                InitCmbHistory();
                                InitTabLogHistory();
                                #endregion
                            }
                            else
                            {
                                MessageBox.Show("Database connection failed!");
                                tabMain.SelectedTab = tabPage1;
                            }
                        }                          
                    }
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }
        #endregion

        #region GetOracleConn
        //private void GetOracleConn()
        //{
        //    try
        //    {
        //        strConn = string.Empty;
        //        #region GetDBInfo
        //        UIServiceFun.structGetDBInfo structDBInfoNull = new UIServiceFun.structGetDBInfo();
        //        UIServiceFun.structGetDBInfo structDBInfo = new UIServiceFun.structGetDBInfo();
        //        structDBInfo = UIServiceFun.R2R_UI_GetDBInfo(strServiceAddress, strServiceType, strDomainName);

        //        if (structDBInfo.Equals(structDBInfoNull))
        //        {
        //            //MessageBox.Show("Data is empty!");
        //        }
        //        else
        //        {
        //            strConn = "User Id=" + structDBInfo.strUser + "; Password=" + structDBInfo.strPassword + "; Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST="
        //                + structDBInfo.strIP + ")(PORT=" + structDBInfo.strPort + ")))(CONNECT_DATA=(SERVICE_NAME=" + structDBInfo.strServiceName + ")))";

        //        }
        //    }
        //    catch (Exception err)
        //    {
        //        MessageBox.Show(BaseFun.GetExceptionInformation(err));
        //    }
        //    #endregion
        //}
        #endregion

        private void cmb_History_DropDown(object sender, EventArgs e)
        {
            var cmb = sender as ComboBox;
            //ClearControl_History();
            GetCurrentCmbText();
            string strText = cmb.Text.ToString();
            string strCmbName = cmb.Name.ToString();
            switch (strCmbName)
            {
                case "cmbLotId_History":
                    cmb.DataSource = null;
                    cmb.DataSource = GetCmbHistoryList("LOT_ID");
                    break;
                case "cmbModule_History":
                    cmb.Text = strCurrentModule_History;
                    break;
                case "cmbProduct_History":
                    cmb.DataSource = null;
                    cmb.DataSource = GetCmbHistoryList("PRODUCT");
                    break;
                case "cmbStage_History":
                    cmb.DataSource = null;
                    cmb.DataSource = GetCmbHistoryList("STAGE");
                    break;
                case "cmbLayer_History":
                    cmb.DataSource = null;
                    cmb.DataSource = GetCmbHistoryList("LAYER_OR_STEP");
                    break;
                case "cmbTool_History":
                    cmb.DataSource = null;
                    cmb.DataSource = GetCmbHistoryList("TOOL_ID");
                    break;
                default:
                    break;
            }
            cmb.Text = strText;
        }

        private void chkSort_CheckedChanged(object sender, EventArgs e)
        {
            #region old
            //var chk = sender as CheckBox;
            //if (chk.Checked)
            //{
            //    chk.Text = "Descending";
            //}
            //else
            //{
            //    //chk.Text = "Ascending";
            //}
            #endregion

            btnRun_History_Click(sender, e);

            //ClearControl_History();

            //ShowContextHistory();
            //dgvContext_History.ReadOnly = true;
        }

    }
}
