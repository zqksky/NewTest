﻿namespace R2R_UI.Present.Common
{
    partial class frmCommonReset
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panBtnOk = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panDgv = new System.Windows.Forms.Panel();
            this.dgvSet = new System.Windows.Forms.DataGridView();
            this.panDgvLblContext = new System.Windows.Forms.Panel();
            this.lblDgvContext = new System.Windows.Forms.Label();
            this.panLbl = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdoPM = new System.Windows.Forms.RadioButton();
            this.rdoReset = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.panBtnOk.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panDgv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSet)).BeginInit();
            this.panDgvLblContext.SuspendLayout();
            this.panLbl.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.panBtnOk);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panLbl);
            this.panel1.Location = new System.Drawing.Point(0, 64);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(693, 341);
            this.panel1.TabIndex = 1;
            // 
            // panBtnOk
            // 
            this.panBtnOk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panBtnOk.Controls.Add(this.btnCancel);
            this.panBtnOk.Controls.Add(this.btnOk);
            this.panBtnOk.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panBtnOk.Location = new System.Drawing.Point(0, 306);
            this.panBtnOk.Name = "panBtnOk";
            this.panBtnOk.Size = new System.Drawing.Size(693, 35);
            this.panBtnOk.TabIndex = 11;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.BackColor = System.Drawing.SystemColors.Control;
            this.btnCancel.Location = new System.Drawing.Point(607, 7);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(73, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.BackColor = System.Drawing.SystemColors.Control;
            this.btnOk.Location = new System.Drawing.Point(516, 7);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(73, 23);
            this.btnOk.TabIndex = 0;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = false;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panDgv);
            this.panel3.Controls.Add(this.panDgvLblContext);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 45);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(693, 296);
            this.panel3.TabIndex = 10;
            // 
            // panDgv
            // 
            this.panDgv.Controls.Add(this.dgvSet);
            this.panDgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panDgv.Location = new System.Drawing.Point(0, 26);
            this.panDgv.Name = "panDgv";
            this.panDgv.Size = new System.Drawing.Size(693, 270);
            this.panDgv.TabIndex = 3;
            // 
            // dgvSet
            // 
            this.dgvSet.AllowUserToAddRows = false;
            this.dgvSet.AllowUserToDeleteRows = false;
            this.dgvSet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvSet.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSet.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSet.Location = new System.Drawing.Point(0, 0);
            this.dgvSet.Name = "dgvSet";
            this.dgvSet.Size = new System.Drawing.Size(693, 270);
            this.dgvSet.TabIndex = 0;
            this.dgvSet.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSet_CellEndEdit);
            this.dgvSet.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvContext_CellFormatting);
            this.dgvSet.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dgvContext_CellPainting);
            this.dgvSet.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSet_CellValueChanged);
            this.dgvSet.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvContext_RowPostPaint);
            // 
            // panDgvLblContext
            // 
            this.panDgvLblContext.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panDgvLblContext.Controls.Add(this.lblDgvContext);
            this.panDgvLblContext.Dock = System.Windows.Forms.DockStyle.Top;
            this.panDgvLblContext.Location = new System.Drawing.Point(0, 0);
            this.panDgvLblContext.Name = "panDgvLblContext";
            this.panDgvLblContext.Size = new System.Drawing.Size(693, 26);
            this.panDgvLblContext.TabIndex = 2;
            // 
            // lblDgvContext
            // 
            this.lblDgvContext.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDgvContext.AutoSize = true;
            this.lblDgvContext.Location = new System.Drawing.Point(308, 2);
            this.lblDgvContext.Name = "lblDgvContext";
            this.lblDgvContext.Size = new System.Drawing.Size(103, 13);
            this.lblDgvContext.TabIndex = 0;
            this.lblDgvContext.Text = "List of context group";
            // 
            // panLbl
            // 
            this.panLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panLbl.Controls.Add(this.groupBox1);
            this.panLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panLbl.Location = new System.Drawing.Point(0, 0);
            this.panLbl.Name = "panLbl";
            this.panLbl.Size = new System.Drawing.Size(693, 45);
            this.panLbl.TabIndex = 8;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.rdoPM);
            this.groupBox1.Controls.Add(this.rdoReset);
            this.groupBox1.Location = new System.Drawing.Point(278, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(165, 36);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            // 
            // rdoPM
            // 
            this.rdoPM.AutoSize = true;
            this.rdoPM.Location = new System.Drawing.Point(18, 13);
            this.rdoPM.Name = "rdoPM";
            this.rdoPM.Size = new System.Drawing.Size(41, 17);
            this.rdoPM.TabIndex = 15;
            this.rdoPM.Text = "PM";
            this.rdoPM.UseVisualStyleBackColor = true;
            this.rdoPM.CheckedChanged += new System.EventHandler(this.rdoType_CheckedChanged);
            // 
            // rdoReset
            // 
            this.rdoReset.AutoSize = true;
            this.rdoReset.Location = new System.Drawing.Point(100, 13);
            this.rdoReset.Name = "rdoReset";
            this.rdoReset.Size = new System.Drawing.Size(53, 17);
            this.rdoReset.TabIndex = 16;
            this.rdoReset.Text = "Reset";
            this.rdoReset.UseVisualStyleBackColor = true;
            this.rdoReset.CheckedChanged += new System.EventHandler(this.rdoType_CheckedChanged);
            // 
            // frmCommonReset
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(693, 405);
            this.Controls.Add(this.panel1);
            this.Name = "frmCommonReset";
            this.Padding = new System.Windows.Forms.Padding(3, 40, 3, 3);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CommonReset";
            this.Load += new System.EventHandler(this.frmCommonReset_Load);
            this.SizeChanged += new System.EventHandler(this.frmCommonReset_SizeChanged);
            this.Resize += new System.EventHandler(this.frmCommonReset_Resize);
            this.panel1.ResumeLayout(false);
            this.panBtnOk.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panDgv.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSet)).EndInit();
            this.panDgvLblContext.ResumeLayout(false);
            this.panDgvLblContext.PerformLayout();
            this.panLbl.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panLbl;
        private System.Windows.Forms.RadioButton rdoReset;
        private System.Windows.Forms.RadioButton rdoPM;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panDgv;
        private System.Windows.Forms.DataGridView dgvSet;
        private System.Windows.Forms.Panel panDgvLblContext;
        private System.Windows.Forms.Label lblDgvContext;
        private System.Windows.Forms.Panel panBtnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.GroupBox groupBox1;
        
    }
}