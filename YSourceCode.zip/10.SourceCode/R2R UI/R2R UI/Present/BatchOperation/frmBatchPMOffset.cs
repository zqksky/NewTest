﻿
using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace R2R_UI.Present.BatchOperation
{
    public partial class frmBatchPMOffset : MaterialForm
    {
        //private readonly MaterialSkinManager meterialSkinManager;

        #region
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0014) // 禁掉清除背景消息
                return;
            base.WndProc(ref m);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;
                return cp;
            }
        }

        private void CtlDoubleBuffer()
        {
            this.DoubleBuffered = true;//设置本窗体
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲
            //SetStyle(ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
            UpdateStyles();
        }
        #endregion

        public frmBatchPMOffset()
        {
            InitializeComponent();
        }
        public frmBatchPMOffset(string strServiceName, string strCurrentUserName, string strCurrentPwd, string strFrmTool, UIServiceFun.structPH_OVL_Batch_GetPMOffsets structDataPMOffset, string strCurrentType)
        {
            InitializeComponent();
            strServiceAddres = strServiceName;
            strUserName = strCurrentUserName;
            strPassword = strCurrentPwd;

            strTool = strFrmTool;
            structData = structDataPMOffset;

            if (structData.iListInputIndex.Count > 0)
            {
                iListInputIndex = new List<int>(structData.iListInputIndex);
                dListPMOffsets = new List<double>(structData.dListPMOffsets);
                strListInputNames = new List<string>(structData.strListInputNames);
                strListInputModels = new List<string>(structData.strListInputModels);
            }

            strServiceType = strCurrentType;

            #region SetSkin
            SkinHelp.SkinSet(this, strServiceType);
            #endregion
        }

        #region Param
        public string strTool;
        public string strServiceAddres;
        public string strUserName;
        public string strPassword;
        string strServiceType;

        public List<int> iListInputIndex;
        public List<double> dListPMOffsets;
        public List<string> strListInputNames;
        public List<string> strListInputModels;

        UIServiceFun.structPH_OVL_Batch_GetPMOffsets structData = new UIServiceFun.structPH_OVL_Batch_GetPMOffsets();
        UIServiceFun.structPH_OVL_Batch_UpdatePMOffsets structDataUpdate = new UIServiceFun.structPH_OVL_Batch_UpdatePMOffsets();
        #endregion

        private void GetGridValue()
        {
            int rowCount = 0;
            rowCount = dgvSet.Rows.Count;
            if (rowCount > 0)
            {
                strListInputNames.Clear();
                strListInputModels.Clear();
                dListPMOffsets.Clear();
                for (int i = 0; i < rowCount; i++)
                {
                    strListInputNames.Add(dgvSet.Rows[i].Cells[0].Value.ToString());
                    strListInputModels.Add(dgvSet.Rows[i].Cells[1].Value.ToString());
                    dListPMOffsets.Add(double.Parse(dgvSet.Rows[i].Cells[2].Value.ToString()));
                }
            }
            structDataUpdate.strListInputModels = new List<string>(strListInputModels);
            structDataUpdate.strListInputNames = new List<string>(strListInputNames);
            structDataUpdate.dListPMOffset = new List<double>(dListPMOffsets);
        }

        DataTable dbGetContext = new DataTable("GetContext");
        private void frmBatchPMOffset_Load(object sender, EventArgs e)
        {
            #region  Double Buffer
            DataGridViewHelp.DoubleBuffered(dgvContext, true);
            DataGridViewHelp.DoubleBuffered(dgvSet, true);
            CtlDoubleBuffer();
            #endregion

            #region Set Lbl
            string strLbl = "Current Selected Context:" + strTool;
            AddControlHelp.SetLable(panLbl, lblContext, strLbl);

            string strDgvLblContext = "List of context group";
            AddControlHelp.SetLable(panDgvLblContext, lblDgvContext, strDgvLblContext);

            string strDgvLblParameters = "List of Parameters";
            AddControlHelp.SetLable(panDgvLblParameters, lblDgvParameters, strDgvLblParameters);
            #endregion

            #region Get DataContext by zqk modify 20180809
            dbGetContext = DataTableHelp.CreateContextGroupTable(structData.structContext);

            DataTable dbContextGroup = new DataTable("ContextGroup");
            List<string> strListColumn = new List<string>(structData.structContext.strListContexts);
            dbContextGroup = DataTableHelp.GetDistinctTable(dbGetContext, strListColumn);

            DataGridViewHelp.InitDgvGrid(dgvContext, dbContextGroup);
            #endregion

            DataGridViewHelp.InitDgvSet(dgvSet, DataTableHelp.CreateBatchPMOffsetTable(structData),2);
        }
        private void frmBatchPMOffset_Resize(object sender, EventArgs e)
        {

        }

        private void frmBatchPMOffset_SizeChanged(object sender, EventArgs e)
        {

        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            frmCheckedPwd frmChecked = new frmCheckedPwd(strUserName);
            if (frmChecked.ShowDialog() == DialogResult.OK)
            {
                if (frmChecked.strPassword.Equals(strPassword))
                {
                    #region
                    bool bSuccess;
                    try
                    {
                        #region PH_OVL_Batch_UpdatePMOffsets
                        GetGridValue();
                        if (dListPMOffsets.Count > 0 && !structDataUpdate.dListPMOffset.SequenceEqual(structData.dListPMOffsets))
                        {
                            bSuccess = UIServiceFun.R2R_UI_PH_OVL_Batch_UpdatePMOffsets(ref strServiceAddres, strUserName, strTool, structDataUpdate);
                            if (bSuccess)
                            {
                                this.Close();
                            }
                            else
                            {
                                //MessageBox.Show("Set Failed!");
                            }
                        }

                        this.DialogResult = DialogResult.OK;
                        #endregion
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show(BaseFun.GetExceptionInformation(err));
                    }
                    #endregion
                }
                else
                {
                    MessageBox.Show("Invalid password!");
                }
            }
            else
            {
                //MessageBox.Show("Invalid password!");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #region Test DataGridView Event
        private void dgvContext_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //DataGridViewHelp.dgv_CellFormatting(sender, e);
        }

        private void dgvContext_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            //DataGridViewHelp.dgv_CellPainting(sender,  e);
        }

        private void dgvContext_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            //DataGridViewHelp.dgv_RowPostPaint(sender, e);
        }
        #endregion

        private void dgvSet_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            this.dgvSet.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.Honeydew; //Color.MediumPurple;
        }
    }
}
