﻿using Oracle.ManagedDataAccess.Client;
using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace R2R_UI.History
{
    class OracleHelp
    {
        #region Fun
        public static bool bIsConnect(string strConn)
        {
            bool flag = false;
            try
            {
                //strConn = "User Id=e3suite;Password=e3suite;Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=192.168.150.135)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=e3suite)))";
                using (OracleConnection conn = new OracleConnection(strConn))
                {
                    conn.Open();
                    if (conn.State == ConnectionState.Open)
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
            }
            finally
            {
            }
            return flag;
        }

        public static DataTable ExecuteDataTable(string strConn, string strSql)
        {
            using (OracleConnection conn = new OracleConnection(strConn))
            {
                conn.Open();
                using (OracleCommand cmd = conn.CreateCommand())
                {
                    cmd.BindByName = true;
                    cmd.CommandText = strSql;
                    //cmd.Parameters.AddRange(parameters);
                    OracleDataAdapter adapter = new OracleDataAdapter(cmd);
                    DataTable datatable = new DataTable();
                    adapter.Fill(datatable);
                    return datatable;
                }
            }
        }

        public static DataTable GetProcessLogDb(string strConn)
        {
            DataTable db = new DataTable("dbProcessLog");
            try
            {
                string sqlProcessLog = "SELECT * FROM R2R_UI_HISTORY_PROCESS_LOG";
                db = ExecuteDataTable(strConn, sqlProcessLog);
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }

            return db;
        }

        public static DataTable GetXmlLogDb(string strConn)
        {
            DataTable db = new DataTable("dbXmlLog");
            try
            {
                string sqlXmlLog = "SELECT * FROM R2R_UI_HISTORY_XML_LOG";
                db = ExecuteDataTable(strConn, sqlXmlLog);
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            return db;
        }
        #endregion
    }
}
