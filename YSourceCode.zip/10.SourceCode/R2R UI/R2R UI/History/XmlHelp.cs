﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace R2R_UI.History
{
    class XmlHelp
    {
        public static bool IsXmlString(string strXml)
        {
            try
            {
                XmlDocument xml = new XmlDocument();
                xml.LoadXml(strXml);//判断是否加载成功
                return true;//是xml文件，返回
            }
            catch
            {
                return false;//不是xml文件，返回
            }
        }
        public static bool IsXmlFile(string strPath)
        {
            string strXml = "";
            using (StreamReader sr = new StreamReader(strPath))
            {
                strXml = sr.ReadToEnd();
                sr.Close();
                sr.Dispose();
            }
            try
            {
                XmlDocument xml = new XmlDocument();
                xml.LoadXml(strXml);//判断是否加载成功
                return true;//是xml文件，返回
            }
            catch
            {
                return false;//不是xml文件，返回
            }
        }

        public static void WriteStringToXml(string strTxt, string strXmlSavePath)
        {
            try
            {
                XmlDocument xdoc = new XmlDocument();
                xdoc.LoadXml(strTxt);
                //XmlComment comment = xdoc.CreateComment("<!-- note -->");
                xdoc.Save(strXmlSavePath);

                //XmlDocument xdoc = new XmlDocument();
                //xdoc.LoadXml(这里是你的xml字符串);
                //或者
                //XmlDocument xdoc = new XmlDocument();
                //xdoc.Load(这里是你的xml文件);

                //或者
                //xdoc.InnerXml= strTxt; //是你的xml字符串
                //xdoc.Save(strXmlSavePath);    //这里是你的xml文件
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }

        }
    }
}




    